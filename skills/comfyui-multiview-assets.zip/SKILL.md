---
name: comfyui-multiview-assets
description: 基于 Comfy-Org/comfy-skills 构建与调度版本化 ComfyUI API Workflow JSON，生成一致的正交三视图（前/侧/顶视图）、PBR 法线/粗糙度贴图、去背景产品图及系列风格资产，并承接 C2M 闭环中 #17 到 #02 CAD Bot 的零件图转三视图交接。
---

# ComfyUI 多视图与工业视觉资产生成（`comfyui-multiview-assets`）

## 1. 触发条件
当用户或上游 Bot 提出以下任一需求时启用本技能：
- 需要基于草图、实拍图或产品描述生成工业级正交三视图（前视图 `front` / 侧视图 `side` / 顶视图 `top`）；
- 需要生成与基准图对齐的 PBR 材质贴图（法线图 `normal`、粗糙度图 `roughness`、高度/金属度贴图）；
- 需要批量输出统一视角、统一光照与色板的去背景产品图（RGBA 透明底）或系列风格一致资产；
- 需要构建、版本化归档或批处理调度可复现的 ComfyUI API Workflow JSON（锁定 `seed`、模型版本与节点参数）；
- 在 C2M 闭环中接收 `#17` 闲鱼买家草图/损坏零件照片，转换为供 `#02 CAD Bot` 建模使用的标准正交三视图与交接元数据。

---

## 2. GitHub 开源底座与关联能力
- **核心开源底座**：`Comfy-Org/comfy-skills`（`https://github.com/Comfy-Org/comfy-skills`），遵循其 Comfy Cloud Skill 规范与 MCP 调度模型，支持对接官方 Comfy Cloud MCP（`https://cloud.comfy.org/mcp`，Streamable HTTP + OAuth）或本地 ComfyUI REST API（`/system_stats`、`/object_info`、`/upload/image`、`/prompt`、`/history`、`/view`）。
- **关联 MCP 插件**：`huggingface`（`https://huggingface.co/settings/mcp`），用于检索与核验基座模型、ControlNet/IP-Adapter/法线粗糙度生成权重、开源许可协议，以及按需调用启用 MCP 徽章的公开预处理 Space。

---

## 3. 前置环境检测与缺失引导（硬性门禁）
执行任何生成步骤前，必须按顺序完成环境真实性检测，**严禁跳过检测或假装生成成功**：

1. **后端可达性检测**：
   - 若使用云端引擎：确认 Comfy Cloud MCP 已绑定且 OAuth 会话有效（如 OpenClaw 下检查 `openclaw mcp status --verbose`）。未登录或未配置时，直接提示用户执行 `Comfy-Org/comfy-skills` 官方接入步骤（如 `openclaw mcp set comfy ...` 与 `openclaw mcp login comfy` 或 Claude Code `/plugin install comfy-cloud@comfy-skills`），**立即停止等待**。
   - 若使用本地引擎：请求 `GET http://127.0.0.1:8188/system_stats`（或用户指定的 ComfyUI 地址）。若连接失败，明确列出启动 ComfyUI 与开启监听端口的步骤并停止；若工作流依赖特定自定义节点或模型，必须先比对 `/object_info` 与本地模型清单，缺项一次列全后停止。
2. **Hugging Face 检索检测**（仅当需要查新模型/许可/Space 时）：
   - 确认 `huggingface` MCP 可用；若需访问受限权重且未配置账号 Token，引导用户前往 `https://huggingface.co/settings/mcp` 完成授权，绝不伪造下载或许可信息。

---

## 4. 分步执行 SOP

### Step 1：输入标准化与目标拆解
- 校验输入图像完整性（可读性、分辨率、是否存在严重倾斜/遮挡/反光）及文字参数（主体类别、材质属性、背景要求、输出尺寸）。
- 明确交付产物集合：
  - **正交三视图**：`front.png`、`side.png`、`top.png` + `orthographic_sheet.png`；
  - **PBR 贴图**：`albedo.png`（可选）、`normal.png`（切线空间 RGB）、`roughness.png`（单通道灰度）；
  - **去背景产品图**：RGBA 透明底 PNG（白底/纯色剥离）；
  - **风格一致系列图**：共享参考图引导（IP-Adapter / Reference / 固定风格提示词前缀与调色 LUT）。

### Step 2：工作流构建与版本固化（Strict Versioning）
- 确保使用 **API Format JSON**（以节点 ID 为键的节点字典，而非含 UI 坐标的网页版工作流 JSON）。
- 若未指定现有工作流，基于 `Comfy-Org/comfy-skills` 规范构造或检索对应模板，并通过 `huggingface` MCP 核实关键模型文件名与商用/开源协议。
- **锁定复现参数**：
  - 所有采样器显式写入正整数 `seed`，且固定策略（不留随机或每次递增）；
  - 固化 `steps`、`cfg`、`sampler_name`、`scheduler`、分辨率与权重文件精确名称；
  - 赋予语义化版本号（如 `v1.0.0`），落盘 `workflows/<name>.v<x.y.z>.api.json` 并计算 `workflow_sha256`。

### Step 3：执行调度与产物拉取
- 若使用本地 ComfyUI：先通过 `/upload/image` 上传参考图/草图，将返回的文件名回填至 `LoadImage` 节点，再向 `/prompt` 提交 JSON，轮询 `/history/{prompt_id}` 直至状态完成，使用 `/view` 下载原始输出图。
- 若使用 Comfy Cloud MCP：按 `Comfy-Org/comfy-skills` 规范提交云端任务并获取产物下载链接或本地落盘文件。
- 严禁在任务异常、节点报错或超时未完成时编造输出路径。

### Step 4：工程级质检（QA）
逐项检查输出图像，不合格则调整提示词/权重强度/ControlNet 条件权重后**升版工作流（如 `v1.0.1`）并记录新参数**重新出图，绝不覆盖旧版本记录：
1. **三视图一致性**：三视图间结构特征（孔洞、凸台、倒角、轮廓比例）互相吻合；投影方向符合正交（无明显透视汇聚变形）；主体居于画布安全区且三视图等比对齐。
2. **PBR 贴图规范**：法线贴图底色符合切线空间基准紫蓝色 `RGB(128, 128, 255)` 左右分布且凹凸方向一致；粗糙度贴图与材质物理特性匹配（金属高光面偏暗、磨砂塑料/破损粗糙面偏亮），与基准图像素严格对齐。
3. **去背景精度**：Alpha 通道边界干净，无残留白边/灰边（halo），内部镂空孔洞正确透明。

### Step 5：复现档案封装
每次交付必须同目录生成 `manifest.json`，完整记录：`task_id`、`workflow_file`、`workflow_version`、`workflow_sha256`、`seed`、`models`（含许可信息）、输入与输出所有文件的 `sha256` 与像素分辨率。

---

## 5. 跨 Bot 协同接口（C2M 闲鱼 3D 打印闭环：#17 → #06 → #02）

### 5.1 上游输入契约（接收自 `#17` 闲鱼/客服 Bot）
要求上游提供结构化工单数据包（缺核心字段时先退回 `#17` 补采）：
- `order_id`：闲鱼订单/工单唯一编号；
- `raw_images[]`：买家手绘草图或损坏零件多角度实拍照；
- `part_notes`：零件名称、安装位置、损坏部位说明（如“左侧卡扣断裂需补全对称还原”）；
- `known_dimensions`：已知物理参考尺寸及单位（必须明确 `unit: "mm"`，如外径/总长/孔径；若买家未提供任何参考尺或实测数值，须标记 `dimension_status: "uncalibrated"`）。

### 5.2 下游交接产物契约（交付给 `#02 CAD Bot`）
向 `#02 CAD Bot` 移交完整文件夹或标准交接包：
1. `views/front.png`、`views/side.png`、`views/top.png`：统一分辨率（如 `1024×1024`）、纯白/透明背景、高对比度清晰轮廓正交三视图；
2. `views/orthographic_sheet.png`：横排/标准三视图对齐校对图，便于 `#02` 核验投影对齐；
3. `handoff_to_cad.json`：必须包含以下字段：
   - `order_id`、`source_bot: "comfyui-asset-bot"`、`target_bot: "cad-bot"`
   - `unit: "mm"`、`dimension_status`（`calibrated` / `estimated_from_photo` / `uncalibrated`）
   - `reference_scale`（锚定尺寸字段、数值与来源）
   - `views`（各视图路径、像素宽高 `width_px`/`height_px`、文件 `sha256`）
   - `reproducibility`（`workflow_version`、`workflow_sha256`、`seed`）
   - `geometry_risks[]`（**强制字段**：逐条列明原照遮挡部位、破损脑补对称部位及不确定孔位，供 `#02 CAD Bot` 与买家二次确认）。

---

## 6. 质检与异常处理
- **节点或模型缺失**：列出缺失的 `class_type` 或 checkpoint/ControlNet 名称，附 `huggingface` 检索到的合法替代或安装路径建议后停止。
- **三视图投影矛盾**：例如顶视图与前视图槽口数量不一致，禁止直接交付 `#02 CAD Bot`，必须回炉加权多视图一致性控制或提示补充角度照片。
- **种子漂移**：发现输出未锁定种子或与 `manifest.json` 哈希不匹配时，立即判定质检失败并重跑锁定版本。

---

## 7. 禁止越界事项
- 禁止伪造 ComfyUI 跑图日志、虚构文件路径或未实际检验的 SHA-256 哈希；
- 禁止使用未版本化、种子随机（`-1`）的一次性工作流作为正式交付物；
- 禁止越俎代庖直接生成 `.step`、`.iges`、`.stl` 等 CAD 工程文件或切片 G-code（分别属 `#02 CAD Bot` 与下游切片打印 Bot 职责）；
- 禁止向 `#02 CAD Bot` 隐瞒草图推演不确定性或将视觉估算比例伪造为卡尺实测公差。
