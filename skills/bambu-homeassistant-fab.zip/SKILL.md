---
name: bambu-homeassistant-fab
description: 打通 3D 模型检验、自动切片、拓竹 Bambu Lab 局域网开印、防炒面机舱视觉巡检与 Home Assistant 智能家居联动，并支持 C2M 无人车间跨 Bot 流水线交接。
---

# 拓竹切片打印与物联联动 (`bambu-homeassistant-fab`)

## 1. 触发条件
当用户或上游调度 Bot 请求以下任一任务时激活本技能：
- 检验 `.stl` / `.3mf` 模型可打印性、自动切片并下发至拓竹（Bambu Lab）打印机开印；
- 监控运行中的打印任务、抓拍机舱画面防“炒面（脱床拉丝）”或执行异常暂停；
- 通过 Home Assistant 联动控制打印间排风扇、照明、电源插座或传感器；
- 作为「C2M 闲鱼 3D 打印无人车间」物理执行节点接收订单并回传制造回执。

---

## 2. GitHub 开源底座与前置门禁（Pre-flight Check）

本技能仅依赖以下三项开源工程（详见 [references/stack-and-sop.md](references/stack-and-sop.md)）：
1. **`DMontgomery40/bambu-printer-mcp`**：拓竹 LAN Mode 协议桥接（MQTT 遥测/暂停/G-code 控制、FTPS 文件管理、`.3mf` 打印与 AMS 映射、STL 几何操作、机舱画面读取）。
2. **`codeofaxel/Kiln`**：切片与打印编排套件（`pip install kiln3d`、`kiln serve`、`kiln status --json`、`kiln snapshot`、`kiln park`、OrcaSlicer/PrusaSlicer 切片流程）。
3. **`tevonsb/homeassistant-mcp`**：Home Assistant 实体查询、开关/风扇/灯光控制与自动化触发。

### 门禁检测铁律
在执行任何打印或物联动作前，**必须先验证连接与工具就绪状态**：
- 确认 `bambu-printer-mcp` / `kiln` 已联通目标打印机且状态可读（需本机配置 `BAMBU_IP`、`BAMBU_ACCESS_CODE`、`BAMBU_SERIAL`、`BAMBU_MODEL` 或 `~/.kiln/config.yaml`）；
- 确认 `homeassistant-mcp` 已联通且可读取目标排风扇/灯光实体（需本机配置 `HASS_HOST`、`HASS_TOKEN`）；
- **缺失引导**：若任一服务、切片软件或本地凭证缺失，立即返回 `BLOCKED`，一次性列明缺失项、`.env` 变量名与安装/开启局域网模式（LAN Only）的步骤并**停止执行**。严禁伪造遥测数据、虚假成功或要求用户在聊天中粘贴明文 Access Code/Token。

---

## 3. 分步执行 SOP

### Step 1：模型与几何合规检验
1. 校验输入文件路径存在，计算并比对 `sha256`（若由上游流水线传入）。
2. 检查单位（默认 `mm`）、包围盒尺寸是否超过当前机型成型体积（如 `256×256×256 mm`）。
3. 检验模型底面是否贴合热床（Z=0）、是否存在大面积悬空无支撑或明显非流形错误；必要时调用网格对齐/放平工具修正，改动后生成新文件名避免覆盖原始资产。

### Step 2：自动切片与 AMS 耗材校验
1. 调用 `Kiln` 或 `bambu-printer-mcp` 对接 OrcaSlicer / Bambu Studio 进行切片，输出 `.gcode.3mf`。
2. 核对关键切片参数：层高、墙层数、填充率、自动支撑、喷嘴温度与热床温度。
3. 查询打印机 **AMS 实时耗材槽位**：确认目标材质（如 PLA / PETG / ABS）与颜色存在、余量充足，且切片温度曲线与槽位耗材严格一致；若存在材质冲突（如用 PLA 槽位匹配 ABS 高温参数），立即 `BLOCKED` 报出冲突项。

### Step 3：环境联动与下发开印
1. 通过 `homeassistant-mcp` 打开打印工位照明与排风/空气净化设备，确认设备在线。
2. 复核打印机当前处于空闲（`idle` / 热床无残留任务确认），经 FTPS 上传 `.gcode.3mf` 并通过 MQTT 发起打印（指定盘片与 AMS 槽位映射）。
3. 回读打印任务启动确认状态与预估耗时。

### Step 4：打印中防炒面视觉巡检与止损
1. 打印期间按 **每 10 分钟** 节拍抓取机舱实时画面（`bambu-printer-mcp` 摄像头读取或 `kiln snapshot`）及温度/层高遥测。
2. 重点检查首层附着、热床边角翘曲、空中拉丝（炒面征兆）与喷头异物缠绕。
3. **异常即时止损**：一旦判定出现明显脱床、炒面或拉丝扩散：
   - 立即通过 MQTT/`bambu-printer-mcp` 下发暂停指令（必要时执行 `kiln park` 移开喷头避免烫伤打印件）；
   - 通过 `homeassistant-mcp` 触发工位灯光警示（如切换高亮/闪烁提示）；
   - 输出 `PAUSED_ALERT` 报告，附上抓拍图像路径与飞书告警字段，等待人工清床确认后再决定取消或恢复。

### Step 5：完工收尾与智能取件联动
1. 监控任务到达 `100%` 并等待热床降温至安全阈值（如 `< 45°C`）及余烟排尽。
2. 通过 `homeassistant-mcp` 关闭排风扇、切换取件提示灯效（或关闭非必要照明）。
3. 生成完整交接摘要并触发飞书取件/发货提醒。

---

## 4. 跨 Bot 协同接口（C2M 无人车间流水线）

### 4.1 上游输入契约（设计/接单/审核 Bot → #18）
```json
{
  "order_id": "XY-20261118-001",
  "model_path": "/abs/path/to/model.3mf",
  "sha256": "<64-hex-sha256>",
  "unit": "mm",
  "target_printer": "bambu-p1s-01",
  "material": "PLA",
  "color": "Matte Black",
  "layer_height_mm": 0.2,
  "infill_pct": 15,
  "support_enabled": true,
  "ha_entities": {
    "exhaust_fan": "fan.print_room_exhaust",
    "status_light": "light.print_room_desk"
  }
}
```

### 4.2 下游交接产物格式（#18 → 飞书通知/客服/发货 Bot）
```json
{
  "order_id": "XY-20261118-001",
  "job_id": "bambu-job-20261118-0930",
  "status": "COMPLETED",
  "gcode_3mf_path": "/abs/path/to/model.gcode.3mf",
  "ams_slot_used": 1,
  "filament_used_g": 42.6,
  "duration_min": 88,
  "snapshot_path": "/abs/path/to/latest_chamber.jpg",
  "iot_post_state": {
    "exhaust_fan": "off",
    "status_light": "pickup_ready"
  },
  "feishu_card_payload": {
    "title": "3D打印完工待取件",
    "order_id": "XY-20261118-001",
    "result": "COMPLETED",
    "note": "热床已冷却，排风已关闭，可取件质检发货"
  }
}
```

---

## 5. 质检与异常处理矩阵

| 异常场景 | 判定信号 | 标准处置动作 |
| :--- | :--- | :--- |
| 脱床 / 炒面 / 严重拉丝 | 机舱画面出现空中丝团、零件移位或边角明显翘起 | 立即暂停打印 + 必要时 `kiln park` + 灯光告警 + 附快照报 `PAUSED_ALERT` |
| AMS 耗材冲突或余量不足 | 槽位材质与切片配置不一致或传感器报断料 | 禁止开印/立即暂停，输出 `BLOCKED`/`PAUSED_ALERT` 并指明需更换的 AMS 槽位号 |
| 温度异常或通信断连 | 喷嘴/热床掉温、MQTT 超时无心跳 | 不得盲目重发开印，先检查局域网与电源插座状态并上报告警 |
| Home Assistant 实体不可用 | `ha_entities` 缺失或离线 | 打印关键安全流程不受虚报影响，明确标注 IoT 联动未生效项并提醒排查 HA |

---

## 6. 禁止越界事项
- 严禁在未确认设备闲置、未核对材质与尺寸的情况下直接发起远程开印；
- 严禁将 `BAMBU_ACCESS_CODE`、`HASS_TOKEN` 等凭证写入输出文本、日志或工单回执；
- 严禁在检测到炒面风险后继续忽略告警完成剩余层打印；
- 严禁越权修改与打印安全无关的家庭安防/门锁/隐私设备状态。
