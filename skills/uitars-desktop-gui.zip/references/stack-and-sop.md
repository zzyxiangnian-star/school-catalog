# UI-TARS 桌面 GUI 操控参考栈与 SOP（`references/stack-and-sop.md`）

## 1. 核心 GitHub 开源底座与关联 MCP 仓库清单

| 组件角色 | GitHub 仓库 / 包名 | 核心定位与能力边界 |
| :--- | :--- | :--- |
| **核心开源底座（视觉定位与代理框架）** | [`bytedance/UI-TARS-desktop`](https://github.com/bytedance/UI-TARS-desktop) | 提供原生桌面 GUI 视觉定位模型接入（UI-TARS 系列 VLM）、UI-TARS Desktop 客户端及 `@agent-tars/cli`，负责将原始桌面截图映射为精准像素坐标与原子操作规划。 |
| **Windows 原生 GUI 操控 MCP** | [`CursorTouch/Windows-MCP`](https://github.com/CursorTouch/Windows-MCP)（对应 `windows-mcp`） | 基于 Python / `uv` 的 Windows 10/11 桌面自动化 MCP，提供 `DisplayInventory`、`Screenshot`、`Snapshot`、`App`、`Click`、`Type`、`Move`、`Scroll`、`Shortcut`、`Wait`、`WaitFor`、`Clipboard` 等原子能力。 |
| **本地文件与持久化终端 MCP** | [`wonderwhy-er/DesktopCommanderMCP`](https://github.com/wonderwhy-er/DesktopCommanderMCP)（对应 `desktop-commander` / `@wonderwhy-er/desktop-commander`） | 提供工作区外的系统级文件读写与哈希校验、持久终端会话、后台进程监控，以及 `.xlsx`/`.csv`/`.pdf` 结构化数据直接处理，弥补纯视觉在批量数据校验上的短板。 |

---

## 2. 典型 MCP 与 CLI 配置模板

> 说明：以下配置中的本地路径与模型 API Key 均为占位符，部署前需替换为本机真实环境；切勿将真实密钥提交至代码仓库。

### 2.1 MCP 客户端配置（`mcp.json` / `claude_desktop_config.json`）

```json
{
  "mcpServers": {
    "windows-mcp": {
      "command": "uvx",
      "args": [
        "windows-mcp"
      ]
    },
    "desktop-commander": {
      "command": "npx",
      "args": [
        "-y",
        "@wonderwhy-er/desktop-commander@latest"
      ]
    }
  }
}
```

若使用源码本地克隆运行 `Windows-MCP`，可按如下方式指定目录：

```json
{
  "mcpServers": {
    "windows-mcp": {
      "command": "uv",
      "args": [
        "--directory",
        "C:\\path\\to\\Windows-MCP",
        "run",
        "windows-mcp"
      ]
    }
  }
}
```

### 2.2 `bytedance/UI-TARS-desktop` CLI 启动参考

```bash
# 快速拉起 Agent TARS CLI（需 Node.js >= 20）
npx @agent-tars/cli@latest

# 使用本地或兼容 OpenAI 接口的 UI-TARS 视觉定位服务时，通过环境变量注入配置
export VLM_BASE_URL="http://127.0.0.1:8000/v1"
export VLM_MODEL_NAME="UI-TARS-1.5-7B"
export VLM_API_KEY="<YOUR_LOCAL_OR_PROVIDER_API_KEY>"
```

### 2.3 环境前置检测命令（Windows PowerShell）

执行任何 GUI 任务前，建议核验以下基础依赖是否就绪：

```powershell
# 1. 检查 Node.js 与 uv 是否可用
node -v
uv --version

# 2. 检查输入文件（例如 3D 模型或账单）SHA-256 哈希与大小
Get-FileHash -Path "D:\workspace\orders\order_1024.stl" -Algorithm SHA256
Get-Item "D:\workspace\orders\order_1024.stl" | Select-Object Name, Length, LastWriteTime

# 3. 检查目标闭源客户端进程是否已启动（示例：微信 / 切片软件）
Get-Process | Where-Object { $_.ProcessName -match "WeChat|bambu-studio|orca-slicer" } | Select-Object ProcessName, Id, MainWindowTitle
```

---

## 3. 高危操作分级与二次确认单模板

| 风险等级 | 典型桌面场景 | 处理策略 |
| :--- | :--- | :--- |
| **L1 只读观测** | 截图、切换只读标签页、查看订单详情、读取当前界面数值 | 自动执行，保留截图摘要。 |
| **L2 本地可逆加工** | 新建草稿、导入模型切片、调整局部参数、导出到临时目录新文件 | 单步复核执行，禁止覆盖原始输入文件。 |
| **L3 不可逆高危动作** | 删除账套/文件、ERP 过账/反结账、财务付款/转账/开票、微信/企微对外发送消息、向 3D 打印机/产线直接下发启动命令 | **强制冻结（`AWAITING_CONFIRM`）**，禁止触发最终点击/回车，必须输出下方确认单等待人工放行。 |

**二次确认单标准结构：**

```json
{
  "status": "AWAITING_CONFIRM",
  "confirm_id": "confirm-20261118-001",
  "risk_level": "L3",
  "action_type": "outbound_message | payment | delete | erp_post | print_dispatch",
  "target_app": "WeChat / 金蝶客户端 / Bambu Studio",
  "target_window_title": "当前激活窗口完整标题",
  "planned_action": "即将点击坐标 (x, y) 的【确认发送 / 立即付款 / 打印】按钮",
  "payload_summary": "具体接收人、金额、文件路径或耗材参数摘要",
  "screenshot_before": "当前待点击画面截图路径"
}
```

---

## 4. 交付产物与跨 Bot 交接检验清单

每次桌面 GUI 任务结束前，逐项核对以下条目：

- [ ] **前置环境已验证**：已核实 `windows-mcp`、`desktop-commander`（如涉及文件校验）及显示器分辨率/DPI 缩放，未出现未授权或黑屏/锁屏状态。
- [ ] **输入契约已校验**：输入文件路径存在、格式正确且 `SHA-256` 与上游任务单一致；3D 模型文件已确认尺寸单位（默认 `mm`）未因软件默认单位错误导致缩放异常。
- [ ] **单步闭环无跳步**：全程严格遵守“观测 → 单步 → 复核”，无连续盲点；遇系统弹窗或焦点丢失已及时捕获并中止。
- [ ] **高危零越权**：所有删除、支付、过账、对外发送、物理下发指令均已停留在执行前一步并取得人类明确批准（或严格返回 `AWAITING_CONFIRM`）。
- [ ] **输出产物可验真**：导出文件（`.gcode` / `.3mf` / `.xlsx` / `.pdf`）已通过磁盘存在性检查、非零字节校验，并附上 `SHA-256` 哈希及最终界面完成态截图。
