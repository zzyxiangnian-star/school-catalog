# n8n 与飞书人机审批技术底座与检验手册

## 1. 核心 GitHub 开源底座

| 组件 | GitHub 仓库 / 包名 | 覆盖能力与核心定位 |
| --- | --- | --- |
| n8n MCP 底座 | `czlonkowski/n8n-mcp`（npm: `n8n-mcp`） | 覆盖 3,501 个 n8n 节点 Schema 与 2,352 套工作流模板，提供离线节点检索、工作流静态校验及在线实例编排调试能力 |
| 飞书官方 OpenAPI MCP | `larksuite/lark-openapi-mcp`（npm: `@larksuiteoapi/lark-mcp`） | 封装飞书/Lark 官方 OpenAPI，通过 `-t` 预设或精确 API 名称暴露 IM 消息卡片与 Bitable 多维表格读写工具 |

### 核心 MCP 工具速查

- **`n8n-mcp` 离线检索与校验**：
  - `search_nodes`：按关键字或集成名称检索节点类型，防止臆造节点名。
  - `get_node`：支持 `minimal` / `standard` / `full` 渐进式获取节点参数 Schema。
  - `search_templates`：从 2,352 套官方及社区模板中按任务/节点检索参考拓扑。
  - `validate_workflow`：对工作流 JSON 进行节点参数、连接拓扑与表达式语法静态校验。
- **`n8n-mcp` 实例运维（需配置 `N8N_API_URL` 与 `N8N_API_KEY`）**：
  - `n8n_create_workflow` / `n8n_update_workflow`：创建或更新工作流（默认保持未激活草稿态）。
  - `n8n_list_executions` / `n8n_get_execution`：检索失败或卡滞的执行记录并定位节点报错载荷。
- **`@larksuiteoapi/lark-mcp` 飞书交互与台账**：
  - `im.v1.message.create`：向审批人或审批群下发飞书交互式消息卡片（Interactive Card）。
  - `im.v1.message.list`：查询会话上下文回执（只读排查用）。
  - `bitable.v1.appTableField.list`：校验多维表格审批台账字段结构是否完整。
  - `bitable.v1.appTableRecord.search` / `create` / `batchCreate`：台账幂等查重与审批记录写入。

---

## 2. 典型 MCP 配置模板

### 2.1 `mcpServers` 标准 JSON 配置（Claude Desktop / Cursor / Windsurf 通用）

> 前置依赖：Node.js `>= 20`，以及可访问的 n8n 实例和飞书企业自建应用。

```json
{
  "mcpServers": {
    "n8n-mcp": {
      "command": "npx",
      "args": ["n8n-mcp"],
      "env": {
        "MCP_MODE": "stdio",
        "LOG_LEVEL": "error",
        "DISABLE_CONSOLE_OUTPUT": "true",
        "N8N_API_URL": "https://your-n8n-instance.example.com",
        "N8N_API_KEY": "<your_n8n_api_key>"
      }
    },
    "lark-mcp": {
      "command": "npx",
      "args": [
        "-y",
        "@larksuiteoapi/lark-mcp",
        "mcp",
        "-a",
        "<your_feishu_app_id>",
        "-s",
        "<your_feishu_app_secret>",
        "-t",
        "preset.light,im.v1.message.create,bitable.v1.appTableField.list,bitable.v1.appTableRecord.search,bitable.v1.appTableRecord.create"
      ]
    }
  }
}
```

### 2.2 Claude Code CLI 注册示例（PowerShell）

```powershell
claude mcp add n8n-mcp `
  '-e MCP_MODE=stdio' `
  '-e LOG_LEVEL=error' `
  '-e DISABLE_CONSOLE_OUTPUT=true' `
  '-e N8N_API_URL=https://your-n8n-instance.example.com' `
  '-e N8N_API_KEY=<your_n8n_api_key>' `
  -- npx n8n-mcp

claude mcp add lark-mcp -- npx -y @larksuiteoapi/lark-mcp mcp `
  -a <your_feishu_app_id> `
  -s <your_feishu_app_secret> `
  -t preset.light,im.v1.message.create,bitable.v1.appTableField.list,bitable.v1.appTableRecord.search,bitable.v1.appTableRecord.create
```

> 说明：若使用海外版 **Lark** 而非国内版**飞书**，需在 `lark-mcp` 参数中追加 `"-d", "https://open.larksuite.com"`。

---

## 3. 飞书应用权限与台账字段基线

### 3.1 飞书开放平台必备权限（最小权限原则）

1. `im:message` / `im:message:send_as_bot`（发送交互式审批卡片）
2. `bitable:app` 或对应多维表格的读写权限（`bitable.v1.appTableRecord.*`）
3. 卡片回调配置：在飞书开发者后台「事件与回调 -> 回调配置」中配置 n8n `Wait` 节点或网关暴露的 HTTPS 回调地址，并开启回调签名校验（`Verification Token` / `Encrypt Key`）。

### 3.2 审批台账多维表格建议字段

| 字段名 | 类型 | 说明 |
| --- | --- | --- |
| `approval_id` | 文本 | 全局唯一审批单号（幂等主键） |
| `request_id` | 文本 | 上游业务/跨 Bot 请求幂等键 |
| `workflow_id` | 文本 | n8n 工作流 ID |
| `execution_id` | 文本 | n8n 本次执行 ID |
| `risk_category` | 单选 | `refund` / `outbound` / `payment` / `prod_deploy` |
| `amount_cny` | 数字 | 涉及金额（元，保留两位小数；非资金类填 `0`） |
| `payload_sha256` | 文本 | 冻结载荷的 SHA-256 摘要，防审批前后篡改 |
| `decision` | 单选 | `PENDING` / `APPROVED` / `REJECTED` / `TIMEOUT` |
| `approver_id` | 人员/文本 | 实际点击审批人的飞书 `open_id` |
| `decided_at` | 日期时间 | 裁决时间（ISO-8601） |
| `resume_url` | 超链接/文本 | n8n `Wait` 节点回调恢复 URL（审批完成后可脱敏置空） |

---

## 4. HITL 门禁标准拓扑模式

```text
[上游 Trigger / 跨 Bot Webhook]
   │
   ▼
[Set / Code: 计算 payload_sha256 & 生成 approval_id]
   │
   ▼
[风险分类器 (Switch): 命中 refund / outbound / payment / prod_deploy?]
   ├─ 否 ──▶ [普通安全路径]
   └─ 是 ──▶ [飞书 Bitable 写入 PENDING 台账]
                 │
                 ▼
             [飞书 IM 下发交互式审批卡片 (含 $execution.resumeUrl 与摘要)]
                 │
                 ▼
             [n8n Wait 节点 (On Webhook Call, 设置超时上限)]
                 │
                 ▼
             [Code / IF: 校验回调签名 + decision == APPROVED + payload_sha256 一致]
                 ├─ 通过 ──▶ [更新台账 APPROVED] ──▶ [放行下游动作 / 输出交接凭证]
                 └─ 拒绝/超时/异常 ──▶ [更新台账 REJECTED/TIMEOUT] ──▶ [阻断并告警通知]
```

---

## 5. 交付产物检验清单（交付前逐项核对）

- [ ] **环境前置检验**：已真实检查 `n8n-mcp` 与 `lark-mcp` 工具可达性，无未声明的密钥占位直接投入生产。
- [ ] **节点合法性**：所有 n8n 节点类型与参数均经 `search_nodes` / `get_node` 确认，并通过 `validate_workflow` 零 Error 校验。
- [ ] **风险全覆盖**：工作流内所有退款、外发、付款、上生产节点均处于 `Wait + 飞书审批` 下游，不存在绕过分支（Bypass Path）。
- [ ] **防篡改校验**：审批前冻结业务载荷并计算 `payload_sha256`，回调恢复时重新比对哈希一致性。
- [ ] **幂等与超时**：`approval_id` / `request_id` 具备台账查重防重放机制；`Wait` 节点配置了明确超时时间与超时拒止策略（Timeout = Deny）。
- [ ] **部署安全态**：新建或变更工作流默认以未激活草稿（`active: false`）交付，需由用户或上生产审批通过后方可激活。
