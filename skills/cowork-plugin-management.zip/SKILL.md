---
name: cowork-plugin-management
description: "创建、定制并管理贴合团队工具链的 Cowork 插件，统一配置 MCP 服务与工作流指令。"
---

# Cowork Plugin Management

创建、定制并管理贴合团队工具链的 Cowork 插件，统一配置 MCP 服务与工作流指令。

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (2)

- `cowork-plugin-management-cowork-plugin-customizer`
- `cowork-plugin-management-create-cowork-plugin`
