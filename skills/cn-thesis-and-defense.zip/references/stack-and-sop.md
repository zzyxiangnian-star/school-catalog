# 学习与论文助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- openags/paper-search-mcp — MIT（免密钥直连 arXiv/OpenAlex/Crossref/PubMed）
- K-Dense-AI/scientific-agent-skills — MIT（按需挑选综述与引文管理技能）
- anthropics/skills (`skills/pptx`) — Apache-2.0（可编辑 PPTX 导出）
- ChengDSYJ-Studio/CNKI-Enhanced-MCP — GPL-3.0（仅由用户作为独立外部进程自备，支持 GB/T 7714）

## 2. 本机前置准备

- Python 3.10+、uv；英文检索可零密钥直接运行 `uvx paper-search-mcp`
- 中文知网检索如选用外部 `CNKI-Enhanced-MCP`，需用户在本机 Chrome/Edge 登录机构或个人账号（不可静态打包源码进闭源工程）
- 可选安装 Zotero 7+、Pandoc（配合 GB/T 7714 Numeric CSL）及 LibreOffice（PPT 质检）

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
{
  "mcpServers": {
    "paper-search-mcp": {
      "command": "uvx",
      "args": ["paper-search-mcp"]
    }
  }
}

# 可选 GB/T 7714 Pandoc 渲染：
# pandoc draft.md --citeproc --csl=china-national-standard-gb-t-7714-2015-numeric.csl -o output.docx
```

## 4. 合规与物理安全核查项

- 保持 `paper-search-mcp` 的 Sci-Hub 相关配置关闭，杜绝版权违规获取。
- 严格禁止模型凭记忆杜撰参考文献或虚构实验数据与引用数量。
- GPL-3.0/AGPL-3.0 第三方本地服务仅由用户独立进程运行，不集成打包或用于批量采集。

## 5. 已排除的过时或高风险方案

- 各类知网自动打码脚本与批量爬虫（触及 IP 封禁与版权风险）
- 任何 Sci-Hub 通道及全量加载 177 项无关学科技能的低效配置

## 6. 交付产物检验清单

- [ ] 所有引用条目均可在检索记录或用户提供题录中找到真实来源与 DOI
- [ ] GB/T 7714 作者截断、标点符号（半角/全角）与类型标识全部合规
- [ ] 答辩 PPT 页数在 12~18 页区间，单页核心文字<=80 字且无排版遮挡
