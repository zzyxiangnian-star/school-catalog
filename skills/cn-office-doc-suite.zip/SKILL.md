---
name: "中文办公文档与公文精排流程"
description: "统一调度文档解析、中文公文规范、公式表格核验与版面转图自检"
---

# 办公文档助手 — 中文办公文档与公文精排流程

## 定位与适用范围

串联 anthropics 官方文档技能与 markitdown-mcp、excel-mcp-server，为中文 Word 公文、汇报 PPT、公式型 Excel 与 PDF 提供全本地解析、规范生成与渲染复核。

- **归属 Bot**：`office-doc-assistant`（分类：`documents`）
- **协同目录技能**：docx, pptx, xlsx, pdf
- **关联推荐 MCP 插件**：markitdown-mcp, excel-mcp-server

## 核心开源工具栈（国内高可用）

- anthropics/skills (`skills/docx`, `pptx`, `xlsx`, `pdf`) — Apache-2.0（2026-11 PR #2146 转开源）
- microsoft/markitdown (`markitdown-mcp`) — MIT，纯本地多格式转 Markdown
- haris-musa/excel-mcp-server — MIT（v2.3.3），内置 479 个 Excel 公式引擎
- lewis-hui1202/WPS-AI — MIT（可选国产 WPS MCP 加载项）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- Python 3.10+ 与 `uv`（国内 PyPI 镜像直装，无需独立显卡与 API Key）
- 版面视觉自检需本机安装 LibreOffice（`soffice --headless --convert-to pdf`）与 Poppler（`pdftoppm -png`）
- 配置 `excel-mcp-server` 时务必通过 `EXCEL_FILES_PATH` 或 `--allow-dir <工作目录>` 限定读写边界

## 标准执行 SOP

1. 目录与权限检查：确认目标读写目录在允许范围内，缺失时停下并提示用户授权工作目录。
2. 结构化解析：调用 `markitdown-mcp` 读取来稿或旧文档，理清章节、表格与待改动范围；敏感文档禁用云端 Azure OCR。
3. 中文排版生成：生成 Word 公文/报告时注入中文版式规范（仿宋_GB2312 或微软雅黑、行距 28 磅、首行缩进 2 字符）。
4. 公式表格核验：使用 `excel-mcp-server` 的 `write_range` / `format_range` 写入，并用内置公式引擎检查 `#REF!`、`#DIV/0!`、`#VALUE!`。
5. 渲染视觉自检：导出 PPT/PDF 后调用 LibreOffice 转 PDF、Poppler 转 PNG，核查中文断行、文本框遮挡与表格溢出并自动修正。
6. 交付汇报：输出成品绝对路径、改动条目摘要与校验结果清单。

## 安全合规红线与执业边界

- 严格遵守最小目录权限（`--allow-dir` / `EXCEL_FILES_PATH`），不读取授权外文件。
- 默认禁用 `--allow-vba-write`，杜绝生成带宏的工作簿。
- 敏感企业文件全程本地离线解析，禁止回传外部云端 OCR。

## 已明确排除项目

- `GongRzhe/Office-Word-MCP-Server`（已于 2026-03-03 归档，停止维护）
- `GongRzhe/Office-PowerPoint-MCP-Server`（已于 2026-03-03 归档，停止维护）

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
