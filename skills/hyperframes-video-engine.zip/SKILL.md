---
name: hyperframes-video-engine
description: 以确定性代码生成 1080p 视频的完整工程 SOP：优先采用 heygen-com/hyperframes HTML-to-Video 引擎，兼容 remotion-dev/skills 与 hypit-ai/hypit 批量克隆方案；覆盖环境预检、分镜编排、#03 3D 资产与 #22 节拍音效卡点编码、4/4 关键帧截图质检及 MP4 渲染交付。
---

# 程序化视频确定性引擎 SOP（`hyperframes-video-engine`）

## 1. 触发条件

当用户或上游流水线提出以下任一需求时激活本技能：
- 以代码生成可复现的 1080p 宣传片、引流短视频、功能演示或数据动效视频。
- 接收 `#03` 渲染的 3D 旋转图序列/视频与 `#22` 音频卡点清单，合成 **15s 引流短视频**。
- 基于参考爆款视频结构进行批量程序化克隆或按语义锚点批量生成变体。
- 对现有 HyperFrames / Remotion 视频工程执行关键帧视觉质检、修帧与交付渲染。

---

## 2. GitHub 开源底座选型规则

| 优先级 | 开源项目 | 触发条件与职责 |
| :--- | :--- | :--- |
| **P0（默认）** | `heygen-com/hyperframes` | 所有常规确定性时间轴视频、HTML/CSS/GSAP 动效与 15s 引流短视频，默认首选此引擎 |
| **P1（兼容）** | `remotion-dev/skills` | 用户明确指定 React/TypeScript 组件化开发，或接手已有 Remotion 仓库时启用 |
| **P2（克隆）** | `hypit-ai/hypit` | 需拆解参考爆款视频并基于词级语义锚定（SVML）批量生成多套口播/混剪变体时启用 |

---

## 3. 分步执行 SOP

### Step 0：环境与依赖预检（未就绪立即停止）

开工前必须逐项验证，禁止跳过或凭记忆假定工具可用：
1. 检查运行时：`node -v`（HyperFrames 需 Node.js >= 22）、`ffmpeg -version`、`ffprobe -version`。
2. 检查引擎：`npx hyperframes doctor --json`（确认 `.ok` 为 `true`）。若启用 Remotion，检查 `npx remotion --version`。
3. 检查 `playwright` MCP：确认当前会话已挂载 `playwright` 工具用于页面/帧截图审校。

**缺失处理铁律**：若任一检查失败，一次性向用户输出缺失组件名称、实际报错摘要与标准安装/配置命令，随后**停止执行**，绝不假装完成渲染。

### Step 1：上游素材校验与分镜脚本编排

1. 核对需求参数：目标画幅（`1920x1080` 横屏 或 `1080x1920` 竖屏）、帧率（默认 `30fps`）、总时长（如 `15.0s`）。
2. 若涉及跨 Bot 协同，按第 4 节契约校验 `#03` 与 `#22` 交付文件的存在性及 SHA-256 哈希。
3. 编写分镜表（镜头序号、起止时间、对应音频拍点 `beats_sec`/`drops_sec`、视觉层结构、文案与入场动效），优先以时间轴推进节奏而非静态 PPT 翻页。

### Step 2：确定性时间轴编码与音画卡点

**HyperFrames 模式（默认）**：
1. 初始化工程：`npx hyperframes init <project-dir>`（已有工程则先 `npx hyperframes timeline --json` 读取现存结构）。
2. 在 `index.html` 与子合成（`data-composition-src`）中使用 `data-duration`、`data-start`、`class="clip"` 声明确定性时间轴；所有动画必须 seek-safe（禁止不可控 `setTimeout`/`requestAnimationFrame` 自由漂移状态）。
3. 将 `#22` 提供的 `beats.json` 关键拍点（`drops_sec`）直接映射为转场节点、缩放脉冲或 `#03` 产品旋转加速帧；文案字号与位置严格约束在平台安全区内。

**Remotion 兼容模式**：按 `remotion-dev/skills` 规范使用 `useCurrentFrame()`、`spring()`/`interpolate()` 驱动逐帧确定性渲染，严禁依赖实时时钟。

**Hypit 批量克隆模式**：按 `hypit-ai/hypit` 流程从参考视频提取分镜与音频效果蓝图，通过语义锚定（SVML）绑定文字/B-roll 层并生成变体配置。

### Step 3：4/4 关键帧截图质检门禁（explainroo 对标标准）

渲染终版前必须完成四维度硬性核验（目标约 2.0 分钟闭环内完成 4/4 全通过）：
1. 运行静态与seek门禁：`npx hyperframes lint` 与 `npx hyperframes check --snapshots`。
2. 抽取至少 4 个关键时间点截图（`npx hyperframes snapshot --at <t0>,<drop1>,<mid>,<end>` 或通过 `playwright` MCP 在对应 seek 时间点截图）：
   - **Check 1（首帧）**：`t=0s` 字体、图片、3D 首帧全部加载完毕，无白屏/闪烁/默认占位符。
   - **Check 2（卡点同步）**：重拍节点 `drops_sec` 画面切换/视觉高光与节拍精确重合（偏差 ≤ ±1 帧）。
   - **Check 3（安全区与对比度）**：标题、卖点标签、字幕无遮挡、无溢出裁切、背景对比度清晰。
   - **Check 4（尾帧收束）**：末帧定格完整（如 CTA/品牌标识），无中途黑屏或音频截断。
3. 任一项未通过（`< 4/4`）必须定位修改代码并重新抽帧复检，严禁带病进入终版渲染。

### Step 4：终版 1080p MP4 渲染与流校验

1. 确认质检 `4/4` 通过后执行终版编码：
   - HyperFrames：`npx hyperframes render --quality delivery --output dist/promo_15s_1080p.mp4`
   - Remotion：`npx remotion render <CompositionId> dist/out.mp4 --codec h264`
2. 执行物理验证：
   - `ffprobe -v error -show_format -show_streams dist/promo_15s_1080p.mp4`（确认宽/高为 `1920x1080` 或 `1080x1920`、时长与设定一致、音视频流均存在且文件非空）。
   - 计算输出文件 SHA-256 校验值，连同 4 张质检截图一并生成 `delivery_manifest.json`。

---

## 4. 跨 Bot 协同接口契约（15s 引流短视频流水线）

### 4.1 上游输入契约

| 上游 Bot | 交付目录/文件 | 强制格式与单位规范 | 校验要求 |
| :--- | :--- | :--- | :--- |
| **#03（Blender/3D 渲染）** | `assets/3d/asset_manifest.json` + 渲染图序列或透明通道视频 | PNG RGBA 序列或 MP4/WebM，分辨率 `>=1080p`（`1920x1080` / `1080x1920` / `1080x1080`），恒定帧率 `30fps` 或 `60fps` | 核对文件数/总帧数与 manifest 一致，校验 SHA-256，缺帧立即退回 #03 |
| **#22（Ableton 音效）** | `assets/audio/beats.json` + 音频母带 | `48kHz` WAV 或 `320kbps` MP3，总时长精确匹配 `15.0s`（误差 ≤50ms），含 `bpm`、`beats_sec`、`drops_sec` 数组 | 核对 `ffprobe` 时长与响度字段，校验 SHA-256，缺 `drops_sec` 时只报错退回不盲猜 |

### 4.2 下游交接产物契约

向用户或下游运营/审批 Bot 交付统一打包产物：
- `dist/promo_15s_1080p.mp4`：1080p H.264 + AAC 成品短视频。
- `qc/frame_01..04_*.png`：4 张关键帧质检截图证据。
- `delivery_manifest.json`：含成片分辨率、fps、精确时长、SHA-256 哈希、上游 `#03`/`#22` 输入引用哈希及 `4/4` 质检通过标记。

---

## 5. 禁止越界事项

- 绝不在未运行 `doctor`、`check` 与 `ffprobe` 的情况下向用户汇报“渲染成功”或“参数无误”。
- 绝不擅自修改或覆盖上游 `#03`/`#22` 原始文件；所有裁切、调速、混音均通过合成工程引用完成。
- 绝不伪造 API Token、虚假下载第三方无授权素材，或硬编码不可达的远程外链作为视频底图。
- 绝不跳过 `4/4` 关键帧质检直接交付未预览的 MP4 文件。
