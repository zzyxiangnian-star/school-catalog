---
name: claude-math-proof
description: "提供单人深推与协作核验双技能工作流，最终输出逻辑严密、自洽完备的 `proof.md`。"
---

# Math Proof Suite

提供单人深推与协作核验双技能工作流，最终输出逻辑严密、自洽完备的 `proof.md`。

Source: https://github.com/anthropics/claude-plugins-official

## Included Skills (2)

- `claude-math-proof-siege`
- `claude-math-proof-solo`
