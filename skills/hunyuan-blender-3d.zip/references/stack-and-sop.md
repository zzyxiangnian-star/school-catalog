# 3D 建模助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- ahujasid/mcp-for-blender — MIT（原 blender-mcp，Blender >= 3.0 插件联动）
- 腾讯云混元生 3D 官方 API（国内直连，人民币按量计费，免本地 GPU）
- RobLe3/cc-blender-skill — MIT（链式 Blender 操作规范参考）

## 2. 本机前置准备

- 本机安装 Blender >= 3.0 与 uv，运行 `uvx mcp-for-blender install-addon` 并启用插件
- 务必配置 `BLENDER_MCP_SAFE_MODE=1` 与 `BLENDER_HOST=localhost`，仅监听 `127.0.0.1:9876`
- 使用云端生 3D 需开通腾讯云混元生 3D 并自备 `TENCENTCLOUD_SECRET_ID` / `TENCENTCLOUD_SECRET_KEY`

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
{
  "mcpServers": {
    "blender": {
      "command": "uvx",
      "args": ["--python", "3.11", "mcp-for-blender"],
      "env": {
        "BLENDER_HOST": "localhost",
        "BLENDER_PORT": "9876",
        "BLENDER_MCP_SAFE_MODE": "1"
      }
    }
  }
}
```

## 4. 合规与物理安全核查项

- 强制 `BLENDER_MCP_SAFE_MODE=1` 与回环地址监听，使用最新已修复历史漏洞的 `mcp-for-blender` 版本。
- 不擅自清空用户既有 Blender 场景内容，操作前提示新建/备份 `.blend` 工程。
- 不推荐商业许可受限且已停更的本地重型推理权重包。

## 5. 已排除的过时或高风险方案

- `Tencent/Hunyuan3D-2` 与 `Hunyuan3D-2.1` 本地权重（超 12 个月未提交、需 10~29 GB 显存且带商用限制）
- `tripo-mcp`（超 12 个月未维护）

## 6. 交付产物检验清单

- [ ] 模型单位已校准为毫米（mm）且底部平贴 `Z=0` 无悬空漂浮
- [ ] 打印用途导出网格已封闭且无反向法线破洞
- [ ] 多视角截图已肉眼核验无严重融粘或细节丢失
