# 激光切割与 CNC 排版助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- mozman/ezdxf — MIT（DXF 几何体检、重线清理与精确圆弧回写）
- PaulDL-RS/spyrrow — MIT（基于 JeroenGar/sparrow 的预编译 Rust 异形排版库）
- sandraschi/inkscape-mcp — MIT（可选外置 Inkscape >= 1.2 矢量化与文字转曲服务）
- DerChris2011/Lightburn_MCP — MIT（可选 LightBurn 2.2+ 用户外置桥梁，不含排版需搭 spyrrow）

## 2. 本机前置准备

- 本机安装 Inkscape >= 1.2、Python >= 3.11 与 uv，并安装 `pip install "ezdxf[draw]" spyrrow`
- 全流程运行在本地多核 CPU，无需大模型联网推理或独立显卡

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
# 本地 CAD/DXF 与异形排版依赖安装：
pip install "ezdxf[draw]" spyrrow

# 如挂载可选 Inkscape MCP（需先独立安装 Inkscape >= 1.2 并克隆仓库）：
# uv --directory <inkscape-mcp仓库路径> run inkscape-mcp
```

## 4. 合规与物理安全核查项

- 强拦截激光禁切物料：PVC、含氯高分子及聚碳酸酯（PC）严禁生成切割参数，明确解释剧毒氯气与火灾隐患。
- 清晰提示 DXF 不包含 CNC 安全高度（Z Safe Height）与压板夹具坐标，必须在 CAM 模拟后方能加工，严禁自动化点火。

## 5. 已排除的过时或高风险方案

- `Jack000/Deepnest`（8 年前停更且缺乏可用 CLI）
- `Jack000/SVGnest`（长期停更的纯浏览器前端工具）

## 6. 交付产物检验清单

- [ ] 已完成加工材质安全性确认（排除 PVC、含氯塑料与聚碳酸酯）
- [ ] 已清除重合切割线并完成 `CUT_INNER` / `CUT_OUTER` / `ENGRAVE` 图层隔离
- [ ] 输出保留圆弧的 DXF、带利用率预览 PNG 图及明确的 CAM 仿真复核提醒
