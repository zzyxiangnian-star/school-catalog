---
name: operations
description: "Optimize business operations across vendor management, process documentation, change management, capacity planning, and compliance tracking."
---

# Operations

Optimize business operations across vendor management, process documentation, change management, capacity planning, and compliance tracking.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (9)

- `operations-capacity-plan`
- `operations-change-request`
- `operations-compliance-tracking`
- `operations-process-doc`
- `operations-process-optimization`
- `operations-risk-assessment`
- `operations-runbook`
- `operations-status-report`
- `operations-vendor-review`
