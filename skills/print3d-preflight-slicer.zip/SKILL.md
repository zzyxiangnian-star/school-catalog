---
name: "3D 打印几何体检与切片方案流程"
description: "基于 trimesh 检测水密性、薄壁与悬垂角，生成安全切片文件与参数报告"
---

# 3D 打印预检与切片助手 — 3D 打印几何体检与切片方案流程

## 定位与适用范围

纯本地 CPU 驱动 trimesh 执行尺寸核对、破洞修复、>45° 悬垂分析及 2 倍喷嘴薄壁预警，联动用户外置 OrcaSlicer 输出 .gcode.3mf（禁止自动物理下发打印）。

- **归属 Bot**：`print3d-preflight-slicer-bot`（分类：`design`）
- **协同目录技能**：无（本技能独立承担全流程）
- **关联推荐 MCP 插件**：filesystem

## 核心开源工具栈（国内高可用）

- mikedh/trimesh — MIT（v5.2.1，纯 Python 网格包围盒、水密性与壁厚计算）
- OrcaSlicer/OrcaSlicer — AGPL-3.0（v2.5+ 内置本机 MCP，外置独立安装）
- OrcaSlicer/orcaslicer-mcp-skills — AGPL-3.0（官方配套外置工具说明参考）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- 从官方渠道（GitHub Releases / 官网）在本机独立安装 OrcaSlicer >= 2.5，并在 `Preferences > General > AI features` 按需启用内置 MCP
- Python 环境安装 `pip install trimesh[easy]`（纯 CPU，免独立显卡）

## 标准执行 SOP

1. 读入与尺度校验：用 `trimesh.load()` 解析网格并打印包围盒与面数，对照目标打印机构建体积防尺度错乱。
2. 水密与法线检查：验证 `is_watertight` 与外法线方向，遇破洞提示修复或在切片前调用简单修补。
3. 悬垂与支撑评估：计算面法线与 `-Z` 夹角，量化 `>45°` 悬垂面积并推荐底面旋转方案与树状支撑参数。
4. 射线法薄壁检测：抽样估算局部壁厚，低于 `2 × 喷嘴直径` 的单层薄片给予明显加厚告警。
5. 外部切片与热安全核对：按用户确认的机型与线材输出 `.gcode.3mf`，读取耗材克数、时长与峰值喷嘴/热床温度交用户复核。

## 安全合规红线与执业边界

- 严格禁用任何物理端 `start_print` 自动执行，只产出静态预检报告和 `.gcode.3mf` 文件。
- 提醒用户下载 OrcaSlicer 认准官方域名与 GitHub Releases 谨防仿冒钓鱼网站。
- 严格遵循 AGPL-3.0 边界，仅作外部进程联动。

## 已明确排除项目

- `PyMeshLab`（更新停滞且 Qt/C++ 体积过重，优先使用纯 Python `trimesh`）
- 任何默认启用物理机直连自动开打的不受控打印插件

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
