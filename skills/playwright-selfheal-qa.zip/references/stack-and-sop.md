# 技术栈底座与交付检验参考（`stack-and-sop.md`）

## 1. 核心开源仓库与关联生态

| 组件类别 | 标识 / 仓库 | 定位与职责 |
| --- | --- | --- |
| 核心浏览器 MCP 底座 | `microsoft/playwright-mcp` | 微软官方 Playwright MCP Server，基于浏览器无障碍树（Accessibility Tree）提供确定性页面快照与操作能力，避免脆弱视觉坐标或深层 XPath 依赖 |
| 关联技能 | `playwright` | 目录既有 Playwright 基础自动化与脚本执行技能 |
| 关联诊断 MCP | `chrome-devtools` | 辅助采集精细控制台错误堆栈、网络请求详情、Timing 与运行时状态 |
| 本地测试引擎 | `@playwright/test`（Playwright CLI） | 执行 `*.spec.ts`、生成 `trace.zip`、HTML 报告与多状态断言 |

---

## 2. 典型 MCP 与 CLI 配置模板

### 2.1 `microsoft/playwright-mcp` 标准 MCP 配置（JSON）

以下为本地 Stdio 模式常见配置参考（具体支持参数以本机 `npx @playwright/mcp@latest --help` 输出为准）：

```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": [
        "-y",
        "@playwright/mcp@latest",
        "--headless"
      ]
    }
  }
}
```

如需复用只读登录态或留存轨迹，可在确认路径存在后按需附加官方 CLI 参数（以当前安装版本文档为准）：

```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": [
        "-y",
        "@playwright/mcp@latest",
        "--headless",
        "--storage-state=./.auth/staging-user.json",
        "--output-dir=./artifacts/playwright-mcp"
      ]
    }
  }
}
```

### 2.2 关联 `chrome-devtools` MCP 参考配置

当需要深挖网络响应体、Console SourceMap 或性能卡顿指标时，可并列挂载：

```json
{
  "mcpServers": {
    "chrome-devtools": {
      "command": "npx",
      "args": [
        "-y",
        "chrome-devtools-mcp@latest"
      ]
    }
  }
}
```

### 2.3 本地环境前置检测与 Playwright Test CLI 常用命令

```bash
# 1. 检测 Node 与 Playwright CLI 是否就绪
node -v
npx playwright --version

# 2. 若浏览器二进制缺失，引导用户安装 Chromium（仅安装必要浏览器）
npx playwright install chromium

# 3. 执行目标 E2E 用例并强制保留 Trace 与失败截图
npx playwright test tests/e2e/checkout.spec.ts --project=chromium --trace=on --screenshot=only-on-failure

# 4. 仅运行带 @smoke 标签的工作日冒烟集
npx playwright test --grep @smoke --reporter=json,html

# 5. 查看生成的可交互 Trace 证据包
npx playwright show-trace test-results/<run-id>/trace.zip
```

### 2.4 语义定位与自愈优先级矩阵

自愈修复与新编测试脚本严格按以下优先级选取定位器：

| 优先级 | Playwright 定位器 | 适用场景 | 禁止替代项 |
| --- | --- | --- | --- |
| P0（首选） | `page.getByRole(role, { name })` | 按钮、链接、标题、表单控件、Tab、弹窗 | 禁止 `/html/body/...` 绝对路径 |
| P1 | `page.getByLabel(...)` / `getByPlaceholder(...)` | 输入框、选择框、复选框 | 禁止依赖 `.css-1a2b3c` 哈希类名 |
| P2 | `page.getByText(...)` | 明确且非动态拼接的语义文本锚点 | 禁止脆弱 `nth-child(7)` 结构索引 |
| P3 | `page.getByTestId(...)` | 无唯一可读文本的复合图标或画布容器 | 禁止依赖易变内联样式属性 |

---

## 3. 交付产物检验清单（Delivery Checklist）

在输出最终 `PASS` / `HEALED` / `FAIL` 结论前，逐项核对：

- [ ] **环境前置已核验**：已实测 `playwright` MCP 或本地 `npx playwright` 可用，且目标 URL / 本地端口真实连通；未就绪时已按 `BLOCKED` 终止，未编造任何通过结果。
- [ ] **无脆弱定位器**：新增或自愈后的 `*.spec.ts` 中不含绝对 XPath（`//div[3]/span[2]`）与构建随机哈希类名。
- [ ] **自愈边界合规**：所有自愈修改均附带修改前后无障碍树语义依据；未篡改、未删除任何业务结果断言（如价格、权限、提交回执校验）。
- [ ] **控制台与网络已捕获**：报告中明确列出测试期间的 `console.error`、`pageerror` 及 HTTP `4xx/5xx`/超时请求统计（若为 `0` 需明确标注 `0 异常`）。
- [ ] **Trace 与截图真实落盘**：报告引用的 `trace.zip`、`screenshots/*.png` 与 `smoke-summary.json` 路径均来自本次真实运行产物，可供直接打开复核。
- [ ] **安全护栏未越界**：测试全程未使用真实客户敏感数据，未在生产环境执行不可逆写操作或真实支付。
