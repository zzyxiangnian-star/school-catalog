# 手机真机跨 App 操控参考栈与检验清单（`mobile-gui-automation`）

## 1. 核心 GitHub 开源底座清单

| 仓库 | 定位与机制 | 支持平台 | 核心能力与适用场景 |
| :--- | :--- | :--- | :--- |
| [mobile-next/mobile-mcp](https://github.com/mobile-next/mobile-mcp) | 基于 Model Context Protocol (MCP) 的移动端真机/模拟器控制服务（npm 包：`@mobilenext/mobile-mcp`） | Android (ADB)、iOS (Xcode / WebDriverAgent) | 优先读取原生无障碍元素树（Accessibility Tree）实现快速、确定性点击/输入/滑动，兼顾截图、App 启停、DeepLink 跳转与崩溃日志采集。 |
| [X-PLUG/MobileAgent](https://github.com/X-PLUG/MobileAgent) | 阿里开源多模态移动设备 GUI 智能体（Mobile-Agent-v2 / Mobile-Agent-E） | Android / HarmonyOS（≤4，通过 ADB + ADB Keyboard） | 基于视觉大模型的规划-决策-反思（Planning-Decision-Reflection）三智能体协同，解决无障碍树缺失、微信小程序嵌套、复杂跨 App 视觉导航与误操作自纠偏。 |

---

## 2. 典型 MCP 与 CLI / 环境配置模板

### 2.1 `mobile-mcp` 标准 MCP 客户端配置

在 MCP 客户端配置文件（如 `mcp.json`）中挂载：

```json
{
  "mcpServers": {
    "mobile-mcp": {
      "command": "npx",
      "args": [
        "-y",
        "@mobilenext/mobile-mcp@latest"
      ]
    }
  }
}
```

Claude Code CLI 快速注册命令：

```bash
claude mcp add mobile -- npx -y @mobilenext/mobile-mcp@latest
```

### 2.2 本地前置环境检查命令（Android / iOS）

**Node.js 与 Android ADB 校验：**

```bash
# 1. 要求 Node.js >= v20
node -v

# 2. 检查 ADB 与已授权设备（状态须为 device，而非 unauthorized/offline）
adb version
adb devices -l

# 3. 检查是否已安装并启用 ADB Keyboard（用于中文及复杂文本稳定输入）
adb shell ime list -a | grep -i adb
# 若需切换默认输入法为 ADB Keyboard（按实际包名确认）
adb shell ime set com.android.adbkeyboard/.AdbIME
```

**iOS 真机 / 模拟器前置要求（macOS）：**
- 已安装 Xcode 与 Xcode Command Line Tools（`xcode-select -p`）。
- 模拟器已启动，或 iOS 真机已开启「开发者模式」、信任当前主机且配置可运行的 WebDriverAgent（WDA）。

### 2.3 `X-PLUG/MobileAgent` 视觉策略部署模板

```bash
git clone https://github.com/X-PLUG/MobileAgent.git
cd MobileAgent
pip install -r requirements.txt
```

在本地环境变量或运行配置中填入用户自己的多模态视觉模型 API 凭证（严禁硬编码或提交至仓库）：

```bash
export VLM_API_BASE="<用户自备的多模态模型兼容接口地址>"
export VLM_API_KEY="<用户自备的 API Key>"
export ADB_PATH="adb"
```

### 2.4 媒体文件推送与相册刷新模板（接收 #08 视频 Bot 成片）

```bash
# 1. 校验本地成片 SHA256 与时长（Windows PowerShell / Linux/macOS）
# sha256sum ./deliverables/clip_15s.mp4
# ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 ./deliverables/clip_15s.mp4

# 2. 推送至备用机相册目录
adb -s <DEVICE_ID> push ./deliverables/clip_15s.mp4 /sdcard/DCIM/Camera/clip_15s.mp4

# 3. 触发 Android 媒体扫描，确保小红书/抖音/闲鱼相册选择器立即可见
adb -s <DEVICE_ID> shell am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:///sdcard/DCIM/Camera/clip_15s.mp4
```

---

## 3. 常见移动端 App 实战要点与防风控边界

| 目标 App / 场景 | 推荐感知策略 | 关键注意事项与风控熔断点 |
| :--- | :--- | :--- |
| **小红书（图文/15s 短视频发布）** | 无障碍树为主 + 视觉策略识别封面/滤镜/标签按钮 | 严禁高频连续发布；标题与正文若通过 `mobile_type_keys` 输入中文异常，优先启用 ADB Keyboard；发布前强制截图确认可见范围与话题标签；遇滑块/实名校验立即 `NEED_HUMAN`。 |
| **抖音（短视频发布/日常互动）** | 无障碍树定位底部导航与发布流 + 视觉策略处理贴纸/特效弹窗 | 同上须先刷新媒体库；严禁脚本式高频点赞/关注/刷评；检测到登录异常或风控验证弹窗即刻停止。 |
| **闲鱼 / 美团** | 混合模式（商品页/订单卡片常含自定义视图，需截图辅助确认金额与状态） | 涉及到下单、支付、改价、确认收货、退款操作前，必须暂停向用户二次确认，绝不自动输入支付密码或生物核验。 |
| **微信小程序** | 视觉策略为主（WebView/Canvas 混合渲染导致部分节点在原生无障碍树中缺失） | 优先通过 `mobile_take_screenshot` 定位按钮坐标，每次点击后做一次状态截图核验页面是否实际跳转。 |
| **企业打卡 / 考勤 App** | 无障碍树定位 + 截图留证 | 严禁篡改设备 GPS 定位或绕过人脸/活体检测；仅在真机真实位置合规状态下协助点击并回传打卡结果截图。 |

---

## 4. 交付产物与执行检验清单

### 4.1 Pre-flight 门禁检查（任一项不通过则输出 `BLOCKED` 并停止）
- [ ] `mobile_list_available_devices` 返回目标设备且状态正常（Android `adb devices` 为 `device`）。
- [ ] 操作目标为指定的备用机/测试机，而非未授权的用户主力私人设备。
- [ ] 若需中文输入，Android 设备已就绪 `ADBKeyboard` 或确认 `mobile_type_keys` 可用。
- [ ] 若需视觉兜底，已确认具备截图能力与用户配置的多模态模型环境。
- [ ] 若为 #08 视频 Bot 协同任务，成片文件存在、为 `.mp4`、时长 ≤ 15s、SHA256 校验一致且含待发布文案/审批状态。

### 4.2 跨 Bot 交接验收检查
- [ ] 执行结束已保存终态结果页截图（`mobile_save_screenshot`）及关键报错现场截图。
- [ ] 若触发崩溃，已附加 `mobile_list_crashes` / `mobile_get_crash` 摘要。
- [ ] 已输出符合规范的结构化 JSON 交接回执，未伪造未观测到的发布链接或 ID。
