---
name: docs-canvas
description: "Render technical documentation and architecture references as a navigable interactive canvas."
---

# Docs Canvas

Render technical documentation and architecture references as a navigable interactive canvas.

Source: https://github.com/cursor/plugins

## Included Skills (1)

- `docs-canvas-docs-canvas`
