# 发票报销整理助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- PaddlePaddle/PaddleOCR (`paddleocr-mcp`) — Apache-2.0（PP-OCRv6 本地源直装，纯 CPU 离线）
- haris-musa/excel-mcp-server — MIT（v2.3.3，生成三页签公式报销台账）
- anthropics/skills (`skills/xlsx`, `skills/pdf`) — Apache-2.0（辅助本地校验）

## 2. 本机前置准备

- Python 3.10+ 与 uv；本地模式 `PP-OCRv6` 从国内源拉取轻量权重，纯 CPU + 4 GB+ 内存可跑，无需显卡或本地 Excel
- 按需提供企业准确抬头名称及税号；若确实需要国家税务官方接口真伪查验，须由财务人员自行配通百度智能云官方托管 OCR/验真 MCP 并控制外发权限

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
{
  "mcpServers": {
    "paddleocr": {
      "command": "uvx",
      "args": ["--from", "paddleocr-mcp[local-cpu]", "paddleocr_mcp"],
      "env": {
        "PADDLEOCR_MCP_MODEL": "PP-OCRv6",
        "PADDLEOCR_MCP_PPOCR_SOURCE": "local"
      }
    },
    "excel-mcp-server": {
      "command": "uvx",
      "args": ["excel-mcp-server", "stdio", "--allow-dir", "<你的发票目录>"]
    }
  }
}
```

## 4. 合规与物理安全核查项

- 默认全流程纯本地运行，保护企业税号、合作商往来与差旅轨迹不外泄。
- 明确标注本地 OCR 对褶皱模糊票面存在误识可能，且无在线国税查验与红冲作废识别能力，均需人工核票与财务终审。

## 5. 已排除的过时或高风险方案

- `negokaz/excel-mcp-server`（2025-07 后超 12 个月未维护）
- `z4none/rapidocr-mcp`（项目体量过小且生态不如官方飞桨 MCP 完备）

## 6. 交付产物检验清单

- [ ] 电子发票均无损提字，模糊扫描/拍照件已标注 OCR 人工复核清单
- [ ] 所有明细与汇总页使用动态 `=SUM()` / `=SUMIF()` 公式而非静态数值
- [ ] 已附上本地不具备国税验真及红冲校验能力的合规提示
