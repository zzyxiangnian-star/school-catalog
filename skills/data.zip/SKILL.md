---
name: data
description: "Write SQL, explore datasets, build visualizations and dashboards, and turn raw data into clear stakeholder insights."
---

# Data

Write SQL, explore datasets, build visualizations and dashboards, and turn raw data into clear stakeholder insights.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (10)

- `data-analyze`
- `data-build-dashboard`
- `data-create-viz`
- `data-data-context-extractor`
- `data-data-visualization`
- `data-explore-data`
- `data-sql-queries`
- `data-statistical-analysis`
- `data-validate-data`
- `data-write-query`
