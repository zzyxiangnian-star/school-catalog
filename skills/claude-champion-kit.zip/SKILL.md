---
name: claude-champion-kit
description: "7 项实用技能，帮助技术布道者组织黑客松、办公答疑与沉淀团队最佳实践。"
---

# Claude Champion Kit

7 项实用技能，帮助技术布道者组织黑客松、办公答疑与沉淀团队最佳实践。

Source: https://github.com/anthropics/claude-plugins-official

## Included Skills (7)

- `claude-champion-kit-climb`
- `claude-champion-kit-faq`
- `claude-champion-kit-hackathon`
- `claude-champion-kit-maturity`
- `claude-champion-kit-office-hours`
- `claude-champion-kit-patterns`
- `claude-champion-kit-routines`
