# 多角色辩论量化投研技术栈与执行参考（stack-and-sop）

## 1. 核心 GitHub 开源底座

| 仓库 | 定位 | 核心机制与关键模块 | 适用版本与前置条件 |
| :--- | :--- | :--- | :--- |
| [TauricResearch/TradingAgents](https://github.com/TauricResearch/TradingAgents) | 多智能体 LLM 金融投研框架（基于 LangGraph） | 通过有状态图（`TradingAgentsGraph`）编排 Analyst Team（基本面/情绪/新闻/技术）、Research Team（Bull/Bear 对抗辩论 + Lead Researcher）、Trader、Risk Management Team 与 Portfolio Manager；核心状态与路由位于 `agent_states.py`（`AgentState`、`InvestDebateState`、`RiskDebateState`）与 `conditional_logic.py`，支持 SQLite 检查点（`langgraph-checkpoint-sqlite`）与多 LLM 后端。 | Python 3.11+；需配置 LLM API Key（如 `OPENAI_API_KEY`、`ANTHROPIC_API_KEY`、`DEEPSEEK_API_KEY`、`OPENROUTER_API_KEY` 或本地 Ollama/OpenAI 兼容接口）。 |

### TradingAgents 本地安装与运行参考
```bash
git clone https://github.com/TauricResearch/TradingAgents.git
cd TradingAgents

# 建议使用 Python 3.11+ 虚拟环境
python -m venv .venv
# Windows PowerShell: .\.venv\Scripts\Activate.ps1
# Linux/macOS: source .venv/bin/activate

pip install -r requirements.txt
# 或 pip install .

# 配置环境变量
cp .env.example .env
# 在 .env 中填入 LLM Key（及可选的 FRED_API_KEY / SEC_EDGAR_USER_AGENT）

# 启动交互式 CLI 或源码入口
tradingagents
# 或
python -m cli.main
```

### TradingAgents Python SDK 最小调用模式
```python
from tradingagents.graph.trading_graph import TradingAgentsGraph
from tradingagents.default_config import DEFAULT_CONFIG

ta = TradingAgentsGraph(config=DEFAULT_CONFIG, debug=True)
state, decision = ta.propagate("NVDA", "2026-11-18")
print(decision)
```

---

## 2. 典型 MCP 插件配置模板（`.mcp.json` / 客户端配置）

以下三个 MCP Server 分别承担**深度资讯检索**、**广域网页/现货报价搜索**与**本地/企业财务及采购台账查询**。配置前请将占位符替换为真实 Key 与数据库 DSN（切勿将真实密钥提交至 Git）。

```json
{
  "mcpServers": {
    "tavily": {
      "command": "npx",
      "args": [
        "-y",
        "tavily-mcp@latest"
      ],
      "env": {
        "TAVILY_API_KEY": "tvly-YOUR_API_KEY_HERE"
      }
    },
    "brave-search": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-brave-search"
      ],
      "env": {
        "BRAVE_API_KEY": "YOUR_BRAVE_API_KEY_HERE"
      }
    },
    "dbhub": {
      "command": "npx",
      "args": [
        "@bytebase/dbhub@latest",
        "--transport",
        "stdio",
        "--dsn",
        "${DATABASE_URL}"
      ]
    }
  }
}
```

### 各数据源接入与降级说明
1. **`tavily`**：用于研报摘要、突发新闻原文提取与宏观/财报事件检索；需在 Tavily 控制台申请 `TAVILY_API_KEY`。
2. **`brave-search`**：用于补充现货大宗报价、交易所公告与跨语种舆情交叉验证；需配置 `BRAVE_API_KEY`（部分环境亦使用 `@brave/brave-search-mcp-server`）。
3. **`dbhub`**（`@bytebase/dbhub`）：支持 PostgreSQL、MySQL、SQLite 等数据源，通过只读账号的 `--dsn` 查询历史成交价、采购成本台账、库存水位与历史回测表；无实库时可用 `--demo` 参数挂载内置示例库验证连通性。
4. **严格只读原则**：为 `dbhub` 分配的数据库凭据应仅授予 `SELECT` 只读权限，防止任何误写操作影响生产账务或采购系统。

---

## 3. 交付产物检验清单（Pre-Flight & Post-Run Checklist）

在最终输出决策报告或向下游节点交接前，必须逐项核验通过以下 10 项检查：

- [ ] **前置连通性核验**：至少确认一种实时外部检索工具（`tavily` 或 `brave-search`）或本地 `TradingAgents`/数据源可用；若全部缺失，已明确报错并给出配置引导，未假装完成分析。
- [ ] **时间锚点完整**：基本面数据、现货报价、新闻舆情与报告结论均标注精确时间戳（`YYYY-MM-DD HH:MM UTC+8`）及原始来源。
- [ ] **角色一完备性**：基本面/现货供需分析员已覆盖核心量化指标（财务健康度/估值分位，或产能/库存/交期），未仅凭定性描述替代数据。
- [ ] **角色二完备性**：新闻与舆情分析员已区分事实公告与市场传闻，并标注情绪极性（正面/中性/负面）及事件时效。
- [ ] **角色三强制两轮辩论**：看多研究员与看空研究员均完成了 **Round 1 立论** 与 **Round 2 针对性反驳**，且第二轮确实回应并质询了对手第一轮的核心论据，而非各说各话。
- [ ] **角色四独立风控核算**：风控官已独立给出 `仓位/锁价上限 (%)`、`最大回撤容忍 (%)`、`硬止损/终止条件` 与 `分批触发区间`，并核算了极端不利情景下的敞口。
- [ ] **置信区间自洽**：报告给出的置信区间（如 `58%–70%`）与辩论未解分歧程度、数据完备度相匹配；当分歧过大或关键数据缺失时，风控官已触发降仓或“观望/风控否决”。
- [ ] **交接格式合规**：若涉及跨 Bot 协同或审批归档，已附带完整的标准化结构字段（`decision_id`、`action`、`max_position_or_lock_pct`、`stop_loss_trigger`、`confidence_interval` 等）。
- [ ] **合规与权限红线**：全文无任何实盘下单指令、自动交易脚本调用或“稳赚/保本”等违规承诺，并附带清晰的非持牌投研辅助免责声明。
- [ ] **定时例程静默门禁**（如处于 Routine 模式）：未配置监控清单或数据源时仅询问一次或调用 `routine_no_update`，未产生空跑与幻觉播报。
