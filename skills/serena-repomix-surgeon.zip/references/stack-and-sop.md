# Serena + Repomix 语义级代码手术参考手册

## 1. 核心 GitHub 开源底座

| 组件 | GitHub 仓库 | 核心定位 | 关键能力 |
| :--- | :--- | :--- | :--- |
| **Serena** | [`oraios/serena`](https://github.com/oraios/serena) | 基于 LSP 的语义级代码检索与编辑 MCP 工具集 | 支持 40+ 语言的 `get_symbols_overview`、`find_symbol`、`find_declaration`、`find_implementations`、`find_referencing_symbols`、`replace_symbol_body`、`insert_before_symbol`、`insert_after_symbol`、`rename_symbol`、`get_diagnostics_for_file` |
| **Repomix** | [`yamadashy/repomix`](https://github.com/yamadashy/repomix) | AI 友好的代码库压缩与全景打包工具（支持 CLI 与 MCP） | 内置 `--compress`（Tree-sitter 抽取类/函数签名与结构，大幅降低 Token）、`--include` / `--ignore` 精准过滤及 `--mcp --sandbox` 沙盒模式 |

### 常见语言对应 Language Server 参考

`serena` 依赖目标项目语言对应的标准 Language Server 提供语义解析与诊断能力，常见环境要求如下：

- **TypeScript / JavaScript**：Node.js + `typescript-language-server` / `typescript`
- **Python**：`pyright` 或 `jedi-language-server` / `python-lsp-server`
- **Rust**：`rustup component add rust-analyzer`
- **Go**：`go install golang.org/x/tools/gopls@latest`
- **C / C++**：`clangd`（项目需包含 `compile_commands.json`）
- **Java**：Eclipse JDT Language Server (`jdtls`) + JDK

---

## 2. 典型 MCP 与 CLI 配置模板

### 2.1 MCP 客户端标准配置（`mcpServers` JSON）

适用于支持标准 MCP `stdio` 协议的客户端（如 Claude Desktop、Cursor 等，请将 `/path/to/your/repo` 替换为实际仓库绝对路径）：

```json
{
  "mcpServers": {
    "serena": {
      "command": "uvx",
      "args": [
        "--from",
        "git+https://github.com/oraios/serena",
        "serena",
        "start-mcp-server",
        "--context",
        "ide-assistant",
        "--project",
        "/path/to/your/repo"
      ]
    },
    "repomix": {
      "command": "npx",
      "args": [
        "-y",
        "repomix",
        "--mcp",
        "--sandbox",
        "/path/to/your/repo"
      ]
    }
  }
}
```

### 2.2 Claude Code CLI 快速注册命令

```bash
# 添加 Serena LSP MCP（绑定当前项目目录）
claude mcp add serena -- uvx --from git+https://github.com/oraios/serena serena start-mcp-server --context ide-assistant --project "$(pwd)"

# 添加 Repomix MCP（启用沙盒限制访问当前目录）
claude mcp add repomix -- npx -y repomix --mcp --sandbox "$(pwd)"
```

### 2.3 常用 Repomix 与 Git 手术辅助 CLI 命令

```bash
# 1. 使用 Tree-sitter 压缩模式导出核心源码骨架（大幅节省上下文）
npx -y repomix --compress --include "src/**,packages/**" --ignore "**/*.test.*,**/dist/**"

# 2. 手术前检查工作区干净度
git status --short

# 3. 手术后统计变更范围与逐行复核
git diff --stat
git diff --unified=3
```

---

## 3. 交付产物检验清单（Surgical Checklist）

在宣布任何代码手术完成（`DONE`）前，必须逐项核验并附带真实证据：

- [ ] **环境与基线就绪**：确认手术基于已知 Git 提交基线进行，无混杂无关脏修改。
- [ ] **全景摸底完成**：已通过 `repomix`（优先压缩骨架模式）明确相关目录、配置与模块依赖边界。
- [ ] **引用点全量闭环**：已通过 `serena` 的 `find_referencing_symbols` 枚举被修改符号的所有调用点/实现类，且所有受影响调用方已同步适配或确认兼容。
- [ ] **手术切口最小化**：所有改动均通过符号级精准替换完成，未发生整文件重写、无关代码格式化或注释误删。
- [ ] **静态与编译诊断零新增错误**：已调用 `get_diagnostics_for_file` 或项目类型检查工具（如 `tsc --noEmit`、`pyright`、`cargo check`、`go vet`），无新增 Error。
- [ ] **单元测试/回归验证通过**：已运行受影响模块的真实测试命令并记录精确的通过/失败用例数。
- [ ] **最小 Git Diff 复核**：已联动 `change-review` 审阅 `git diff` 全量片段，确认无调试残留（`console.log`/临时注释）、无越界改动与硬编码敏感信息。
