---
name: "中国大陆发票报销识别与查重流程"
description: "PP-OCRv6 纯 CPU 离线提字段、严校税号价税、精准模糊查重并生成公式表"
---

# 发票报销整理助手 — 中国大陆发票报销识别与查重流程

## 定位与适用范围

组合飞桨本地离线 PaddleOCR MCP 与 excel-mcp-server，优先无损读取电子票 PDF/OFD，精准/模糊双维度查重并生成带动态 SUM 公式的报销工作簿。

- **归属 Bot**：`invoice-reimbursement-bot`（分类：`data-analytics`）
- **协同目录技能**：xlsx, pdf
- **关联推荐 MCP 插件**：paddleocr-mcp, excel-mcp-server

## 核心开源工具栈（国内高可用）

- PaddlePaddle/PaddleOCR (`paddleocr-mcp`) — Apache-2.0（PP-OCRv6 本地源直装，纯 CPU 离线）
- haris-musa/excel-mcp-server — MIT（v2.3.3，生成三页签公式报销台账）
- anthropics/skills (`skills/xlsx`, `skills/pdf`) — Apache-2.0（辅助本地校验）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- Python 3.10+ 与 uv；本地模式 `PP-OCRv6` 从国内源拉取轻量权重，纯 CPU + 4 GB+ 内存可跑，无需显卡或本地 Excel
- 按需提供企业准确抬头名称及税号；若确实需要国家税务官方接口真伪查验，须由财务人员自行配通百度智能云官方托管 OCR/验真 MCP 并控制外发权限

## 标准执行 SOP

1. 合规与基准准备：确认《公司开票信息》（全称/税号）及目录访问授权。
2. 分层无损/离线提取：PDF/OFD 优先走 `pypdf`/`pdfplumber` 无损提取文本；照片与扫描件调用本地离线 `paddleocr-mcp` 识字。
3. 发票要素结构化：解析发票代码、20 位全电发票号码、日期、买卖方抬头及税号、不含税价、税额与价税合计。
4. 抬头与账目复核：逐张核查购买方抬头错字/个人抬头/税号偏差、有效期超期，并验证 `不含税 + 税额 == 价税合计`（±0.01 元）。
5. 双重精准/模糊查重：同时基于 `(发票代码, 号码)` 精准判重，并基于 `(日期 + 销售方 + 金额)` 拦截 PDF 原票与手机截图重复贴票。
6. 动态公式台账输出：用 `excel-mcp-server` 写入三页签 `.xlsx`（明细、异常预警、分类汇总），严格采用 `=SUM()`/`=SUMIF()` 而非硬编码总价。

## 安全合规红线与执业边界

- 默认全流程纯本地运行，保护企业税号、合作商往来与差旅轨迹不外泄。
- 明确标注本地 OCR 对褶皱模糊票面存在误识可能，且无在线国税查验与红冲作废识别能力，均需人工核票与财务终审。

## 已明确排除项目

- `negokaz/excel-mcp-server`（2025-07 后超 12 个月未维护）
- `z4none/rapidocr-mcp`（项目体量过小且生态不如官方飞桨 MCP 完备）

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
