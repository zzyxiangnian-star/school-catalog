---
name: uitars-desktop-gui
description: 结合 bytedance/UI-TARS-desktop 视觉定位能力与 Windows MCP / Desktop Commander，对无 API/CLI 的闭源桌面软件（ERP、财务客户端、3D 切片软件、微信桌面端等）执行「截图观测 → 坐标规划 → 单步动作 → 复核截图」闭环操控，并在删除、支付或对外发送前强制暂停二次确认。
---

# UI-TARS 桌面视觉操控（`uitars-desktop-gui`）

## 1. 触发条件与适用边界

当任务符合以下任一条件时激活本技能：
- 需要操作的软件**无公开 REST API、无 CLI 工具、且非标准 Web 页面**（如传统 ERP 客户端、桌面财务/税控软件、3D 打印切片软件 Bambu Studio / OrcaSlicer / Cura、微信/企业微信桌面端、工业上位机等）。
- 需要在多个异构桌面软件之间搬运状态、导入导出本地文件或触发固定 UI 流程。
- 上游自动化流水线（如 C2M 3D 打印无人车间、自动对账流水线）已生成本地产物，需要最后一步通过桌面端切片、填单或导出报表。

**不适用场景（应退回或转交）：**
- 目标系统已有官方 API、CLI 或纯浏览器页面（优先交由 API/CLI 或浏览器类 Bot 处理，严禁舍近求远使用像素点击）。
- 目标界面处于图形验证码、人脸核验、U 盾物理按键或系统锁屏状态（直接报 `BLOCKED` 请人工介入）。

---

## 2. GitHub 开源底座与关联工具栈

- **核心 GitHub 开源底座**：`bytedance/UI-TARS-desktop`（提供桌面视觉定位 VLM 推理、`@agent-tars/cli` 及混合屏幕算子）。
- **关联 MCP 插件**：
  - `windows-mcp`（`CursorTouch/Windows-MCP`）：执行显示器枚举（`DisplayInventory`）、屏幕截图（`Screenshot`）、UI 树快照（`Snapshot`）、应用切换（`App`）、鼠标点击/移动/滚动（`Click`、`Move`、`Scroll`）、键盘输入与快捷键（`Type`、`Shortcut`）、剪贴板读写（`Clipboard`）与等待（`Wait`、`WaitFor`）。
  - `desktop-commander`（`wonderwhy-er/DesktopCommanderMCP`）：负责输入输出文件的磁盘存在性核验、`SHA-256` 哈希计算、进程巡检，以及 `.xlsx`/`.csv` 等导出结果的后验解析。

---

## 3. 分步执行 SOP

### Step 0：环境与前置就绪自检（未就绪立即停止）
1. **工具连通性检查**：确认 `windows-mcp` 已挂载且可返回屏幕信息（`DisplayInventory` / `Screenshot`）；若需本地文件/进程校验，确认 `desktop-commander` 或系统终端可用；若依赖外部 UI-TARS VLM 推理端点，确认配置就绪。
2. **缺失报错规则**：若任一必需 MCP 未连接、系统处于锁屏/黑屏状态或目标桌面软件未安装，**立即停止执行**，一次性向用户输出缺失组件、安装/启动命令与修复步骤，绝不假装操作成功。
3. **屏幕与窗口对齐**：记录当前主副屏分辨率与 DPI 缩放比例（推荐在 100% 缩放下操作或确保坐标换算一致），使用 `App` 或任务栏激活目标软件窗口并最大化/置顶，避免遮挡。
4. **输入文件校验**：若任务携带本地输入文件，先确认路径存在、字节数非零，并计算 `SHA-256` 校验码与上游契约比对。

### Step 1：截图观测与双通道定位
1. 调用 `Screenshot` 获取当前全屏或目标窗口清晰画面；必要时辅以 `Snapshot` 读取可访问性 UI 控件树作为坐标交叉验证。
2. 将截图与当前单步子目标送入 UI-TARS 视觉定位模型（或结合控件树边界框），确定唯一目标元素的中心像素坐标 `(x, y)` 与预期触发后的界面变化特征。

### Step 2：单步原子动作执行
1. **严守单步原则**：每轮循环**只执行 1 个原子动作**（如：点击某菜单、双击文件输入框、粘贴路径、按下 `Enter` 或预设快捷键）。禁止一次性连发多步盲点脚本。
2. **中文与路径输入规范**：涉及中文文本或含空格/特殊字符的 Windows 路径时，优先写入 `Clipboard` 后通过 `Shortcut`（`Ctrl+V`）粘贴，避免输入法中英文状态错乱导致字符丢失。

### Step 3：复核截图与异常处理
1. 动作后视软件响应速度执行短暂 `Wait` / `WaitFor`，随即再次调用 `Screenshot` 进行复核。
2. **状态判定**：
   - **符合预期**：界面已切换至目标状态（如文件已加载、数值已更新、导出进度完成），进入下一单步。
   - **意外弹窗 / 焦点丢失**：识别弹窗意图（如单位换算提示、覆盖警告、登录过期）；若属非高危常规确认则按规处理，否则立即冻结上报。
   - **坐标未命中**：禁止原坐标盲目连点，重新计算元素坐标并最多微调重试 1 次；连续 2 次复核异常立即终止并输出 `BLOCKED` 现场截图。

### Step 4：高危动作强制拦截闸门（L3 Gate）
在执行以下任一不可逆高危操作**之前**，必须立即暂停、禁止发送最终点击/确认键，并输出标准二次确认单（状态 `AWAITING_CONFIRM`）：
- **数据销毁类**：删除账套、清空记录、不可逆覆盖原文件或批量作废单据。
- **资金交易类**：财务软件付款、银行客户端转账、开具正式发票、确认收款核销。
- **对外通信类**：微信/企微/邮件客户端向外部联系人或群聊点击「发送」。
- **业务过账与物理下发类**：ERP 正式审核/过账/反结账、向 3D 打印机/产线设备直接下发「开始打印」指令。

仅当收到人类用户或上游授权审批系统的明确放行回复后，方可对最新复核截图重新定位确认按钮并完成最终单步触发。

---

## 4. 跨 Bot 协同接口契约

当本技能作为下游执行节点接入跨 Bot 流水线（如 **C2M 闲鱼 3D 打印无人车间** 或 **自动化财务/ERP 对账流水线**）时，严格执行以下数据交接标准：

### 4.1 上游输入契约（Upstream Input）
```json
{
  "task_id": "c2m-20261118-042",
  "source_bot": "xianyu-ops-bot | 3d-model-bot | finance-bot",
  "target_app": "Bambu Studio | OrcaSlicer | 金蝶/用友客户端 | WeChat",
  "input_file": {
    "path": "D:\\workshop\\jobs\\c2m-20261118-042\\model.3mf",
    "format": "3mf | stl | xlsx | csv",
    "unit": "mm",
    "sha256": "<64-char-hex>"
  },
  "operation_params": {
    "preset": "0.20mm Standard @BBL A1",
    "material": "PLA Basic",
    "infill": "15%",
    "export_dir": "D:\\workshop\\jobs\\c2m-20261118-042\\sliced"
  },
  "high_risk_policy": "always_pause_for_human_confirm"
}
```

### 4.2 下游交接产物格式（Downstream Output）
完成操作或到达高危确认点时，返回以下结构化回执供下游 Bot（如打印调度、飞书审批、客户通知 Bot）消费：
```json
{
  "status": "DONE | AWAITING_CONFIRM | BLOCKED",
  "task_id": "c2m-20261118-042",
  "target_app": "Bambu Studio",
  "artifacts": [
    {
      "path": "D:\\workshop\\jobs\\c2m-20261118-042\\sliced\\model_plate_1.gcode.3mf",
      "size_bytes": 4829104,
      "sha256": "<64-char-hex>",
      "summary": {
        "estimated_print_time": "2h 18m",
        "filament_grams": 64.5,
        "unit_verified": "mm"
      }
    }
  ],
  "approval_ticket": {
    "required": true,
    "action_type": "print_dispatch | outbound_message | payment | erp_post",
    "target_window": "Bambu Studio - model_plate_1",
    "payload_summary": "待向打印机下发打印任务（耗时 2h18m / 耗材 64.5g PLA）",
    "evidence_screenshots": [
      "artifacts/step_01_loaded.png",
      "artifacts/step_04_sliced_preview.png"
    ]
  }
}
```

---

## 5. 禁止越界事项

- **严禁跳过复核截图**：每一步 UI 修改都必须有后置截图佐证，不允许基于“应该点到了”继续后续操作。
- **严禁自行放行 L3 高危操作**：即使上游任务单声称“自动执行”，凡涉及删改核心账套、真实资金支付、对外发消息、物理设备直接启停，未经人类最终确认一律冻结。
- **严禁绕过安全屏障**：不得尝试破解、自动化点击第三方图形验证码、跳过银行 U 盾或篡改系统权限策略。
- **严禁伪造交付产物**：输出路径、文件大小与 `SHA-256` 必须来自磁盘实测；若软件切片报错或导出失败，必须如实上报 `BLOCKED` 与错误弹窗截图。
