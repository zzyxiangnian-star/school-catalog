# 参考底座与实战检验清单（`editable-pptx-architect`）

## 1. 核心 GitHub 开源底座与方法论参考

| 仓库 / 项目 | 核心定位 | 在本技能中的工程职责 |
|---|---|---|
| [`zhuyansen/awesome-codex-ppt-skills`](https://github.com/zhuyansen/awesome-codex-ppt-skills) | Codex / Agent 体系下的 PPT 生成技能集合与模板工程实践 | 提供分步大纲拆解、高密度版式原型、矢量图形组合与质量门禁规则 |
| [`icip-cas/PPTAgent`](https://github.com/icip-cas/PPTAgent) | 中科院计算所开源的文档到演示文稿多阶段智能体框架（约 4.6 min 流水线） | 提供“文档解析 → 大纲规划 → 版式匹配 → 代码生成 → 视觉反馈迭代”的多阶段闭环范式 |
| `ppt-master`（本地/社区工作流范式） | 路由式母版与多角色分工演示文稿工作流 | 提供 `Page Job`（单页使命）、几何构图多样性与结构化母版契约设计 |
| `claude-office-skills`（约 3.2 min / L2 原生图形 100% 实践） | 面向办公文档的原生 OOXML/python-pptx 高保真生成规范 | 提供 100% 原生形状/图表生成纪律与防整页栅格化红线 |
| `scanny/python-pptx` | Python 读写 OpenXML (`.pptx`) 标准库 | 负责 SlideMaster、Shape、Chart、Table 与底层 `oxml` XML 节点操作 |
| LibreOffice (`soffice`) + Poppler (`pdftoppm`) / PyMuPDF (`fitz`) | 跨平台无头渲染管线 | 负责将 `.pptx` 高保真转 `.pdf` 并栅格化为每页缩略图供视觉质检 |

---

## 2. 环境前置检测命令模板

在执行生成前，先按操作系统运行以下检测，任何核心依赖缺失即终止并提示安装：

### Windows (PowerShell)
```powershell
python --version
python -c "import pptx, PIL; print('python-pptx & Pillow OK')"
Get-Command soffice -ErrorAction SilentlyContinue
Get-Command pdftoppm -ErrorAction SilentlyContinue
python -c "import fitz; print('PyMuPDF OK')" 2>$null
```
> 若提示缺失 `soffice`（LibreOffice），常见安装路径为 `C:\Program Files\LibreOffice\program\soffice.exe`；缺失 Python 库可通过 `pip install python-pptx pillow pymupdf` 安装。

### macOS / Linux (Bash)
```bash
python3 --version
python3 -c "import pptx, PIL; print('python-pptx & Pillow OK')"
command -v soffice || command -v libreoffice
command -v pdftoppm || python3 -c "import fitz; print('PyMuPDF OK')"
```

---

## 3. 典型 CLI 渲染与 `python-pptx` 原生生成模板

### 3.1 PPTX 转 PDF 与逐页缩略图渲染
```bash
# 1. 无头转换 PPTX -> PDF
soffice --headless --convert-to pdf ./output/deck.pptx --outdir ./output/preview/

# 2. PDF -> 每页 150 DPI PNG 缩略图（Poppler）
pdftoppm -png -r 150 ./output/preview/deck.pdf ./output/preview/slide

# 备选：若无 pdftoppm，使用 PyMuPDF 渲染每页缩略图
python -c "import fitz, pathlib; doc=fitz.open('./output/preview/deck.pdf'); out=pathlib.Path('./output/preview'); [page.get_pixmap(dpi=150).save(out / f'slide-{i+1:02d}.png') for i, page in enumerate(doc)]"
```

### 3.2 `python-pptx` 原生可编辑对象构建骨架（禁止整页图片）
```python
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE

prs = Presentation()
prs.slide_width = Inches(13.333)   # 12192000 EMU (16:9 宽屏)
prs.slide_height = Inches(7.5)     # 6858000 EMU

blank_layout = prs.slide_layouts[6]
slide = prs.slides.add_slide(blank_layout)

# 1. 原生矢量卡片（可二次选中、改色、改圆角）
card = slide.shapes.add_shape(
    MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(1.6), Inches(5.4), Inches(4.8)
)
card.fill.solid()
card.fill.fore_color.rgb = RGBColor(0xF8, 0xFA, 0xFC)
card.line.color.rgb = RGBColor(0xCB, 0xD5, 0xE1)

# 2. 原生文本框（可二次编辑字体与段落）
tb = slide.shapes.add_textbox(Inches(1.1), Inches(1.9), Inches(4.8), Inches(1.2))
tf = tb.text_frame
tf.word_wrap = True
p = tf.paragraphs[0]
p.text = "核心指标趋势（原生可编辑结论）"
p.font.size = Pt(18)
p.font.bold = True

# 3. 原生数据图表（嵌入式 Excel 数据源，非 PNG 截图）
chart_data = CategoryChartData()
chart_data.categories = ["Q1", "Q2", "Q3", "Q4"]
chart_data.add_series("营收(万元)", (120, 165, 210, 285))
slide.shapes.add_chart(
    XL_CHART_TYPE.COLUMN_CLUSTERED,
    Inches(6.6), Inches(1.6), Inches(5.9), Inches(4.8),
    chart_data,
)

prs.save("./output/deck.pptx")
```

### 3.3 原生可编辑性审计脚本（L3–L5 门禁检查）
```python
import hashlib
from pathlib import Path
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

def audit_pptx(pptx_path: str) -> dict:
    prs = Presentation(pptx_path)
    total_slides = len(prs.slides)
    full_bleed_image_slides = []
    stats = {"text": 0, "auto_shape": 0, "chart": 0, "table": 0, "picture": 0, "group": 0}

    slide_area = prs.slide_width * prs.slide_height
    for idx, slide in enumerate(prs.slides, start=1):
        non_bg_pics = 0
        editable_objs = 0
        for shp in slide.shapes:
            if shp.shape_type == MSO_SHAPE_TYPE.PICTURE:
                stats["picture"] += 1
                ratio = (shp.width * shp.height) / slide_area
                if ratio >= 0.65:
                    non_bg_pics += 1
            elif shp.has_chart:
                stats["chart"] += 1
                editable_objs += 1
            elif shp.has_table:
                stats["table"] += 1
                editable_objs += 1
            elif shp.shape_type == MSO_SHAPE_TYPE.GROUP:
                stats["group"] += 1
                editable_objs += 1
            elif shp.has_text_frame or shp.shape_type == MSO_SHAPE_TYPE.AUTO_SHAPE:
                stats["auto_shape" if shp.shape_type == MSO_SHAPE_TYPE.AUTO_SHAPE else "text"] += 1
                editable_objs += 1
        if non_bg_pics > 0 and editable_objs == 0:
            full_bleed_image_slides.append(idx)

    sha256 = hashlib.sha256(Path(pptx_path).read_bytes()).hexdigest()
    return {
        "file": pptx_path,
        "sha256": sha256,
        "slides": total_slides,
        "slide_size_emu": [prs.slide_width, prs.slide_height],
        "object_stats": stats,
        "l1_rasterized_slides": full_bleed_image_slides,
        "editable_pass": len(full_bleed_image_slides) == 0,
    }
```

---

## 4. 跨 Bot 交接清单规范（`handoff_manifest.json`）

```json
{
  "producer_bot": "editable-ppt-bot",
  "skill": "editable-pptx-architect",
  "deck_file": "./output/deck.pptx",
  "pdf_preview": "./output/preview/deck.pdf",
  "thumbnails_dir": "./output/preview/",
  "slide_count": 12,
  "dimensions": {
    "aspect_ratio": "16:9",
    "width_inches": 13.333,
    "height_inches": 7.5,
    "width_emu": 12192000,
    "height_emu": 6858000
  },
  "editability_level": "L4",
  "l1_rasterized_slides": [],
  "visual_qa_status": "PASS",
  "sha256": "<64-char-hex>"
}
```

---

## 5. 交付产物检验清单（Delivery Checklist）

- [ ] **前置环境实测通过**：已真实执行 Python、`python-pptx`、LibreOffice 与 PDF 渲染检测，无伪造命令输出。
- [ ] **零 L1 整页死图**：`audit_pptx` 检查 `l1_rasterized_slides` 为空列表；所有文本、卡片、箭头、流程图与数据图表均为原生 PPTX 对象。
- [ ] **图表数据源真实嵌入**：所有图表使用 `add_chart` 创建并绑定真实数据源，不采用 matplotlib/echarts 截图替代。
- [ ] **版式与母版一致**：全局字体家族、标题字号阶梯、色板对比度与页边距符合 12 栏网格规范，未出现同页 3 种以上无序字体。
- [ ] **PDF 缩略图全页审阅**：已通过 `soffice` 转 PDF 并渲染逐页 PNG，人工/视觉核验无文字截断、无边框溢出、无元素遮挡、无图表标签重叠。
- [ ] **文件完整性与交接包齐备**：`.pptx`、生成脚本、`.pdf`、逐页缩略图与 SHA-256 哈希均已生成并可核验。
