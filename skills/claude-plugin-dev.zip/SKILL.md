---
name: claude-plugin-dev
description: "涵盖 Agent、斜杠命令、Hooks、MCP 集成与全流程插件规范的 7 项官方开发工具包。"
---

# Claude Plugin Dev Toolkit

涵盖 Agent、斜杠命令、Hooks、MCP 集成与全流程插件规范的 7 项官方开发工具包。

Source: https://github.com/anthropics/claude-plugins-official

## Included Skills (7)

- `claude-plugin-dev-agent-development`
- `claude-plugin-dev-command-development`
- `claude-plugin-dev-hook-development`
- `claude-plugin-dev-mcp-integration`
- `claude-plugin-dev-plugin-settings`
- `claude-plugin-dev-plugin-structure`
- `claude-plugin-dev-skill-development`
