---
name: "激光切割与 CNC 排版安全流程"
description: "本地矢量转 DXF 除重线分层，运行 spyrrow 异形排版并输出禁切物料黑名单"
---

# 激光切割与 CNC 排版助手 — 激光切割与 CNC 排版安全流程

## 定位与适用范围

全本地 CPU 联动 Inkscape、ezdxf 与 Rust 内核 spyrrow，完成闭合与重线清理、内外轮廓分层、异形省料排版及路径工时估算，严防有毒材质切割。

- **归属 Bot**：`laser-cnc-nesting-bot`（分类：`design`）
- **协同目录技能**：无（本技能独立承担全流程）
- **关联推荐 MCP 插件**：filesystem

## 核心开源工具栈（国内高可用）

- mozman/ezdxf — MIT（DXF 几何体检、重线清理与精确圆弧回写）
- PaulDL-RS/spyrrow — MIT（基于 JeroenGar/sparrow 的预编译 Rust 异形排版库）
- sandraschi/inkscape-mcp — MIT（可选外置 Inkscape >= 1.2 矢量化与文字转曲服务）
- DerChris2011/Lightburn_MCP — MIT（可选 LightBurn 2.2+ 用户外置桥梁，不含排版需搭 spyrrow）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- 本机安装 Inkscape >= 1.2、Python >= 3.11 与 uv，并安装 `pip install "ezdxf[draw]" spyrrow`
- 全流程运行在本地多核 CPU，无需大模型联网推理或独立显卡

## 标准执行 SOP

1. 原料合规核查：核对用户提交的板材名称，如命中 PVC、含氯塑料、聚碳酸酯等激光禁切黑名单立刻中止并给出警示。
2. 转曲与单位校准：经 Inkscape（CLI 或外置 `inkscape-mcp`）执行位图矢量化及字体转曲，统一毫米（mm）输出 R12/R2010 DXF。
3. DXF 几何清障与分层：使用 `ezdxf` 排查开放路径、微碎线段与重复叠线，清晰分入 `CUT_INNER`（内孔先切）、`CUT_OUTER`（外轮廓）、`ENGRAVE` 图层。
4. 异形省料求解：写入板材宽高、割缝补偿（0.1~0.2 mm）或铣刀直径及木纹 `0°/180°` 旋转限制，运行 `spyrrow.StripPackingInstance`。
5. 排版回写与工时核算：保留圆弧实体导出排版 DXF 与 `ezdxf draw` 预览图，汇总切割总长、空移距离与穿孔次数，说明工时未含加减速及换刀等待并附 CAM 上机复核单。

## 安全合规红线与执业边界

- 强拦截激光禁切物料：PVC、含氯高分子及聚碳酸酯（PC）严禁生成切割参数，明确解释剧毒氯气与火灾隐患。
- 清晰提示 DXF 不包含 CNC 安全高度（Z Safe Height）与压板夹具坐标，必须在 CAM 模拟后方能加工，严禁自动化点火。

## 已明确排除项目

- `Jack000/Deepnest`（8 年前停更且缺乏可用 CLI）
- `Jack000/SVGnest`（长期停更的纯浏览器前端工具）

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
