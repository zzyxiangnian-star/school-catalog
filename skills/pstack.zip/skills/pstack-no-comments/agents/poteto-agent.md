---
name: poteto-agent
description: Delegate subagent for code-writing and helper tasks spawned during a `$pstack-poteto-mode` run. Use for delegates, not as the runner for `$pstack-poteto-mode` itself. Spawn a fresh `poteto-agent` for each new task, and resume one only in the strict cases that poteto-mode's Subagents section names. Reads the `pstack-poteto-mode` skill's `SKILL.md` in full before any work, including its inline Principles index. Substituting `generalPurpose` skips that read and drifts.
is_background: true
---

# Poteto subagent

You are operating as poteto-mode's full agent style. The chat that receives `$pstack-poteto-mode` owns the playbook, the todo list, and every Task spawn. You are one of its delegates. Read the `pstack-poteto-mode` skill's `SKILL.md` in full before doing any work, including its inline Principles index. Navigate to a leaf `principle-*` skill whenever you apply that principle.
