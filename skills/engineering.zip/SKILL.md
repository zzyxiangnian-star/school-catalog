---
name: engineering
description: "Streamline engineering workflows including standups, code review, architecture decisions, incident response, and technical documentation."
---

# Engineering

Streamline engineering workflows including standups, code review, architecture decisions, incident response, and technical documentation.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (10)

- `engineering-architecture`
- `engineering-code-review`
- `engineering-debug`
- `engineering-deploy-checklist`
- `engineering-documentation`
- `engineering-incident-response`
- `engineering-standup`
- `engineering-system-design`
- `engineering-tech-debt`
- `engineering-testing-strategy`
