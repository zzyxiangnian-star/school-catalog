---
name: product-management
description: "Write feature specs, plan roadmaps, synthesize user research, update stakeholders, and track the competitive landscape."
---

# Product Management

Write feature specs, plan roadmaps, synthesize user research, update stakeholders, and track the competitive landscape.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (8)

- `product-management-competitive-brief`
- `product-management-metrics-review`
- `product-management-product-brainstorming`
- `product-management-roadmap-update`
- `product-management-sprint-planning`
- `product-management-stakeholder-update`
- `product-management-synthesize-research`
- `product-management-write-spec`
