---
name: sales
description: "Sales workflows for call preparation, account research, pipeline review, follow-up drafting, and revenue forecasting."
---

# Sales

Sales workflows for call preparation, account research, pipeline review, follow-up drafting, and revenue forecasting.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (36)

- `sales-account-context`
- `sales-account-plan`
- `sales-account-research`
- `sales-account-tiering`
- `sales-call-prep`
- `sales-call-summary`
- `sales-close-plan`
- `sales-competitive-intelligence`
- `sales-create-an-asset`
- `sales-crm-hygiene-check`
- `sales-customer-health`
- `sales-customer-voice`
- `sales-daily-briefing`
- `sales-deal-advance-gap`
- `sales-deal-review`
- `sales-deal-signals`
- `sales-deal-slip-scenario`
- `sales-draft-outreach`
- `sales-end-of-day`
- `sales-expansion-whitespace`
- `sales-forecast`
- `sales-handle-objection`
- `sales-inbox-sweep`
- `sales-lead-triage`
- `sales-log-activity`
- `sales-pipeline-review`
- `sales-renewal-radar`
- `sales-rep-context`
- `sales-route-lead`
- `sales-schedule-meeting`
- `sales-setup`
- `sales-stakeholder-map`
- `sales-team-pipeline`
- `sales-update-opportunity`
- `sales-weekly-wrap`
- `sales-win-loss-review`
