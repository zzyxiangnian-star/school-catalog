---
name: claude-imessage
description: "Anthropic 官方插件，直连本地 chat.db 与 AppleScript 实现带权限控制的消息通道。"
---

# Claude iMessage Channel

Anthropic 官方插件，直连本地 chat.db 与 AppleScript 实现带权限控制的消息通道。

Source: https://github.com/anthropics/claude-plugins-official

## Included Skills (2)

- `claude-imessage-access`
- `claude-imessage-configure`
