---
name: addy-engineering-skills
description: "Production-grade engineering skills by Addy Osmani covering spec-driven development, API design, TDD, code review, security hardening, and performance optimization."
---

# Addy Engineering Skills

Production-grade engineering skills by Addy Osmani covering spec-driven development, API design, TDD, code review, security hardening, and performance optimization.

Source: https://github.com/addyosmani/agent-skills

## Included Skills (25)

- `addy-engineering-skills-api-and-interface-design`
- `addy-engineering-skills-browser-testing-with-devtools`
- `addy-engineering-skills-ci-cd-and-automation`
- `addy-engineering-skills-code-review-and-quality`
- `addy-engineering-skills-code-simplification`
- `addy-engineering-skills-constraint-driven-development`
- `addy-engineering-skills-context-engineering`
- `addy-engineering-skills-debugging-and-error-recovery`
- `addy-engineering-skills-deprecation-and-migration`
- `addy-engineering-skills-documentation-and-adrs`
- `addy-engineering-skills-doubt-driven-development`
- `addy-engineering-skills-frontend-ui-engineering`
- `addy-engineering-skills-git-workflow-and-versioning`
- `addy-engineering-skills-idea-refine`
- `addy-engineering-skills-incremental-implementation`
- `addy-engineering-skills-interview-me`
- `addy-engineering-skills-observability-and-instrumentation`
- `addy-engineering-skills-performance-optimization`
- `addy-engineering-skills-planning-and-task-breakdown`
- `addy-engineering-skills-security-and-hardening`
- `addy-engineering-skills-shipping-and-launch`
- `addy-engineering-skills-source-driven-development`
- `addy-engineering-skills-spec-driven-development`
- `addy-engineering-skills-test-driven-development`
- `addy-engineering-skills-using-agent-skills`
