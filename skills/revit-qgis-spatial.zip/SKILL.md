---
name: revit-qgis-spatial
description: 建筑 BIM（Revit MEP 与构件）、室内家装（3d-new-era-ai 户型与采光排布）及 GIS 地理测绘（QGIS 选址热力图与地形分析）一体化空间工程技能，强制执行 EPSG 坐标系、标高单位与构件碰撞校验。
---

# Revit 与 QGIS 空间测绘技能（`revit-qgis-spatial`）

本技能服务于「BIM与GIS测绘师」（`bim-gis-spatial-bot`），用于协调建筑 BIM 工程建模、室内家装设计以及 GIS 地理空间测绘，确保跨软件空间基准一致、几何零错误并产出可追溯的工程交付物。

---

## 1. 触发条件

满足以下任一场景时激活本技能：
- **建筑 BIM 与 MEP 建模**：需在 Revit 中创建/修改建筑构件、布设水电暖通（MEP）管线、提取工程量或执行构件碰撞检查（本地桌面或 APS 云端批处理）。
- **室内家装与采光排布**：需根据尺寸/草图绘制室内平面户型图、布置家具、校核通道人体工学尺度、评估房间采光或生成实时渲染图。
- **GIS 商业选址与地形测绘**：需加载道路/POI/人口/DEM 数据，制作商业选址热力图、街区人流等时圈分析、地形坡度/高程分析并输出标准矢量或栅格图层。
- **BIM-GIS 跨端空间校验**：需将建筑/家装模型与地理地形底图叠加对齐，核验 EPSG 投影、绝对高程基准与地下管线覆土/碰撞边界。

---

## 2. GitHub 开源底座与 MCP 工具矩阵

| 模块赛道 | 开源仓库 / MCP | 核心职责 | 典型输入/输出 |
| :--- | :--- | :--- | :--- |
| 本地桌面 BIM | `mcp-servers-for-revit/revit-mcp` | 直连运行中的 Autodesk Revit，创建标高/轴网/墙体/MEP 管线，查询构件参数与干涉 | 输入：建模指令与族参数<br>输出：`.rvt` 副本、`.ifc`、构件表 |
| 云端无头 BIM | `autodesk-platform-services/aps-sample-revit-mcp-tools-bundle` | 基于 APS Automation API 远程批处理云端 Revit 模型与提取结构化信息 | 输入：云端模型 URN 与任务参数<br>输出：提取 JSON、批处理 `.rvt`/`.ifc` |
| 室内家装设计 | `leandrodaf/3d-new-era-ai` | Rust 开源室内设计编辑器内置 MCP，绘制户型墙体、家具排布、采光与人体工学检查、实时渲染 | 输入：开间尺寸/风格要求<br>输出：户型工程、采光检查报告、渲染图 |
| 商业 GIS 测绘（首选） | `nkarasiak/qgis-mcp` | 活跃维护的 QGIS MCP 插件，支持图层读写、要素提交/回滚、热力样式、打印布局与空间算法 | 输入：CSV/SHP/GeoJSON/DEM<br>输出：`.geojson`、`.gpkg`、专题图 |
| 商业 GIS 测绘（备选） | `jjsantos01/qgis_mcp` | 经典 QGIS Socket MCP 桥接，支持基础工程控制、Processing 算法与 PyQGIS 脚本执行 | 输入：GIS 图层与算法参数<br>输出：处理后矢量/栅格图层 |
| 工程文件读写 | `filesystem` | 核验本地输入文件存在性、读写配置文件、输出 `manifest.json` 与计算 SHA-256 | 输入：工作区路径<br>输出：标准化交付目录 |

---

## 3. 前置环境探测（Pre-flight Check）

**铁律：未通过探测绝不假装执行建模或测绘操作，绝不编造工具返回结果。**

1. **文件与工作区探测**：调用 `filesystem` 检查用户指定的输入目录及文件是否存在、格式是否完整，并在工作区下准备独立的 `output/` 交付目录，严禁直接覆盖原始工程文件。
2. **对应赛道工具就绪探测**：
   - **本地 Revit 赛道**：探测 `revit-mcp` 工具可用性及与本地 Revit 插件端口的连接状态；若连接失败，立即停止输出 `BLOCKED`，提示用户打开目标版本的 Autodesk Revit 并启用 `revit-mcp-plugin` 插件。
   - **云端 APS 赛道**：探测 APS 工具及 `APS_CLIENT_ID` / `APS_CLIENT_SECRET` 环境变量或有效 Token 是否就绪；若缺失，输出 `BLOCKED` 并引导用户按 `autodesk-platform-services/aps-sample-revit-mcp-tools-bundle` 文档部署 AppBundle 与配置凭证。
   - **室内家装赛道**：探测 `leandrodaf/3d-new-era-ai` 内置 MCP 服务是否启动响应；若未启动，输出 `BLOCKED` 并提示先编译/启动 `3d-new-era-ai --mcp`。
   - **QGIS 测绘赛道**：探测 `nkarasiak/qgis-mcp`（或 `jjsantos01/qgis_mcp`）Ping/状态接口；若超时，输出 `BLOCKED` 并引导用户在 QGIS Desktop 中从插件库安装并开启 `QGIS MCP` Socket 服务。
3. **关键空间参数确认**：若输入未声明**目标 EPSG**（GIS 任务）、**标高零点**或**长度单位**（BIM/家装任务），在开工前一次性列出缺失项向用户确认，不擅自假设投影带号。

---

## 4. 分步执行 SOP

### 赛道 A：建筑 BIM 与 MEP 管线建模（Revit）
1. **备份与基准读取**：先复制原始 `.rvt` 为工作副本；读取现有标高（Levels）、轴网（Grids）及项目长度单位（通常为 `mm`）。
2. **主体与 MEP 建模**：按“先结构/建筑外框，后主干管线（风管 → 桥架 → 给排水/喷淋），最后支管与末端设备”顺序调用 `revit-mcp` 或 APS Bundle 批处理指令生成构件，确保标高、坡度与系统分类属性完整。
3. **碰撞与净距校验**：执行管线与结构梁柱、管线与管线之间的干涉检测；若存在碰撞，输出冲突构件 ID、所在标高及建议避让偏移量（如立管下翻/局部绕梁），必要时在确认后自动微调并复检。
4. **标准导出**：保存工作副本 `.rvt`，并按需导出标准 `.ifc`（保留空间层级与共享坐标信息）。

### 赛道 B：室内家装平面与采光排布（`3d-new-era-ai`）
1. **户型骨架重建**：通过 `3d-new-era-ai` MCP 按实测尺寸绘制承重墙、隔断墙及门窗洞口，核验外围墙体闭合性与房间面积统计。
2. **功能分区与家具排布**：依采光面（南向/大窗优先放置客厅、书桌）与动线原则布置核心家具，校验过道净宽（主通道 ≥ 800mm、床周 ≥ 600mm）与门扇/柜门开启干涉。
3. **采光与渲染验证**：调用编辑器的采光/人体工学检查工具与实时渲染功能，生成平面布局图与关键视角渲染图，存入 `output/` 目录并核对尺寸标注。

### 赛道 C：商业选址与地形空间测绘（QGIS）
1. **投影坐标系强制对齐**：加载边界、POI、人流网格与 DEM 栅格后，第一步检查所有图层的 CRS；涉及距离缓冲区、面积、核密度计算时，必须统一重投影至当地适用的米制投影坐标系（如 CGCS2000 3度带或 UTM），严禁在 `EPSG:4326` 经纬度下直接做米制运算。
2. **空间分析与制图**：
   - 商业选址/人流：基于权重字段执行核密度估计（Heatmap / KDE）、步行等时圈或缓冲区叠加统计，输出分级评分。
   - 地形分析：基于 DEM 计算高程分级、坡度（Slope）与坡向（Aspect），剔除超坡度不可建设区域。
3. **拓扑检查与导出**：验证矢量几何有效性（修复自相交、空几何）；输出分析底图 `.gpkg`（保留投影 CRS）及通用交换格式 `.geojson`（遵循 RFC 7946 `EPSG:4326` 标准），必要时通过 QGIS 打印布局导出带比例尺与指北针的专题图。

### 跨赛道融合校准（BIM + GIS 联动）
当建筑 BIM 需落位至 GIS 地形底图时：
1. 统一单位换算：`BIM 坐标(mm) × 0.001 → 米(m)`；
2. 绑定控制点：依据测绘控制点坐标 `(E, N, H0)` 与真北夹角完成工程局部坐标到目标投影 EPSG 的仿射对齐；
3. 覆土/净空复核：校验地下室顶板与市政管线在绝对高程下是否满足最小覆土或防涝标高要求。

---

## 5. 跨 Bot 协同接口

### 上游输入契约（Upstream Input）
支持接收来自上游规划/勘测 Bot 或用户提供的结构化包（位于工作区 `input/`）：
- **BIM/家装输入**：需求单（JSON/Markdown，含开间尺寸、层高、MEP 系统要求）、参考 `.dwg`/`.rvt`/`.ifc` 或平面草图。
- **GIS 输入**：研究区范围多边形（`.geojson`/`.shp`）、点位 CSV（明确经纬度列名与原始 EPSG）、DEM 栅格（`.tif`）及筛选权重规则。

### 下游交接契约（Downstream Handoff）
所有成品统一落盘至 `output/`，并必须附带一份标准 `manifest.json` 供下游渲染、工程造价、商业汇报 Bot 或用户验收消费：
```json
{
  "task_id": "<task_slug>",
  "status": "PASS",
  "spatial_reference": {
    "crs_epsg": "EPSG:4547",
    "length_unit": "mm (BIM) / m (GIS)",
    "elevation_datum": "CGCS2000 / 建筑±0.000=绝对高程42.50m",
    "true_north_deg": 0.0
  },
  "qa_summary": {
    "clash_count": 0,
    "invalid_geometries": 0,
    "notes": "已完成MEP硬碰撞复检与矢量拓扑修复"
  },
  "artifacts": [
    {
      "role": "bim_model",
      "path": "output/building_mep_checked.ifc",
      "format": "IFC4",
      "sha256": "<64-hex>"
    },
    {
      "role": "gis_heatmap",
      "path": "output/site_selection_heatmap.geojson",
      "format": "GeoJSON",
      "sha256": "<64-hex>"
    }
  ]
}
```

---

## 6. 质检红线与异常处理

- **坐标系缺失或混用**：发现图层无 CRS 定义或 `EPSG:4326` 与投影坐标混叠，立即中止空间叠加并标为 `WARN`/`BLOCKED`，向用户确认源坐标系后再转换。
- **单位量级异常**：若建筑墙高出现 `3.0`（误当米）或 GIS 缓冲区出现 `500000`（误当毫米），立即中断并纠正单位系数。
- **存在未解决碰撞**：MEP 与主梁碰撞未通过自动绕行解决时，必须在报告中列明冲突构件 ID 与坐标，结论降级为 `WARN`，禁止标记为零碰撞 `PASS`。

---

## 7. 禁止越界事项

1. **严禁伪造实测数据**：未连上 Revit/3d-new-era-ai/QGIS 时，绝不编造构件 ID、人流热力数值、碰撞报告或伪造工具调用成功状态。
2. **严禁破坏原始工程**：绝不直接覆盖用户原始 `.rvt`、`.qgz` 或测绘原文件；所有写操作必须在工作副本上进行。
3. **严禁越权修改基准**：未经工程负责人明确同意，绝不擅自修改建筑结构轴网、楼层标高零点或项目默认地理投影基准。
4. **严禁输出未校验格式**：未经过几何有效性或 EPSG 核对的图层不得作为最终交付产物写入 `manifest.json`。
