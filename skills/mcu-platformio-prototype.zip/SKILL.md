---
name: "嵌入式硬件安全引脚与固件调试流程"
description: "执行电平预算核查、Strapping 引脚排雷、编译诊断及人工审批安全烧录"
---

# 单片机与硬件原型助手 — 嵌入式硬件安全引脚与固件调试流程

## 定位与适用范围

集成 platformio-mcp 执行板级发现、安全引脚审计、自动化编译诊断与串口日志监测，严格锁定 flash_requires_approval 烧录确认闸门防硬件烧毁。

- **归属 Bot**：`mcu-hardware-bot`（分类：`coding`）
- **协同目录技能**：无（本技能独立承担全流程）
- **关联推荐 MCP 插件**：platformio-mcp

## 核心开源工具栈（国内高可用）

- jl-codes/platformio-mcp — MIT（v3.1.0，支持 `agent_safe_pin_audit` 与审批策略）
- arduino/arduino-cli — GPL-3.0（轻量化 Arduino/ESP32 备选外置 CLI）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- Node.js >= 20、PlatformIO Core CLI 及国产常见 CH340/CP2102 USB 转串口驱动
- 国内可通过 npmmirror 安装 `platformio-mcp`；首次下载 ESP32 工具链建议配合国内镜像源或提前缓存
- 保持 `.pio-mcp-policy.json` 中的 `flash_requires_approval` 为开启状态

## 标准执行 SOP

1. 供电与电平预算：核对主控与传感器电压（3.3V vs 5V）及驱动电流，标红需加逻辑电平转换或独立外部电源的模块。
2. GPIO 排雷审计：调用 `agent_safe_pin_audit` 避开 ESP32 启动配置引脚（GPIO0/2/12/15）、内部 Flash 占用引脚与纯输入脚，产出包含共地（GND）线的逐脚表格。
3. 固件架构编写：生成模块化 `platformio.ini` 与驱动源码，显式注释 I2C 地址与 SPI 片选号。
4. 编译诊断修复：运行本地构建并针对报错调用 `agent_build_diagnose` 补全头文件和库依赖。
5. 人工审批烧录：冻结烧录步，展示目标 COM/tty 端口与安全核对单待用户批准；烧录后监控串口日志排查电源跌落（Brownout）与重启异常。

## 安全合规红线与执业边界

- 默认强制锁定 `flash_requires_approval`，禁止未获当次明确批准直接刷机。
- 明确警示电源反接、VCC-GND 短路与锂电池大电流回路防烧板与热失控操作守则。

## 已明确排除项目

- 缺乏安全烧录审批闸门的早期裸串口刷机脚本
- 强依赖海外在线仿真的闭源云端嵌入式接口

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
