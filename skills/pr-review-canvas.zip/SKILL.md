---
name: pr-review-canvas
description: "Render pull request diffs as structured review canvases grouped by importance."
---

# PR Review Canvas

Render pull request diffs as structured review canvases grouped by importance.

Source: https://github.com/cursor/plugins

## Included Skills (1)

- `pr-review-canvas-pr-review-canvas`
