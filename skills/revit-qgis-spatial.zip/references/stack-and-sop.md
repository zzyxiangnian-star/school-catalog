# Revit 与 QGIS 空间测绘技术底座及交付检验手册

本参考手册配套技能 `revit-qgis-spatial`（所属 Bot：`bim-gis-spatial-bot`），汇总开源工具栈、典型 MCP 配置模板与交付物核验清单。

---

## 1. 开源 GitHub 底座清单

| 仓库 | 定位与适用场景 | 运行方式与核心前提 |
| :--- | :--- | :--- |
| `mcp-servers-for-revit/revit-mcp` | 桌面端 Autodesk Revit 实时建模、族实例化、MEP 管线布设、视图与碰撞查询 | 需本机运行支持的 Autodesk Revit，并安装编译/加载配套 `revit-mcp-plugin` 插件 |
| `autodesk-platform-services/aps-sample-revit-mcp-tools-bundle` | 基于 Autodesk Platform Services (APS) Automation API 的云端无头 Revit 批处理与数据提取 | 需配置 APS 应用 `Client ID` / `Client Secret`、OAuth Token 及打包上传的 AppBundle |
| `leandrodaf/3d-new-era-ai` | Rust 编写的开源室内家装与平面户型编辑器，内置原生 MCP Server，支持墙体绘制、家具排布、采光评估与实时出图 | 需本地编译或运行 `3d-new-era-ai` 二进制并开启其内置 MCP 通信端点 |
| `nkarasiak/qgis-mcp` | 活跃维护的 QGIS Desktop MCP 服务（已上架官方 QGIS Python Plugins 仓库），覆盖图层管理、要素编辑回滚、样式制图、打印布局与空间分析 | 需本机安装 QGIS，并在插件管理器中安装并启动 `QGIS MCP` Socket 服务 |
| `jjsantos01/qgis_mcp` | 经典初代 QGIS MCP 桥接仓库，提供工程加载、处理算法（Processing）及 PyQGIS 执行基础能力 | 作为轻量或旧版 QGIS 环境备选，需在 QGIS 插件端开启本地 Socket 监听 |
| `filesystem`（关联 MCP） | 本地工程目录遍历、原始 CAD/GeoJSON/CSV 读取、交付产物写入及规范文件校验 | 需在 MCP 客户端配置中明确授权工作区读写白名单路径 |

---

## 2. 典型 MCP 客户端配置模板

> 说明：以下为标准 `mcpServers` 配置示例，使用前请将 `<...>` 替换为本机实际路径或测试环境变量，**切勿在配置或日志中提交真实密钥**。

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "<WORKSPACE_PROJECT_DIR>"
      ]
    },
    "revit-mcp": {
      "command": "node",
      "args": ["<PATH_TO_REVIT_MCP>/build/index.js"]
    },
    "aps-revit-mcp": {
      "command": "node",
      "args": ["<PATH_TO_APS_REVIT_MCP_SERVER>/dist/index.js"],
      "env": {
        "APS_CLIENT_ID": "<YOUR_APS_CLIENT_ID>",
        "APS_CLIENT_SECRET": "<YOUR_APS_CLIENT_SECRET>"
      }
    },
    "3d-new-era-ai": {
      "command": "<PATH_TO_3D_NEW_ERA_AI_BIN>",
      "args": ["--mcp"]
    },
    "qgis-mcp": {
      "command": "uv",
      "args": [
        "--directory",
        "<PATH_TO_QGIS_MCP_REPO>",
        "run",
        "qgis_mcp_server.py"
      ]
    }
  }
}
```

---

## 3. 空间坐标系、标高与单位校准速查

1. **长度与坐标单位换算**：
   - **Revit / 室内户型标准**：常用毫米（`mm`），局部轴网原点多位于建筑西南角柱轴交点 `(0, 0, ±0.000)`。
   - **QGIS 投影坐标系标准**：常用米（`m`，如 `EPSG:3857` 或 CGCS2000 3度带 `EPSG:4547`）；经纬度地理坐标系（`EPSG:4326`）为十进制度（`degree`），**严禁直接对 `EPSG:4326` 图层执行米制缓冲区或面积计算**，必须先重投影至等面积/等距投影坐标系。
   - **BIM → GIS 落位公式**：先将 Revit 模型坐标按 `0.001` 缩放转为米，再依据项目测量控制点（Survey Point）与真北偏角（Angle to True North）平移旋转至目标 EPSG 坐标。
2. **高程与标高基准**：
   - 建筑标高（如 `±0.000` 室内地坪）必须记录其对应的绝对海拔高程（如黄海高程 / WGS84 椭球高 `H0` 米），在合并地形 DEM 与地下管线时统一按 `Z_abs = H0 + Z_bim_m` 核算覆土深度。

---

## 4. 交付产物检验清单（Delivery Checklist）

### A. 通用交接元文件（`manifest.json`）
- [ ] 包含 `project_id`、`crs_epsg`、`length_unit`、`elevation_datum`、`true_north_deg` 字段。
- [ ] 每个交付文件均附带 `path`、`format`、`size_bytes` 与 `sha256` 校验值。
- [ ] 记录前置检查状态、碰撞/拓扑质检汇总结论（`PASS` / `WARN`）及未决说明。

### B. 建筑 BIM 与室内家装交付（`.rvt` / `.ifc` / 家装工程）
- [ ] 原始 `.rvt` 未被直接覆盖，交付文件为带版本号或时间戳的独立工作副本（如 `*_checked.rvt`、`*.ifc`）。
- [ ] IFC 导出版本明确（推荐 IFC4 / IFC2x3 Coordination View），共享坐标（Shared Coordinates）已勾选或于 `manifest.json` 注明局部原点。
- [ ] MEP 管线（风管、桥架、给排水）已完成硬碰撞与最小安装净距检查，无未记录的穿梁/穿墙冲突。
- [ ] 室内户型外墙闭合、门窗开启方向无干涉、通道净宽符合基础人机尺度且采光面朝向明确。

### C. GIS 空间测绘交付（`.geojson` / `.gpkg` / 专题图）
- [ ] 使用 `ogrinfo -al -so <file>` 或 QGIS 图层属性确认 `EPSG` 明确且无 `Unknown CRS`。
- [ ] 多边形要素已执行几何有效性校验（无自相交、无零面积碎片，`.geojson` 默认按 RFC 7946 使用 `EPSG:4326`，投影分析底图保存为 `.gpkg` 并保留投影 EPSG）。
- [ ] 商业选址热力图与地形分析图层包含图例分级阈值、采样半径/核密度参数及数据源时间戳说明。
