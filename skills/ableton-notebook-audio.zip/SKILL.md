---
name: ableton-notebook-audio
description: 联动 ahujasid/ableton-mcp 进行无版权风险 DAW 原创配乐与分轨导出（适配视频卡点），并协同 qiaomu-anything-to-notebooklm 与 jacob-bd/gemini-notebook-mcp-cli（notebooklm-mcp-cli）将长研报一键转化为带来源引用的双人对谈播客音频。
---

# Ableton 编曲与 NotebookLM 双人播客生产技能

## 1. 触发条件
当遇到以下任一需求时触发本技能：
- 需要为视频剪辑、产品演示或自媒体内容制作**无版权争议的原创背景音乐 / 分轨配乐**（含指定 BPM、调性、情绪、段落卡点），并输出 `.als` 工程与 WAV/MP3 分轨。
- 需要将 `#01 爬虫 Bot` 或 `#04 ETL Bot` 产出的**数十页长研报、多篇参考资料或网页合集**转化为**双人对谈播客音频**，并保留可核查的来源引用。
- 需要为 `#08 视频 Bot` 提供精确的节拍卡点时间表（BPM / 小节时间戳）与同步音频资产。

---

## 2. GitHub 开源底座与关联技能
- **DAW 控制底座**：`ahujasid/ableton-mcp`（Ableton Live Remote Script + Python MCP Server，默认本地 TCP 端口 `9877`）。
- **播客生成底座**：`jacob-bd/gemini-notebook-mcp-cli`（即 `notebooklm-mcp-cli`，提供 `nlm` CLI 与 `notebooklm-mcp` 服务）。
- **协同前置技能**：`qiaomu-anything-to-notebooklm`（用于长文档、网页、PDF、Markdown 等异构信源的清洗、分段与格式化摄取）。

---

## 3. 分步执行 SOP

### 阶段零：前置环境与凭证探测（强制门禁）
在执行任何创作指令前，先按目标轨道完成最小化探活，**任一前置条件缺失即输出修复引导并终止（`BLOCKED`），严禁跳过或模拟成功**：

1. **Track A（Ableton Live）探活**：
   - 调用 `ableton-mcp` 的 `get_session_info`。
   - 若超时或连接拒绝，一次说明排查清单并停止：
     1. 确认本地已打开 Ableton Live（Live 10+）；
     2. 确认已将 `ahujasid/ableton-mcp` 的 `AbletonMCP_Remote_Script/__init__.py` 放入 `User Remote Scripts/AbletonMCP/`；
     3. 在 Live 的 `Preferences -> Link, Tempo & MIDI -> Control Surface` 中选中 `AbletonMCP`（Input/Output 设为 `None`）；
     4. 确认 MCP 配置使用 `uvx ableton-mcp` 且可连通本机 `9877` 端口。
2. **Track B（NotebookLM CLI/MCP）探活**：
   - 检查 `nlm` CLI 或 `notebooklm-mcp` 是否可用；通过轻量列表命令（如查询现有笔记本或状态）验证 Google 会话 Cookie 是否有效。
   - 若提示未安装或认证失效，指导用户安装（`uv tool install notebooklm-mcp-cli`）并执行 `nlm login` 完成浏览器授权后停止等待。

---

### 阶段一：Track A — Ableton Live 无版权原创配乐工作流
1. **需求锚定**：确定目标 `BPM`、调性（如 C Minor / A Major）、拍号（默认 `4/4`）、目标时长/小节数、情绪风格与卡点转场节点（如 Intro 4 小节、Drop 第 9 小节、Outro 第 25 小节）。
2. **工程初始化**：
   - 调用 `set_tempo` 写入精确 BPM。
   - 调用 `create_midi_track` 按职责建立标准分轨：`01-Drums`、`02-Bass`、`03-Chords`、`04-Lead/Arp`。
3. **音色加载与编曲写入**：
   - 使用 `load_browser_item` 为各轨挂载 Ableton 原厂或用户合法授权的合成器、鼓组与效果器（混响、压缩、均衡）。
   - 使用 `create_clip` 按段落创建 MIDI Clip，通过 `add_notes_to_clip` 写入符合和声进行与节奏律动的音符（精确控制 `pitch`、`start_time`、`duration`、`velocity`，加入适度力度起伏避免机械感）。
   - 检查轨道电平与声像，预留至少 `-1 dBFS` ~ `-3 dBFS` 峰值余量（Headroom），防止母带削波。
4. **工程保存、分轨导出与卡点清单生成**：
   - 如当前 `ableton-mcp` 版本未暴露直接渲染磁盘 API，须明确指引用户在 Ableton Live 执行 `Ctrl/Cmd+S` 保存 `.als`，以及 `Ctrl/Cmd+Shift+R` 导出母带（Master）与各分轨（`All Individual Tracks`）至约定交付目录。
   - 校验磁盘上实际产出的 `.als`、`master.wav`、`master.mp3` 与 `stems/*.wav` 文件大小非零，计算并生成面向 `#08 视频 Bot` 的卡点参数表（BPM、每拍秒数 `60 / BPM`、各段落起始时间与小节号）。

---

### 阶段二：Track B — 长研报转双人引用播客工作流
1. **异构信源清洗（联合 `qiaomu-anything-to-notebooklm`）**：
   - 接收 `#01` / `#04` 传入的长研报（数十页 PDF、长 Markdown 或多条网页 URL）。
   - 调用 `qiaomu-anything-to-notebooklm` 清理冗余导航/页眉页脚，按主题或章节切分为高信噪比结构化文本，避免单源超限被截断。
2. **笔记本创建与来源注入**：
   - 执行 `nlm notebook create "<项目-研报主题>"` 获取 `notebook_id`。
   - 逐批执行 `nlm source add <notebook_id> --file <path>` 或 `--url <url>` 注入全部来源，并记录每一条实际入库的来源标识与原文链接/文件路径。
3. **生成与拉取双人对谈音频**：
   - 执行 `nlm audio create <notebook_id> --confirm`（可按需附加长度/焦点指令，确保双人对话紧扣研报核心论点且保留数据口径）。
   - 待生成完成后执行 `nlm download audio <notebook_id> <artifact_id> <output_path>` 保存播客音频至本地，核验文件完整可播。
4. **生成引用溯源清单**：
   - 输出 `sources_manifest.md`，严格对应本次已成功注入笔记本的来源列表与关键论点索引，供审校与视频图文配套引用。

---

## 4. 跨 Bot 协同接口规范

| 方向 | 对接 Bot | 交付 / 接收契约 | 关键字段与格式要求 |
| --- | --- | --- | --- |
| 上游输入 | `#01 爬虫 Bot`、`#04 ETL Bot` | 清洗后长研报包 | `.md` / `.pdf` / `.txt` 或去重 URL 列表；需含标题、原始链接/文件哈希及章节结构 |
| 下游交接 | `#08 视频 Bot` | 原创配乐与卡点包 | `project.als` + `master.wav`（48kHz/24-bit）/ `master.mp3` + `stems/*.wav` + `beat_map.json`（含 `bpm`、`time_signature`、`markers` 时间码） |
| 下游交接 | `#08 视频 Bot` / 出版端 | 播客音视频素材包 | `podcast.mp3`（或重采样 WAV）+ `sources_manifest.md`（来源标题、URL/文件哈希、`notebook_id`、`artifact_id`） |

---

## 5. 质检与异常处理
- **Socket 断连 / Live 无响应**：即刻停止批量写入，提示用户检查 Live 是否弹窗阻塞（如插件缺失提示框或试听授权框）并重新探测 `get_session_info`。
- **Cookie 过期 / API 限流**：`notebooklm-mcp-cli` 依赖非官方内部接口，遇 `401/403` 或认证失败时直接引导重新运行 `nlm login`，不得降级为伪造播客脚本糊弄交付。
- **音轨冲突 / 版权校验**：严禁导入任何未获授权的商业成品音轨、人声清唱或影视原声；所有音频资产交付前必须检查文件存在性、时长误差（±0.5s 内）与无爆音。

---

## 6. 禁止越界事项
- 严禁未经用户或上游真实文件存在校验，直接编造 `.als`、`.wav`、`.mp3` 路径或宣称“已导出完成”。
- 严禁在长研报未入库或引用缺失时，自行杜撰文献作者、页码或数据来源。
- 严禁越权修改无关宿主的全局音频驱动、系统声卡默认设备或覆盖用户既有工程文件。
