---
name: crawl4ai-web-harvest
description: 使用 unclecode/crawl4ai 与 browser-use/browser-use 将静态网页、动态 SPA 与授权登录页转化为去噪 Markdown/JSON 语料及可复现脚本，服务 #04 文档 ETL、#22 双人播客与 #23 量化投研的一手信源供给。
---

# 网页信源爬取与降噪（crawl4ai-web-harvest）

## 1. 触发条件

当用户或上游流程出现以下任一需求时启用本技能：
- 需要抓取指定网页、文档站、新闻流、公告页或研报页面，并去除导航栏、广告、页脚、脚本等 HTML 噪音以节省大模型 Token；
- 目标站点为 SPA（React/Vue/Next.js 等前端渲染）、依赖点击展开/异步加载/分页跳转，或需要使用用户本人提供的合法登录态（Cookie / `storage_state.json`）；
- 需要为下游 `#04 文档 ETL`、`#22 双人播客`、`#23 量化投研` 准备附带来源 URL、抓取时间、SHA-256 校验哈希与可复现脚本的一手语料包。

---

## 2. GitHub 开源底座与关联工具栈

- **静态降噪主力**：`unclecode/crawl4ai`（Python SDK `AsyncWebCrawler` + `PruningContentFilter` + `DefaultMarkdownGenerator`，以及 `crwl` CLI）。
- **动态交互主力**：`browser-use/browser-use`（结合 Playwright Chromium 执行自然语言或脚本化点击、翻页、等待渲染与状态提取）。
- **参考 MCP 插件**：
  - `firecrawl`（云端/本地化网页转 Markdown 备选通道）；
  - `playwright`（精确 DOM 选择器、翻页按钮、网络空闲等待控制）；
  - `chrome-devtools`（排查 XHR/GraphQL 接口、控制台报错与真实响应载荷）；
  - `tavily`（当用户仅给出研究主题而非明确 URL 时，用于前置全网检索定位信源 URL）。

---

## 3. 前置检测与缺失报错引导（Fail-Fast）

开始抓取前必须先做就绪检测，**任一必需条件未满足时立即停止并一次性给出完整修复指引，严禁伪造抓取结果**：

1. **底座检测**：
   - 静态任务检查 `python -c "import crawl4ai"` 或 `crwl --help`（或已挂载的 `firecrawl` MCP）。
   - 动态任务检查 `browser-use --doctor` / `playwright` / `chrome-devtools` MCP 是否可用。
   - 若缺失，一次性提示安装命令：
     - Crawl4AI：`pip install -U crawl4ai && crawl4ai-setup && crawl4ai-doctor`
     - Browser Use：`pip install "browser-use[cli]" && playwright install chromium`
2. **凭证与登录态检测**：
   - 使用 `firecrawl` / `tavily` MCP 或需要 LLM 驱动 `browser-use` 时，检查对应环境变量（如 `FIRECRAWL_API_KEY`、`TAVILY_API_KEY`、`OPENAI_API_KEY` 等）是否已配置；缺失则列出环境变量名并停止。
   - 目标页面存在登录墙时，要求用户提供本地合法导出的 Playwright `storage_state.json` 或确认在可视化浏览器中完成个人登录，绝不向用户索要明文密码。

---

## 4. 分步执行 SOP

### Step 1：输入契约与采集范围确认
- 明确以下要素：目标 URL（或经 `tavily` 检索并由用户确认后的 URL 清单）、目标字段/正文边界、是否需要翻页（最大页数上限）、输出目录（默认 `artifacts/harvest/<job_id>/`）及目标下游（`#04` / `#22` / `#23`）。
- 设定保守抓取速率（单域名串行或低并发，必要时加随机延时），严禁对目标站点施压。

### Step 2：分级路由采集
- **路径 A — 静态/常规渲染（默认优先）**：
  - 优先使用 `crawl4ai` 的 `AsyncWebCrawler` 配合 `PruningContentFilter` 与 `DefaultMarkdownGenerator`，并配置 `excluded_tags=["form", "header", "footer", "nav", "aside"]` 抽取 `fit_markdown`；
  - 单页快速探索可用 `crwl <url> -o markdown`。
- **路径 B — 动态 SPA / 交互翻页 / 接口嗅探**：
  - 若路径 A 返回空壳（仅含骨架屏、`Please enable JavaScript` 或正文字符数过低），升级至路径 B：
  - 需要多步点击、筛选或登录态页内浏览时，调用 `browser-use` 或 `playwright` 等待目标选择器出现并触发“加载更多”/分页；
  - 若前端通过 JSON API 渲染关键数据（如财报、公告列表、行情表），优先使用 `chrome-devtools` 观察网络请求后在合法会话内直接提取结构化 JSON。

### Step 3：去噪清洗与元数据封装
- 剔除残余页眉页脚、社交分享按钮、空链接与重复段落。
- 为每个抓取页面生成两个配对文件：
  1. `<slug>.md`：含标准 YAML Frontmatter（`source_url`、`title`、`fetched_at`、`engine`、`sha256`）与去噪 Markdown 正文；
  2. `<slug>.json`：结构化 JSON（包含上述元数据 + `content_markdown` + `char_count` + 可选提取字段 `structured_data`）。
- 校验规则：`sha256` 必须由最终写入的正文 UTF-8 字节实时计算，严禁手填或复用旧值。

### Step 4：固化可复现脚本与汇总清单
- 将本次实测成功的采集逻辑保存为独立脚本 `scripts/harvest_<job_id>.py`（含配置参数、过滤阈值与输出规范），确保后续可直接重跑复现。
- 生成目录级索引 `manifest.json`，汇总任务 ID、总页数、成功/阻断状态、所有产物路径与 SHA-256 清单。

---

## 5. 跨 Bot 协同接口（Upstream / Downstream Contracts）

### 上游输入契约（接收来自用户或上游调度 Bot）
- `urls`: `string[]`（必填，或经确认的搜索候选集）
- `mode`: `"auto" | "static" | "dynamic"`（默认 `auto`：先静态，失效再动态）
- `max_pages`: `number`（默认 `10`，防止深度爬取失控）
- `downstream_target`: `"#04-etl" | "#22-podcast" | "#23-quant" | "general"`

### 下游交接产物契约（交付给协同 Bot）
统一交付目录：`artifacts/harvest/<job_id>/`（含 `manifest.json`、`corpus/*.md`、`corpus/*.json`、`scripts/harvest_<job_id>.py`）。

| 下游 Bot | 消费文件 | 关键交付要求与字段保证 |
| :--- | :--- | :--- |
| `#04 文档 ETL` | `manifest.json` + `corpus/*.md` | 保证零 HTML 杂讯、完整 Markdown 标题层级（`#`/`##`/`###`）与 UTF-8 编码；附 `sha256` 供增量去重与向量分块校验。 |
| `#22 双人播客` | `corpus/*.json` | 保留干净可读的叙事正文、核心观点段落、原文标题与 `source_url` 引用锚点，去除表格碎片与页内广告干扰，便于直接提炼双人对谈脚本。 |
| `#23 量化投研` | `corpus/*.json` + `manifest.json` | 精确保留抓取 UTC 时间戳（`fetched_at` ISO-8601）、原始出处 URL（`source_url`）、数值表格与公告发布时间字段，确保投研回溯可审计。 |

---

## 6. 质检与异常处理

- **空壳或截断检测**：若提取后有效字符数异常偏低（例如 `< 150` 字符且非短公告）或包含大量登录提示/骨架词，判定为未完整渲染，必须切换动态引擎重试或明确标记 `PARTIAL`。
- **反爬与人机校验**：遇到 Cloudflare Turnstile、reCAPTCHA、滑块验证码、403/429 频控或强制付费墙时，**立即停止该 URL 抓取并上报 `BLOCKED`**，保留失败 HTTP 状态/页面提示说明，交由用户接管验证或更换授权源。

---

## 7. 禁止越界事项

- 绝不绕过 CAPTCHA、人机校验、DRM 或付费墙；
- 绝不伪造或补全未抓取到的段落、数据或时间戳；
- 绝不在脚本或输出文档中写入明文 API Key、Cookie 值或账号密码；
- 绝不执行未授权的高频并发扫描或越权渗透行为。
