---
name: n8n-lark-hitl
description: 整合 czlonkowski/n8n-mcp（3,501 节点与 2,352 模板）与飞书官方 larksuite/lark-openapi-mcp（@larksuiteoapi/lark-mcp），自动编排、校验并部署带 Human-in-the-Loop（HITL）飞书审批卡片与多维表格台账同步的 n8n 工作流。高风险节点未拿到有效批准回调前严禁放行下游。
---

# n8n 与飞书人机审批（n8n-lark-hitl）

## 1. 触发条件

满足以下任一场景时触发本技能：
1. 用户要求生成、重构或审查包含敏感操作（退款、外发消息/邮件、资金付款/采购、工作流上生产/变更配置）的 n8n 自动化工作流；
2. 跨 Bot 流水线（如 C2M 无人车间异常退款/大额耗材采购/排程变更、财务对账出款、运营批量外发）需要接入飞书人机审批闭环与台账留痕；
3. 需要对既有 n8n 工作流进行节点合规定位、`validate_workflow` 静态校验，或通过 `n8n_list_executions` / `n8n_get_execution` 排查审批挂起与执行失败问题。

---

## 2. 开源底座与前置环境检测

本技能依赖以下两套真实开源 MCP 服务，启动任何编排或部署动作前**必须先执行前置检测**：
- **n8n 底座**：`czlonkowski/n8n-mcp`（覆盖 3,501 节点与 2,352 套模板）
- **飞书底座**：`larksuite/lark-openapi-mcp`（npm 包 `@larksuiteoapi/lark-mcp`）

### 前置门禁检查清单

1. **工具可用性检查**：确认当前会话已挂载 `n8n-mcp`（含 `search_nodes`、`validate_workflow` 等）及 `lark-mcp`（含 `im.v1.message.create`、`bitable.v1.appTableRecord.*` 等）。
2. **实例与权限检查**：
   - 部署/读取线上工作流前，确认 `N8N_API_URL` 与 `N8N_API_KEY` 已配置且可连接；
   - 发送飞书卡片与写入台账前，确认飞书应用 `APP_ID` / `APP_SECRET` 已就绪，目标 `chat_id`/`open_id` 及多维表格 `app_token`/`table_id` 已知，且飞书开放平台已配置卡片回调地址与签名校验。
3. **缺失阻断原则**：若检测到任一 MCP 未安装、环境变量缺失或缺少飞书目标 ID，**立即停止**，一次性列出缺失项与配置步骤（参考 `references/stack-and-sop.md`）交由用户补齐，绝不编造节点执行结果或伪造假回调。

---

## 3. 分步执行 SOP

### Step 1：需求拆解与高风险节点识别
扫描目标业务流或用户提供的 Workflow JSON，显式标出全部高风险动作并归类：
- `refund`：退款、退货打款、订单冲正；
- `outbound`：客户群发、对外商务邮件、社媒/工单公开回复；
- `payment`：付款、转账、采购下单、API 扣费触发；
- `prod_deploy`：工作流 `active` 状态切换上线、生产库写入、权限变更。

### Step 2：节点检索与模板复用（严禁凭记忆写 JSON）
1. 调用 `search_templates` 检索近似场景模板（如 Webhook + Wait + HTTP Request/Approval）；
2. 对每个拟用节点调用 `search_nodes` 与 `get_node`（优先 `standard` 级别）核实准确 `type`、`typeVersion` 及必填参数；
3. 核对飞书多维表格字段结构（调用 `bitable.v1.appTableField.list`），确保台账字段齐全。

### Step 3：强制注入 HITL 审批网关
在每一个高风险节点之前，插入不可绕过的串行门禁链：
1. **载荷冻结与摘要**：通过 `Set` / `Code` 节点固化待执行参数（金额、收款方、外发正文、目标工作流版本），生成唯一 `approval_id` 与载荷哈希 `payload_sha256`。
2. **台账预登记（`PENDING`）**：调用 `bitable.v1.appTableRecord.search` 按 `request_id` 查重；无重复时调用 `bitable.v1.appTableRecord.create` 写入状态 `PENDING`。
3. **飞书审批卡片下发**：通过 `im.v1.message.create` 向指定审批人/群发送交互式卡片，展示：风险类别、业务摘要、金额/影响范围、`payload_sha256` 前 8 位、关联 `$execution.resumeUrl` 的「批准放行」与「驳回阻断」回调动作。
4. **n8n `Wait` 阻塞等待**：配置 `Wait` 节点（`On Webhook Call`），设置明确超时阈值（如 `24h` 或业务 SLA），超时默认流向拒止分支（Timeout = Deny）。
5. **回调验签与严格分支路由**：
   - 校验回调来源签名/Token、审批人是否在授权名单、返回 `payload_sha256` 与冻结值是否一致；
   - `IF decision === "APPROVED"`：更新多维表格为 `APPROVED`（记录 `approver_id` 与 `decided_at`），方才放行下游动作；
   - `ELSE`（`REJECTED` / `TIMEOUT` / 验签失败）：更新台账为 `REJECTED` 或 `TIMEOUT`，直接终止下游执行并向发起方回传阻断告警。

### Step 4：工作流静态校验与安全部署
1. 调用 `validate_workflow` 对完整工作流执行静态校验，修复所有参数缺失、断连、非法表达式，直至零 Error；
2. 若用户要求落库到 n8n 实例，调用 `n8n_create_workflow` 或 `n8n_update_workflow` 部署，**强制默认 `active: false`（草稿/测试态）**；
3. 若需上线激活（`prod_deploy`），该动作本身必须经过独立审批或用户明确指令确认后方可执行。

### Step 5：运行时排查（按需）
当用户反馈某次审批卡滞或执行失败时，调用 `n8n_list_executions` 定位异常 `execution_id`，再用 `n8n_get_execution` 提取报错节点堆栈与飞书台账状态比对，给出精准修复补丁，禁止对已失败的高风险支付/退款单盲目自动重放。

---

## 4. 跨 Bot 协同接口契约

当本技能作为跨赛道流水线或「C2M 无人车间」风险闸门被上游 Bot（如接单客服、财务对账、切片排程等）调用时，严格执行以下输入/输出契约：

### 上游输入契约（Upstream Request Payload）
```json
{
  "request_id": "req_20261118_0001",
  "source_bot": "upstream-bot-slug",
  "risk_category": "refund | outbound | payment | prod_deploy",
  "n8n_workflow_id": "可选，既有工作流ID或留空新建",
  "payload_summary": "为订单 #ORD-8821 发起部分退款 128.50 元（PLA 耗材打印瑕疵）",
  "amount_cny": 128.50,
  "artifact_refs": [
    { "type": "order_snapshot", "uri": "bitable://app/tbl/rec", "sha256": "..." }
  ],
  "payload_sha256": "<冻结业务参数JSON的SHA-256>",
  "approver_target": { "receive_id_type": "chat_id", "receive_id": "oc_xxx" },
  "sla_minutes": 120
}
```
- `amount_cny` 单位统一为人民币元（保留两位小数，非资金类传 `0`）；尺寸或物料关联凭证若附带于 `artifact_refs`，需保留原始单位（如 `mm`）与 `sha256` 校验值。

### 下游交接产物格式（Downstream Handoff Artifact）
```json
{
  "approval_id": "apr_20261118_9f3a",
  "request_id": "req_20261118_0001",
  "workflow_id": "wf_142",
  "execution_id": "exec_9081",
  "risk_category": "refund",
  "decision": "APPROVED | REJECTED | TIMEOUT | PENDING",
  "approver_id": "ou_xxxxxxxx",
  "decided_at": "2026-11-18T15:30:00+08:00",
  "payload_sha256": "<与上游一致的SHA-256>",
  "bitable_record_id": "recxxxxxxxx",
  "feishu_message_id": "om_xxxxxxxx",
  "approval_token": "<仅在 APPROVED 时签发的一次性放行凭据，未批准时为 null>"
}
```
- **铁律**：下游执行节点或下游 Bot 必须校验 `decision === "APPROVED"`、`approval_token !== null` 且 `payload_sha256` 与原始请求完全一致；缺失或不一致一律拒止。

---

## 5. 质检与异常处理

- **静态校验失败**：必须修正 Schema 后重新通过 `validate_workflow`，不得跳过校验交付 JSON。
- **飞书写入/发卡失败**：检查应用权限（`im:message`、`bitable:app`）与机器人是否已拉入目标审批群；失败时工作流必须走 `Fail-Closed`（默认阻断），绝不因通知失败而默认放行。
- **重复回调/重放攻击**：通过台账 `approval_id` 当前状态判断（仅 `PENDING` 允许流转至终态），二次回调直接幂等忽略并记录告警。

---

## 6. 禁止越界事项

1. **严禁越权放行**：未拿到真实且验签通过的飞书 `APPROVED` 回调前，绝不允许执行退款、外发、付款或上生产下游动作。
2. **严禁伪造实测数据**：未连接真实 MCP 实例时，不得虚构 `workflow_id`、`om_xxx` 消息回执或宣称已部署成功，应明确标注为「离线校验方案」或「缺失配置阻塞」。
3. **严禁明文落盘密钥**：输出的 JSON 与文档中所有凭证一律使用占位符或 n8n Credential 引用。
