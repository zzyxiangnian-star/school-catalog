---
name: pstack-poteto-help
description: Guides users through pstack setup, $pstack-poteto-mode, and picking the skill, playbook, or principle for a task. Type $pstack-poteto-help with a question.
---

# Poteto help

Answer the user's question about pstack, hand them a prompt they can send, and link the file the answer came from. For a help question, don't start the work. The user asked how, and a pstack run spends real tokens, so let them send the prompt.

A message that asks for work, such as "use pstack to fix this bug", is not a help question. Read [`pstack-poteto-mode`](../pstack-poteto-mode/SKILL.md), do the work under it, and mention once that a Custom Mode keeps it on.

This file maps questions to the skills and guide pages that hold the answers. Those files own the details. Read the file you route to before you quote it, and trust it when it disagrees with this map. The links here point into the installed plugin, which the user may not be able to open, so give the user the file's public copy: `https://github.com/cursor/plugins/blob/main/pstack/` followed by its path.

## Find out what they need

Infer the need from the message and the conversation. A named situation, such as "which skill reviews a PR?", goes straight to its section. If the need is still unclear, ask one multiple-choice question with these options, then answer only the section they pick:

- Get set up
- Start a task with `$pstack-poteto-mode`
- Pick a skill for a situation
- Fix a run that went wrong
- Make pstack my own

Check the state that changes the answer, and mention it only when it does:

- No `~/.cursor/rules/pstack-models.mdc` means `$pstack-setup-pstack` hasn't run for this user, so every role uses its default model.
- No `verify-*` skill or other app harness in the project means agents have no scripted way to drive the app. Mention `$pstack-create-verification-skill` when the question is about proving a change works.

When the model rule is missing and it matters, ask whether the user wants to pick a model for each role and a reasoning budget now. It matters when the user is new, the question is about setup or cost, or the answer depends on which models run. Ask at most once per chat. If the need is also unclear, ask both questions together. Offer two choices:

- Now: give them `$pstack-setup-pstack` to type, and answer their question too.
- Later: answer their question, and add one line saying every role keeps its default model until they run `$pstack-setup-pstack`.

## Get set up

1. Install with `/add-plugin pstack` in chat, or from Customize in the sidebar.
2. Run [`$pstack-setup-pstack`](../pstack-setup-pstack/SKILL.md). It asks for a reasoning budget, maps a model to each role, and writes a rule. The rule applies to new chats.
3. Start a real task with `$pstack-poteto-mode`, a goal, and a check that can pass or fail.

Installing changes nothing until the user invokes a skill. Only `$pstack-setup-pstack` loads from the user's words. The [README](https://github.com/cursor/plugins/blob/1b6d44ff26d4e242f4e8f68c391e6d2f7ca16def/pstack/README.md) and [guide page 1](https://github.com/cursor/plugins/blob/1b6d44ff26d4e242f4e8f68c391e6d2f7ca16def/pstack/docs/guide/01-setup.md) have the details. Offer to word their first prompt with them, per [`references/prompting.md`](references/prompting.md).

If cost is the worry, say where the tokens go and how to spend fewer. pstack spends extra tokens on subagents and review panels. Rerun `$pstack-setup-pstack` and pick a smaller budget or cheaper models. A role set to `auto` or `inherit-parent` runs on the chat's model, which saves tokens when the chat runs on Auto or a cheaper model. A shorter panel list runs fewer subagents, one for each entry. Save `$pstack-poteto-mode` for work that needs rigor.

pstack is built for Cursor. Its skills use the Agent Skills format, so other tools can read them. But most workflow skills, including `$pstack-poteto-mode`, `$pstack-how`, `$pstack-why`, and `$pstack-teach`, spawn Cursor subagents with per-role models, and Custom Modes and `/loop` are Cursor features, so those parts may not work there.

## Start a task with `$pstack-poteto-mode`

`$pstack-poteto-mode` matches the task to a playbook, copies the playbook's steps into the todo list, and runs the other skills as the steps need them. A step it skips stays in the list as `skip: <reason>`. A good prompt states the goal and how to tell it's done. It doesn't list skills, because a hand-written sequence tends to drop or reorder steps the playbook would keep. Read [`references/prompting.md`](references/prompting.md) before you help word one. [Guide page 2](https://github.com/cursor/plugins/blob/1b6d44ff26d4e242f4e8f68c391e6d2f7ca16def/pstack/docs/guide/02-poteto-mode.md) has examples.

Whether `$pstack-poteto-mode` stays on depends on how the user starts it:

- Enter on `$pstack-poteto-mode` attaches the skill to one message. It fades as the chat moves on.
- Option+Enter on Mac or Alt+Enter on Windows, or Use as Mode from the skill entry, makes it a Custom Mode. It stays in context every turn until the user exits the mode, and it stays out of casual turns.
- Cursor's docs list Custom Modes in the Agents Window and the CLI. Elsewhere, start each new task with `$pstack-poteto-mode`.

Link [Cursor's skills docs](https://cursor.com/docs/skills) when this comes up. Mid-chat, "new task" makes the mode match a fresh playbook. `$pstack-poteto-mode` already uses `poteto-agent` for the subagents its playbook steps spawn. To get the same style from a subagent of your own, spawn it with `subagent_type: "poteto-agent"`.

## Pick a skill

The default answer is `$pstack-poteto-mode`, which runs most of the others when its steps need them. Name a skill directly when the user wants more or less of something than the playbook gives. Read the skill before you recommend it, and give one example prompt.

| The user wants to | Skill |
|---|---|
| Do any non-trivial task with rigor | [`$pstack-poteto-mode`](../pstack-poteto-mode/SKILL.md) |
| Know how code works now, or where new code should live | [`$pstack-how`](../pstack-how/SKILL.md) |
| Know why code is shaped this way, or where a number came from | [`$pstack-why`](../pstack-why/SKILL.md) |
| Understand a change or subsystem, explained plainly | [`$pstack-teach`](../pstack-teach/SKILL.md) |
| Catch up on their own recent work on a topic | [`$pstack-recall`](../pstack-recall/SKILL.md) |
| Catch up on everything in this chat since their last message, with enough context to decide each action item | [`$pstack-ketchup`](../pstack-ketchup/SKILL.md) |
| Know what a small diff could break outside itself | [`$pstack-blast-radius`](../pstack-blast-radius/SKILL.md) |
| Settle types and module shape before code that crosses a function boundary | [`$pstack-architect`](../pstack-architect/SKILL.md) |
| Get several attempts at one brief, merged into the best one | [`$pstack-arena`](../pstack-arena/SKILL.md) |
| Run parallel checks over slices, or race workers, as cloud agents | [`$pstack-swarm`](../pstack-swarm/SKILL.md) |
| Have different models review a diff and try to break it | [`$pstack-interrogate`](../pstack-interrogate/SKILL.md) |
| Fix a bug test-first when a cheap local test exists | [`$pstack-tdd`](../pstack-tdd/SKILL.md) |
| Apply TypeScript rules to `.ts` or `.tsx` work | [`$pstack-typescript-best-practices`](../pstack-typescript-best-practices/SKILL.md) |
| Strip comments before review, using a reviewer that didn't write them | [`$pstack-no-comments`](../pstack-no-comments/SKILL.md) |
| Clean AI tells out of prose | [`$pstack-unslop`](../pstack-unslop/SKILL.md) |
| Write docs, an RFC, a README, a PR description, or a commit message to a standard | [`$pstack-technical-writing`](../pstack-technical-writing/SKILL.md) |
| Hear the last reply again in plain words | [`$pstack-bro`](../pstack-bro/SKILL.md) |
| Give agents a scripted way to drive the app and prove behavior | [`$pstack-create-verification-skill`](../pstack-create-verification-skill/SKILL.md) |
| Bring a verification skill and its feature map back in line with the app | [`$pstack-maintain-verification-skill`](../pstack-maintain-verification-skill/SKILL.md) |
| Vet a performance number before reporting or acting on it | [`$pstack-benchmark-checklist`](../pstack-benchmark-checklist/SKILL.md) |
| Run a large or cross-cutting change, or one to review after stepping away | [`$pstack-figure-it-out`](../pstack-figure-it-out/SKILL.md) |
| Keep a decision log during a run, and review it afterward | [`$pstack-show-me-your-work`](../pstack-show-me-your-work/SKILL.md) |
| Pick a model for each role and a reasoning budget | [`$pstack-setup-pstack`](../pstack-setup-pstack/SKILL.md) |
| Turn their own working habits into a personal mode skill | [`$pstack-automate-me`](../pstack-automate-me/SKILL.md) |
| Turn what a finished task taught into skill edits | [`$pstack-reflect`](../pstack-reflect/SKILL.md) |
| Stop agents from repeating the same mistakes in this repo | [`$pstack-correct`](../pstack-correct/SKILL.md) |
| Build a page whose buttons wake a Grok Bot over a webhook | [`$pstack-make-bot-ui`](../pstack-make-bot-ui/SKILL.md) |
| Find their way around pstack | `$pstack-poteto-help` |

If a skill directory next to this one is missing from the table, read its frontmatter and route by its description. The `principle-*` directories are covered under principles below.

Close calls:

- `$pstack-how` explains what the code does. `$pstack-why` explains the reasons. `$pstack-teach` runs one or both and explains the result plainly.
- `$pstack-arena` gives every worker the same brief and merges the best parts. `$pstack-swarm` splits work into slices or a race and returns one report.
- `$pstack-architect` implements right after it settles the design. Add "with checkpoint" to review the design before it writes code.
- `$pstack-interrogate` reviews the diff. `$pstack-blast-radius` looks for breakage outside the diff and proves the one fact that makes the change safe.
- `$pstack-recall` rebuilds context across recent chats. `$pstack-ketchup` covers only this chat since the user's last message. Resuming one specific chat or branch is the Session pickup playbook.
- `$pstack-figure-it-out` designs one rigorous run. The Orchestrate playbook runs a program that spans days and many PRs. The Autonomous run playbook drives one task to a finish condition.

Not in pstack:

- `/deslop`, `control-cli`, and `control-ui` ship in the `cursor-team-kit` plugin.
- `/loop` and `/create-skill` are Cursor built-ins.
- pstack has no `/orchestrate` skill. Orchestrate is a `$pstack-poteto-mode` playbook. If the slash menu shows `/orchestrate`, another plugin provides it.

## Playbooks and principles

Playbooks are step lists inside `$pstack-poteto-mode`, not skills, so they have no slash command. Inside `$pstack-poteto-mode`, describing the task picks one, and these phrases name one directly:

- "babysit this pr" or "check on pr 123" runs Babysit. It drives the PR to merge-ready and stops there. It doesn't merge unless the user asks to merge, land, or ship.
- "land the stack" runs Shipping.
- "take over this branch" runs Session pickup.
- "pause safely" runs Pause safely.
- "full autopilot on this queue" runs Autopilot-full. "stack them, don't ship" runs Autopilot-stack.
- "run the eval playbook" runs Eval.

Without `$pstack-poteto-mode`, a phrase such as "babysit this pr" can start Cursor's own skill for the same job instead. The Playbooks section of [`pstack-poteto-mode`](../pstack-poteto-mode/SKILL.md) lists every playbook and when it applies. [Guide page 6](https://github.com/cursor/plugins/blob/1b6d44ff26d4e242f4e8f68c391e6d2f7ca16def/pstack/docs/guide/06-verify-and-ship.md) covers opening, babysitting, and landing a PR.

pstack has no planning skill. Cursor's Plan Mode works alongside it. For work that spans phases or stacked PRs, asking `$pstack-poteto-mode` for a plan runs the [Multi-phase plan playbook](../pstack-poteto-mode/playbooks/multi-phase-plan.md), which writes the plan and doesn't implement it. For a design question, the Prototype playbook or `$pstack-architect` settles it in code first.

Principles are one-rule skills that `$pstack-poteto-mode` reads and cites in its replies. The user rarely invokes one. They steer with the names instead, as in "apply prove it works. show me the real output." Typing `/principle-<name>` still loads one on demand. [Guide page 8](https://github.com/cursor/plugins/blob/1b6d44ff26d4e242f4e8f68c391e6d2f7ca16def/pstack/docs/guide/08-principles.md) lists them.

## Fix a run that went wrong

| Symptom | Fix |
|---|---|
| The mode stopped applying after a few turns | It was started with Enter. Start it as a Custom Mode, or start each task with `$pstack-poteto-mode`. |
| A question got treated as the next step of the last task | Say "new task", or say the turn doesn't need the mode. |
| A new model choice had no effect | The rule from `$pstack-setup-pstack` applies to new chats. Start one. |
| Runs cost more than expected | See the cost paragraph under Get set up. |
| A skill didn't load on its own | Only `$pstack-setup-pstack` loads from the user's words. The others load when the user types them or when `$pstack-poteto-mode` runs them, and it doesn't run every skill. |
| Parallel agents overwrote each other | Give each agent its own worktree, or run them as cloud agents, which each get their own machine. |
| An overnight run moved but finished nothing | `/loop` needs a check that can pass or fail, not a duration. See [guide page 7](https://github.com/cursor/plugins/blob/1b6d44ff26d4e242f4e8f68c391e6d2f7ca16def/pstack/docs/guide/07-overnight.md). |
| The reply claims success from a green build | Ask for the real command, flow, stored value, or profile. That's the prove-it-works principle. |

For a run that drifts, [`references/prompting.md`](references/prompting.md) has one-line steers. [Guide page 10](https://github.com/cursor/plugins/blob/1b6d44ff26d4e242f4e8f68c391e6d2f7ca16def/pstack/docs/guide/10-recipes-and-pitfalls.md) has more pitfalls and the recipes worth copying.

## Make pstack my own

- [`$pstack-automate-me`](../pstack-automate-me/SKILL.md) drafts a personal mode skill from the user's own history, to use alongside `$pstack-poteto-mode`.
- [`$pstack-reflect`](../pstack-reflect/SKILL.md) after a session turns its lessons into skill edits the user approves.
- `$pstack-poteto-mode write a skill for <workflow>` runs the authoring playbook. The eval playbook tests a skill change blind.
- Fix a misbehaving skill in its own PR, not inside the feature work where it went wrong.

[Guide page 9](https://github.com/cursor/plugins/blob/1b6d44ff26d4e242f4e8f68c391e6d2f7ca16def/pstack/docs/guide/09-make-it-yours.md) covers each of these.

## Reply

Lead with the answer. Give at most one example prompt in a code block, adapted from [`references/recipes.md`](references/recipes.md) when one fits, then the link to that file. Keep it short unless the user asked for the whole map.

## pstack in OpenBot

- This skill is part of pstack. OpenBot installs each pstack skill as its own skill: the skill `<name>` is `pstack-<name>`. A principle `<name>` is `pstack-principle-<name>`. Call a skill with `$pstack-<name>`.
- For `subagent_type: "<agent>"`, when your harness does not know that type, start a general subagent. Give it the body of `agents/<agent>.md` first, then the task.
- The license and notice are in `../pstack/LICENSE` and `../pstack/NOTICE.md`.
