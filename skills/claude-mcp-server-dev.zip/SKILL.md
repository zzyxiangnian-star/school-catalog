---
name: claude-mcp-server-dev
description: "覆盖远程/本地部署模型、协议设计及认证规范的 3 项官方 MCP 服务端构建技能。"
---

# MCP Server Dev Pack

覆盖远程/本地部署模型、协议设计及认证规范的 3 项官方 MCP 服务端构建技能。

Source: https://github.com/anthropics/claude-plugins-official

## Included Skills (3)

- `claude-mcp-server-dev-build-mcp-app`
- `claude-mcp-server-dev-build-mcp-server`
- `claude-mcp-server-dev-build-mcpb`
