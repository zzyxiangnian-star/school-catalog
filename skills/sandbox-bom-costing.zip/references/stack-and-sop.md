# 沙盒 BOM 核算参考手册（Stack & SOP）

## 1. 关联 GitHub 开源底座与生态组件

| 名称 | 类型 | 用途说明 |
| :--- | :--- | :--- |
| `e2b-dev/mcp-server` | 核心 GitHub 开源底座 | E2B 官方 MCP Server，为 Agent 提供云端隔离微虚拟机（Sandbox）中的安全 Python/Shell 代码执行能力，确保 BOM 与成本运算完全确定且可复现。 |
| `e2b` MCP 插件 | 关联 MCP 插件 | 负责建立隔离沙盒会话、上传输入表（CSV/XLSX/JSON）、运行核算脚本并拉回生成的 `.xlsx` 交付产物。 |
| `xlsx` 目录既有技能 | 联合调用技能 | 规范多 Sheet Excel 工作簿的版式、动态公式编写、数值格式（货币/百分比）及公式求值零错误校验。 |
| Python 数据与表格生态（沙盒内置） | 运行时依赖 | `pandas`（清洗网表与阶梯区间匹配）、`numpy`（敏感性矩阵向量化计算）、`openpyxl`（写入跨表公式与格式）、`LibreOffice` headless（可选：重算公式并审计错误值）。 |

---

## 2. 典型 MCP / 环境配置模板

### 2.1 `e2b-dev/mcp-server` MCP 配置示例

在客户端 MCP 配置中注册 E2B MCP Server，并注入合法的 `E2B_API_KEY`：

```json
{
  "mcpServers": {
    "e2b": {
      "command": "npx",
      "args": ["-y", "@e2b/mcp-server"],
      "env": {
        "E2B_API_KEY": "<YOUR_E2B_API_KEY>"
      }
    }
  }
}
```

> **前置自检原则**：启动任务前先探测 `e2b` MCP 工具是否可用。若返回认证失败或未连接，向用户一次性说明需配置 `E2B_API_KEY`（或切换至经用户确认的本地受控 Python 沙盒），随后立即停止并返回 `BLOCKED`，禁止假装执行成功。

### 2.2 本地受控 Python 沙盒兜底检查命令

当用户明确授权使用本地受控环境替代 E2B 时，先运行环境探针验证依赖就绪：

```bash
python -c "import pandas, numpy, openpyxl; print('SANDBOX_DEPS_OK')"
```

可选公式重算审计命令（需本机或沙盒镜像安装 LibreOffice）：

```bash
soffice --headless --convert-to xlsx --outdir ./verified ./bom_costing_output.xlsx
```

---

## 3. 确定性成本核算核心数学模型

所有计算均须在沙盒 Python 脚本中显式编码，严禁语言模型直接估算：

1. **单件有效材料成本（Material Cost）**
   - 3D 打印 / 机加工零件：
     $$\text{Cost}_{\text{mat}} = \frac{\text{Weight}_{\text{net}} \times (1 + \text{Waste\_Factor}) + \text{Weight}_{\text{support}}}{1000} \times \text{UnitPrice}_{\text{kg}}$$
   - 电子元器件 BOM（按订单批量 $Q$ 匹配阶梯区间 $[MOQ_i, Max_i]$）：
     $$\text{Cost}_{\text{part}}(Q) = \text{Qty}_{\text{per\_board}} \times \text{TierPrice}(Q \times \text{Qty}_{\text{per\_board}})$$
2. **加工与人工工时成本（Process & Labor Cost）**
   $$\text{Cost}_{\text{proc}} = \text{Time}_{\text{machine\_hr}} \times \text{Rate}_{\text{machine}} + \text{Time}_{\text{post\_hr}} \times \text{Rate}_{\text{labor}} + \frac{\text{Setup}_{\text{fee}}}{Q}$$
3. **良品率折算有效成本（Yield-Adjusted Unit Cost）**
   $$\text{Cost}_{\text{eff}} = \frac{\text{Cost}_{\text{mat}} + \text{Cost}_{\text{part}} + \text{Cost}_{\text{proc}}}{\text{Yield\_Rate}}$$
   *(注：$\text{Yield\_Rate} \in (0, 1]$，绝不允许为 0)*
4. **梯级毛利报价（Tiered Margin Pricing）**
   - 未税报价（基于目标毛利率 $M \in [0, 1)$）：
     $$\text{Price}_{\text{ex\_tax}} = \frac{\text{Cost}_{\text{eff}}}{1 - M}$$
   - 含税报价：
     $$\text{Price}_{\text{inc\_tax}} = \text{Price}_{\text{ex\_tax}} \times (1 + \text{Tax\_Rate})$$

---

## 4. 交付产物检验清单（Delivery QA Checklist）

在输出最终回复前，必须在沙盒内逐项核验并通过以下检查：

- [ ] **环境真实性**：脚本已在 `e2b` 隔离沙盒或经授权的本地受控 Python 沙盒中完整执行并退出码为 `0`。
- [ ] **动态公式覆盖率 100%**：`总览报价` 与 `BOM明细` 中的小计、良品率折算、含税/未税售价、毛利额、敏感性矩阵全部使用 Excel 原生公式（`=SUM(...)`、`=SUMPRODUCT(...)`、`=INDEX/MATCH(...)` 等），无硬编码贴死数字。
- [ ] **零公式异常**：经重算校验，工作簿所有单元格均不含 `#REF!`、`#DIV/0!`、`#VALUE!`、`#NAME?`、`#N/A`、`#NUM!`。
- [ ] **口径一致性**：全表统一币种（如 CNY/USD）、税率口径（13% 增值税/未税）及物理单位（mm / cm³ / g / PCS），且在 `核算假设` 区块显式注明。
- [ ] **跨 Bot 交接字段完整**：已生成目标 `.xlsx` 文件，计算并附带文件 `SHA-256` 校验哈希，且输出包含项目编号、基准成本、推荐报价、毛利率与交期风险提示的结构化摘要，可直接流转至下游报价上架或飞书审批节点。
