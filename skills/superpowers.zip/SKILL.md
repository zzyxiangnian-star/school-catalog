---
name: superpowers
description: "An agentic software development methodology pack featuring brainstorming, TDD, systematic debugging, plan execution, git worktrees, and subagent workflows."
---

# Superpowers

An agentic software development methodology pack featuring brainstorming, TDD, systematic debugging, plan execution, git worktrees, and subagent workflows.

Source: https://github.com/obra/superpowers

## Included Skills (15)

- `superpowers-brainstorming`
- `superpowers-diagnosing-superpowers`
- `superpowers-dispatching-parallel-agents`
- `superpowers-executing-plans`
- `superpowers-finishing-a-development-branch`
- `superpowers-receiving-code-review`
- `superpowers-requesting-code-review`
- `superpowers-subagent-driven-development`
- `superpowers-systematic-debugging`
- `superpowers-test-driven-development`
- `superpowers-using-git-worktrees`
- `superpowers-using-superpowers`
- `superpowers-verification-before-completion`
- `superpowers-writing-plans`
- `superpowers-writing-skills`
