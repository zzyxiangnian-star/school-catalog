---
name: human-resources
description: "Streamline people operations including recruiting, onboarding, performance reviews, compensation analysis, and policy guidance."
---

# Human Resources

Streamline people operations including recruiting, onboarding, performance reviews, compensation analysis, and policy guidance.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (9)

- `human-resources-comp-analysis`
- `human-resources-draft-offer`
- `human-resources-interview-prep`
- `human-resources-onboarding`
- `human-resources-org-planning`
- `human-resources-people-report`
- `human-resources-performance-review`
- `human-resources-policy-lookup`
- `human-resources-recruiting-pipeline`
