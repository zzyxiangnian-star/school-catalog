---
name: serena-repomix-surgeon
description: 面向数万行级遗留工程的 LSP 语义级代码手术技能。动手前先用 yamadashy/repomix 压出仓库骨架与依赖全景，定位与修改阶段严格使用 oraios/serena 的符号概览、定义/实现跳转、全项目引用枚举与 AST 符号级局部替换，每次手术完毕执行类型检查、单测与 change-review 最小 Git diff 复核。
---

# LSP 语义级代码手术（Serena + Repomix Surgeon）

本技能用于对中大型或数万行级遗留代码库执行**低破坏、可验证、最小 Diff** 的缺陷修复、接口演进与结构重构，彻底杜绝普通编码 Agent 修改大文件时的“盲目正则替换”和“整文件覆写丢逻辑”。

---

## 1. 触发条件与适用边界

### 适用场景
- 数千至数十万行规模遗留工程的 Bug 定位、跨文件重构、函数/类签名变更或接口拆分。
- 修改单个大文件（>300 行）中的特定方法/类，需严格保留周边历史补丁、注释与异常分支。
- 需要准确评估某个公共符号修改后对全项目所有调用方与多态实现的影响范围。

### 不适用场景
- 从零初始化全新空项目脚手架（直接编写即可，无需先枚举遗留引用）。
- 纯静态文本/文档（如普通 Markdown 博客、纯静态图片资源）的批量排版，不涉及编译器或 LSP 语义树。

---

## 2. 开源底座与前置环境检测

本技能依赖以下真实开源工具与本地环境：
1. **GitHub 开源底座**：
   - `oraios/serena`：LSP 语义级代码检索与编辑 MCP（提供符号概览、引用枚举与 AST 符号体替换）。
   - `yamadashy/repomix`：仓库骨架压缩工具（支持 `--compress` Tree-sitter 结构提取与 `--mcp` 模式）。
   - `git`：用于基线检查与最小 Diff 复核。
2. **前置就绪检测（动手前必检）**：
   - 检查 MCP/CLI 工具清单中是否存在 `serena` 工具（如 `get_symbols_overview`、`find_symbol`、`replace_symbol_body`）与 `repomix`（MCP `pack_codebase` 或本地 `npx repomix`），以及可执行 `git` 的命令环境。
   - **缺失处理铁律**：若检测到 `serena` 未连接项目、目标语言缺失对应 Language Server（如 `pyright`/`typescript-language-server`/`rust-analyzer`/`gopls`），或 `uv`/`node` 缺失：
     - **立即停止手术**，严禁退化为“用正则跨文件盲改”或“整文件覆写”。
     - 一次性向用户输出缺失项、具体配置/安装命令（参考 `references/stack-and-sop.md`）并等待用户就绪。

---

## 3. 分步执行 SOP（五阶段手术流）

### Phase 0：工作区基线与安全预检
1. 执行 `git status --short` 确认工作区状态。
2. 若存在与本次任务无关的未提交改动，先提示用户确认是否暂存或新建手术分支；记录当前起始 Commit SHA 作为回退锚点。

### Phase 1：Repomix 仓库骨架压缩与依赖全景
1. **禁止直接通读大文件全量源码**。先通过 `repomix`（推荐 MCP `pack_codebase` 传入 `compress: true`，或 CLI 执行 `npx -y repomix --compress`）按需配合 `--include` / `--ignore`（排除构建产物、锁文件与无关测试目录）压出目标模块及周边的类/函数骨架。
2. 基于压缩全景图确定：
   - 入口模块、核心数据流与外部依赖边界；
   - 本次手术涉及的候选文件列表与项目构建/测试脚本位置（如 `package.json`、`pyproject.toml`、`Cargo.toml`、`go.mod`）。

### Phase 2：Serena LSP 符号定位与全项目引用枚举
1. **文件骨架探测**：对候选文件调用 `get_symbols_overview`，获取精确的顶层类、函数、方法层级树。
2. **定义与实现跳转**：使用 `find_symbol`、`find_declaration` 与 `find_implementations` 精确定位目标符号实现体及接口派生类，必要时仅读取目标符号自身代码体。
3. **全项目引用点枚举（强制门禁）**：
   - 凡涉及修改函数签名、参数类型、返回值、类属性或重命名，必须调用 `find_referencing_symbols` 枚举全仓库所有引用位置。
   - 输出并核对“受影响符号引用清单”，确认无遗漏调用方后，方可进入施术阶段。

### Phase 3：制定最小切口方案
在正式修改前于内部或向用户明确切口清单：
- 仅列明需要动刀的 `文件路径 :: 符号名称` 及改动目的；
- 确定采用何种原子手术工具（修改函数体 / 局部前置或后置插入 / 跨文件重命名）；
- 确定术后用于验证的精确命令（类型检查命令 + 最小关联单元测试命令）。

### Phase 4：AST 符号级精准施术
严格按变更粒度选用 `serena` 符号级编辑工具，**严禁整文件覆盖写入**：
- **重写单个函数/方法/类实现体**：使用 `replace_symbol_body` 精确替换目标符号定义，确保函数外所有代码、导入语句、邻近方法及头部版权/说明注释保持逐字节不变。
- **补充辅助函数、导入或新方法**：使用 `insert_before_symbol` 或 `insert_after_symbol` 在锚点符号前后精确插入。
- **跨文件标识符重命名**：使用 `rename_symbol` 交由 LSP 执行作用域感知的全局安全重命名，禁止用字符串全局替换。
- **同步调用点**：依据 Phase 2 枚举出的引用清单，逐一在各调用符号内执行最小局部更新。

### Phase 5：术后诊断、实测与最小 Diff 复核
1. **LSP 静态诊断**：对所有修改过的文件调用 `get_diagnostics_for_file`，确保无新增语法、导入或类型报错。
2. **编译/类型检查与单测**：运行仓库真实存在的类型检查（如 `tsc --noEmit`、`pyright`、`cargo check`、`go test` 等）与相关单元测试，完整记录命令及真实退出码/结果摘要；若环境无测试脚本或某项依赖缺失，如实声明未运行原因，绝不虚构通过。
3. **联合 `change-review` 最小 Diff 复核**：
   - 执行 `git diff --stat` 与 `git diff`，调用目录既有技能 `change-review` 对本次变更进行独立自查：
     - 是否存在非预期的格式化抖动、误删注释或无关文件变更？
     - 是否满足边界条件、空值处理与错误信息规范？
   - 若发现多余改动，立即局部清理并重跑验证。

---

## 4. 跨 Bot 协同接口

### 上游输入契约（接收来自架构规划、Bug 分诊或评审 Bot 的派单）
```json
{
  "repo_path": "本地代码仓库绝对路径",
  "task_type": "bugfix | refactor | signature_migration",
  "target_symbols": ["模块路径::符号名"],
  "change_goal": "期望达成的语义或行为变更说明",
  "constraints": ["向后兼容要求、禁改文件或测试要求"]
}
```
若上游未提供完整 `target_symbols`，先通过 Phase 1 `repomix --compress` 与 Phase 2 `find_symbol` 自主补齐后再落刀。

### 下游交接产物格式（交付至 `change-review` / 发版验收 / PR 汇总 Bot）
- **手术状态**：`DONE` | `PARTIAL` | `BLOCKED`
- **基准与范围**：起始 Commit SHA、`git diff --stat` 统计
- **符号变更与引用闭合表**：已修改符号清单 + `find_referencing_symbols` 覆盖确认结果
- **实测验证凭证**：类型检查命令与输出摘要、单测命令与通过/失败计数、LSP `get_diagnostics_for_file` 状态
- **风险与静态盲区提示**：如存在动态反射、字符串拼接路由等 LSP 无法静态覆盖的调用点，显式标注待人工或动态集成测试重点验证。

---

## 5. 质检与异常处理

- **动态语言/反射/元编程盲区**：Python/JS/TS 中通过 `getattr`、动态 `import()`、装饰器或字符串路由表触发的调用，`find_referencing_symbols` 可能无法覆盖；必须在报告中显式补充关键字检索结果并标注静态分析局限。
- **LSP 索引未完成或诊断延迟**：大型仓库首次启动 `serena` 时 Language Server 可能正在索引；若 `find_symbol` 或诊断为空，先检查 LSP 状态或等待索引完成重试一次，仍异常则报告 `BLOCKED` 并提示排查语言服务器日志。
- **测试或类型检查失败**：绝不隐藏失败或删除断言以凑绿灯；定位失败原因是否由漏改引用点引起，最多进行定向修复并重新验证，若涉及超出授权范围的架构冲突，立即回滚或保持现场并报告 `PARTIAL`/`BLOCKED`。

---

## 6. 禁止越界事项

- **绝不整文件重写**：严禁使用全量 `write_file` 覆盖超过百行的现有源码文件。
- **绝不盲目正则批量改名**：在 LSP 可用时，禁止用 `sed`/正则替换跨文件重构变量或方法名。
- **绝不越权 Git 远端操作**：未经用户明确指令，禁止 `git push`、`git commit --amend`、`git reset --hard` 或强制清理未跟踪文件。
- **绝不伪造实测结果**：只报告本轮实际执行并观察到的命令输出、报错行号与测试结果。
