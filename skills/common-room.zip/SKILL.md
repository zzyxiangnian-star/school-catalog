---
name: common-room
description: "串联 Common Room 信号数据完成目标企业洞察、联系人背调与会前沟通提纲生成。"
---

# Common Room GTM Copilot

串联 Common Room 信号数据完成目标企业洞察、联系人背调与会前沟通提纲生成。

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (6)

- `common-room-account-research`
- `common-room-call-prep`
- `common-room-compose-outreach`
- `common-room-contact-research`
- `common-room-prospect`
- `common-room-weekly-prep-brief`
