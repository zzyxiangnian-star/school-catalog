# 程序化视频引擎技术底座与交付检验清单（`references/stack-and-sop.md`）

## 1. 核心 GitHub 开源底座清单

| 仓库地址 | 定位与核心能力 | 适用场景 |
| :--- | :--- | :--- |
| `heygen-com/hyperframes` | HTML-to-Video 确定性时间轴渲染引擎（Node.js 22+ / FFmpeg / Seek-safe 动效） | **默认首选**：15s–3min 产品宣发、分镜动效、音画卡点、确定性 1080p MP4 导出 |
| `remotion-dev/skills` | Remotion 官方 Agent 技能与 React 视频编程规范 | 用户明确指定 React/TypeScript 组件化视频或复用现有 Remotion 工程时启用 |
| `hypit-ai/hypit` | 基于语义锚定（SVML）与并发无头浏览器的爆款视频工作流克隆方案 | 拆解参考爆款视频结构、按词/句语义锚点批量生成多变体短视频 |

> 注：质检基准参考 explainroo 工程实践（约 2.0 min 闭环周期、4/4 关键帧视觉质检全通过后再触发终版编码）。

---

## 2. 环境前置检测与典型配置模板

### 2.1 运行时预检命令（缺失即停）

```bash
# 1. 检查 Node.js（HyperFrames CLI 要求 >= 22）
node -v

# 2. 检查 FFmpeg 与 FFprobe
ffmpeg -version
ffprobe -version

# 3. 检查 HyperFrames 引擎及无头浏览器状态（返回 .ok === true 方可通过）
npx hyperframes doctor --json
```

若 `npx hyperframes doctor --json` 报错或缺失 Chromium：
- Node.js < 22：请用户升级至 Node.js 22 LTS 及以上版本。
- 缺少 FFmpeg：引导安装 FFmpeg 并加入系统 `PATH`。
- 缺少浏览器驱动：运行 `npx playwright install chromium` 后重测 `doctor`。

### 2.2 Playwright MCP 参考配置模板

用于编码阶段预览校验及关键拍点高分辨率 DOM 截图质检：

```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["-y", "@playwright/mcp@latest"]
    }
  }
}
```

### 2.3 HyperFrames 工程常用 CLI 命令流

```bash
# 初始化工程
npx hyperframes init ./video-project

# 静态语法与时间轴检查
npx hyperframes lint

# 门禁级全量检查（含无头浏览器 seek 校验与截图）
npx hyperframes check --snapshots

# 指定关键时刻与拍点抽帧截图（例如首帧、卡点1、卡点2、尾帧）
npx hyperframes snapshot --at 0,3.2,8.5,14.9

# 迭代草稿渲染 vs 终版 1080p 交付渲染
npx hyperframes render --quality draft --output ./dist/preview.mp4
npx hyperframes render --quality delivery --output ./dist/promo_15s_1080p.mp4
```

---

## 3. 跨 Bot 协同输入/输出契约模板

### 3.1 上游 #03（Blender 3D 资产）输入契约 `asset_manifest.json`

```json
{
  "source_bot": "#03",
  "render_type": "turntable_sequence",
  "format": "png_rgba_sequence",
  "resolution": "1920x1080",
  "fps": 30,
  "frame_count": 180,
  "files_glob": "assets/3d/frame_%04d.png",
  "sha256_manifest": "assets/3d/checksums.sha256"
}
```

### 3.2 上游 #22（Ableton 音效）输入契约 `beats.json`

```json
{
  "source_bot": "#22",
  "audio_file": "assets/audio/master_15s.wav",
  "sample_rate_hz": 48000,
  "duration_sec": 15.0,
  "bpm": 128,
  "loudness_lufs": -14.0,
  "beats_sec": [0.0, 0.469, 0.938, 1.406, 1.875],
  "drops_sec": [2.812, 7.500, 12.188],
  "sha256": "<64-char-hex>"
}
```

### 3.3 下游交付清单 `delivery_manifest.json`

```json
{
  "producer_bot": "#08-programmatic-video-bot",
  "engine": "heygen-com/hyperframes",
  "output_video": "dist/promo_15s_1080p.mp4",
  "resolution": "1080x1920",
  "fps": 30,
  "duration_sec": 15.0,
  "video_codec": "h264",
  "audio_codec": "aac",
  "qc_score": "4/4",
  "qc_snapshots": [
    "qc/frame_01_start.png",
    "qc/frame_02_drop1.png",
    "qc/frame_03_feature.png",
    "qc/frame_04_end_cta.png"
  ],
  "upstream_refs": {
    "bot_03_manifest": "assets/3d/asset_manifest.json",
    "bot_22_beats": "assets/audio/beats.json"
  },
  "sha256": "<64-char-hex>"
}
```

---

## 4. 交付产物 4/4 检验清单（发布前必核）

1. **首帧可用性（1/4）**：`t=0s` 画面已完全渲染，无白屏、黑屏、字体闪烁或未加载资产占位符。
2. **拍点与动效同步（2/4）**：核心转场、`#03` 旋转高光帧与 `#22` `drops_sec` 重拍误差 ≤ ±1 帧（≤33ms @30fps）。
3. **文案安全区与可读性（3/4）**：所有标题、卖点角标及 CTA 均位于平台安全区内，无溢出裁切，对比度清晰。
4. **尾帧与音画流完整性（4/4）**：尾帧收束稳定无截断；`ffprobe -v error -show_format -show_streams` 实测分辨率为 1080p、音视频流时长一致且非空、SHA-256 哈希已记录。
