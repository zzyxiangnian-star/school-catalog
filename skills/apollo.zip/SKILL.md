---
name: apollo
description: "Anthropic 官方合作插件，串联多项 Apollo API 完成潜在客户挖掘、画像补全与外联闭环。"
---

# Apollo Sales Workflows

Anthropic 官方合作插件，串联多项 Apollo API 完成潜在客户挖掘、画像补全与外联闭环。

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (3)

- `apollo-enrich-lead`
- `apollo-prospect`
- `apollo-sequence-load`
