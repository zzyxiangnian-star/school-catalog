# 单片机与硬件原型助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- jl-codes/platformio-mcp — MIT（v3.1.0，支持 `agent_safe_pin_audit` 与审批策略）
- arduino/arduino-cli — GPL-3.0（轻量化 Arduino/ESP32 备选外置 CLI）

## 2. 本机前置准备

- Node.js >= 20、PlatformIO Core CLI 及国产常见 CH340/CP2102 USB 转串口驱动
- 国内可通过 npmmirror 安装 `platformio-mcp`；首次下载 ESP32 工具链建议配合国内镜像源或提前缓存
- 保持 `.pio-mcp-policy.json` 中的 `flash_requires_approval` 为开启状态

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
{
  "mcpServers": {
    "platformio": {
      "command": "npx",
      "args": ["-y", "platformio-mcp", "serve"]
    }
  }
}

// 项目根目录建议保留 .pio-mcp-policy.json：
{ "flash_requires_approval": true }
```

## 4. 合规与物理安全核查项

- 默认强制锁定 `flash_requires_approval`，禁止未获当次明确批准直接刷机。
- 明确警示电源反接、VCC-GND 短路与锂电池大电流回路防烧板与热失控操作守则。

## 5. 已排除的过时或高风险方案

- 缺乏安全烧录审批闸门的早期裸串口刷机脚本
- 强依赖海外在线仿真的闭源云端嵌入式接口

## 6. 交付产物检验清单

- [ ] 所有外设 3.3V / 5V 电平与总电流已在接线表核对无误，且含共地提醒
- [ ] 已避开 ESP32 Strapping 引脚及仅输入 GPIO
- [ ] 本地编译零错误通过，烧录环节严格执行人工确认后方才触发
