---
name: small-business
description: "Pre-built small business workflows covering CRM, invoicing, payroll prep, hiring, SEO, inventory planning, and operations."
---

# Small Business

Pre-built small business workflows covering CRM, invoicing, payroll prep, hiring, SEO, inventory planning, and operations.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (44)

- `small-business-ad-manager`
- `small-business-ap-processor`
- `small-business-brand-style`
- `small-business-build-agent`
- `small-business-build-connector`
- `small-business-business-pulse`
- `small-business-call-list`
- `small-business-canva-creator`
- `small-business-cash-flow-snapshot`
- `small-business-close-month`
- `small-business-content-strategy`
- `small-business-contract-review`
- `small-business-crm-autopilot`
- `small-business-grant-rfp-writer`
- `small-business-grow-pipeline`
- `small-business-growth-pulse`
- `small-business-hiring-screener`
- `small-business-inbox-manager`
- `small-business-inventory-planner`
- `small-business-invoice-chase`
- `small-business-job-post-builder`
- `small-business-lead-finder`
- `small-business-lead-triage`
- `small-business-marketing-monday`
- `small-business-monday-brief`
- `small-business-month-end-prep`
- `small-business-outreach-composer`
- `small-business-pay-the-bills`
- `small-business-payroll-prep`
- `small-business-plan-payroll`
- `small-business-proposal-builder`
- `small-business-reactivate`
- `small-business-report-builder`
- `small-business-report-pack`
- `small-business-restock`
- `small-business-review-reputation`
- `small-business-seo-ai-visibility`
- `small-business-smb-onboard`
- `small-business-smb-router`
- `small-business-social-content-engine`
- `small-business-speed-to-lead`
- `small-business-tax-prep`
- `small-business-tax-season-organizer`
- `small-business-ticket-deflector`
