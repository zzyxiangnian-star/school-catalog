# DBHub 多引擎安全 BI 参考栈与操作手册（`references/stack-and-sop.md`）

## 1. 核心 GitHub 开源底座与关联 MCP 参考

| 组件 / 仓库 | 定位 | 支持引擎与特性 | 核心能力说明 |
| :--- | :--- | :--- | :--- |
| **[bytebase/dbhub](https://github.com/bytebase/dbhub)** | 极省 Token 多引擎安全 SQL MCP 网关 | PostgreSQL、MySQL、MariaDB、SQLite、Oracle（纯 JS Thin 模式）、SQL Server | 默认仅暴露 `search_objects` 与 `execute_sql` 两个核心工具（加载约 1.4k Token）；支持 `dbhub.toml` 多库聚合、渐进式 Schema 披露及工具级 `readonly` / `max_rows` 强制护栏；可选开启 `explain_sql` 与 `health_check`。 |
| `postgres` MCP（参考扩展） | PostgreSQL 专精只读插件 | PostgreSQL | 单库场景下作为备选直连插件，提供基础表结构查看与只读查询。 |
| `clickhouse` MCP（参考扩展） | OLAP 列式分析补充插件 | ClickHouse | 承担亿级明细日志、实时漏斗与宽表 OLAP 聚合，与 `dbhub` 的 OLTP 业务库互补。 |
| `mongodb` MCP（参考扩展） | 文档库只读补充插件 | MongoDB | 承担非结构化订单快照、埋点 JSON 文档的只读聚合查询（`aggregate` / `find`）。 |

---

## 2. 典型 MCP / CLI 配置模板

### 2.1 `dbhub.toml` 多库只读安全配置模板

将以下配置文件置于工作区根目录或通过 `--config` 指定路径。**生产库务必配置只读数据库账号，并在 `[[tools]]` 中显式锁定 `readonly = true` 与 `max_rows`**：

```toml
# 1. 定义多个业务数据源（支持同时挂载多种数据库引擎）
[[sources]]
id = "orders_pg"
dsn = "postgres://bi_readonly:${PG_RO_PASSWORD}@127.0.0.1:5432/orders_db"
connection_timeout = 30
query_timeout = 30

[[sources]]
id = "crm_mysql"
dsn = "mysql://bi_readonly:${MYSQL_RO_PASSWORD}@127.0.0.1:3306/crm_db"
connection_timeout = 30
query_timeout = 30

[[sources]]
id = "local_cache"
dsn = "sqlite:///data/metrics_snapshot.db"

# 2. 为每个数据源强制绑定只读护栏与行数上限
# 多数据源模式下，DBHub 会自动生成 execute_sql_orders_pg / search_objects_orders_pg 等命名空间工具
[[tools]]
name = "execute_sql"
source = "orders_pg"
readonly = true
max_rows = 1000

[[tools]]
name = "execute_sql"
source = "crm_mysql"
readonly = true
max_rows = 1000

[[tools]]
name = "execute_sql"
source = "local_cache"
readonly = true
max_rows = 2000
```

### 2.2 CLI 启动与 MCP Client 挂载模板

**本地 HTTP / SSE 服务方式（调试或共享网关）：**

```bash
# 自动读取当前目录 ./dbhub.toml
npx @bytebase/dbhub@latest --transport http --port 8080

# 或显式指定配置文件路径
npx @bytebase/dbhub@latest --transport http --port 8080 --config /path/to/dbhub.toml
```

**MCP Client（Stdio 模式，如桌面端/Agent 运行时配置 `mcpServers`）：**

```json
{
  "mcpServers": {
    "dbhub": {
      "command": "npx",
      "args": [
        "-y",
        "@bytebase/dbhub@latest",
        "--transport",
        "stdio",
        "--config",
        "/path/to/dbhub.toml"
      ],
      "env": {
        "PG_RO_PASSWORD": "your_readonly_password",
        "MYSQL_RO_PASSWORD": "your_readonly_password"
      }
    }
  }
}
```

### 2.3 环境前置自检命令

在本地排查 `dbhub` 运行前置条件时可执行：

```bash
# 检查 Node.js 与 npx 是否可用
node -v && npx -v

# 验证配置文件是否存在且未泄露明文敏感信息至 Git
ls -la dbhub.toml
```

---

## 3. 交付产物检验清单（交付前逐项核对）

- [ ] **前置与权限合规**：已确认数据源为只读配置（`readonly = true`）或仅执行了 `SELECT` / `WITH` / `EXPLAIN`；零 DDL/DML 写操作。
- [ ] **Schema 渐进探查**：先用 `search_objects`（`names` -> `summary`）定位真实表名与字段名，未凭记忆猜表名/列名。
- [ ] **行数与性能保护**：所有明细探查查询均显式附带 `LIMIT`；汇总查询在数据库端完成 `GROUP BY` 聚合后再拉取结果。
- [ ] **口径与空值核对**：
  - [ ] 已明确时间字段名、时区及起止边界（闭区间/半开区间）。
  - [ ] 已检查关键维度/度量字段的 `NULL`、空串、负值或异常极端值占比。
  - [ ] 多表 `JOIN` 前已核对关联键基数，排除 1:N 关联导致金额/计数翻倍膨胀。
  - [ ] 已确认软删除标记（如 `deleted_at` / `is_deleted`）与订单取消状态过滤条件。
- [ ] **BI 可视化一致性**：联合 `data` 技能生成的图表数值、单位、维度标签与 SQL 返回结果 100% 一致，无截断误导。
- [ ] **SQL 审计清单完整**：输出末尾包含每条有效查询的 `source_id`、完整可复现 SQL、返回行数、执行状态及口径备注，且已脱敏所有敏感字段。
