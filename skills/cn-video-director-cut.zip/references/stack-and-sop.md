# 剪辑师 — 技术栈与配置参考

## 1. 选型开源仓库索引

- MiniMax-AI/MiniMax-MCP — MIT（大陆节点 `api.minimaxi.com` 配音/生图/Hailuo 视频）
- sun-guannan/VectCutAPI — Apache-2.0（输出剪映专业版 10.x 草稿 `dfd_*` 及实时预览）

## 2. 本机前置准备

- Python 3.10+、uv 与本机 FFmpeg（用于音频时长探测及直接渲染 MP4）
- 配置大陆版 `MINIMAX_API_KEY`，保持 `MINIMAX_API_RESOURCE_MODE=local` 落盘
- 如需剪映草稿二次精修，本机安装剪映专业版 10.x 并克隆启动 `VectCutAPI`

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
{
  "mcpServers": {
    "MiniMax": {
      "command": "uvx",
      "args": ["minimax-mcp", "-y"],
      "env": {
        "MINIMAX_API_KEY": "<你的大陆版 MINIMAX_API_KEY>",
        "MINIMAX_API_HOST": "https://api.minimaxi.com",
        "MINIMAX_API_RESOURCE_MODE": "local",
        "MINIMAX_MCP_BASE_PATH": "<素材落盘目录>"
      }
    }
  }
}
```

## 4. 合规与物理安全核查项

- 按量计费的视频/图片生成批量动作前必须由用户确认预算。
- 音色克隆需明确具备声音权利人授权，成片发布需遵守国家深度合成内容显著标识规定。
- 提示剪映草稿格式随客户端大版本升级可能变化，建议同步保留原始素材文件夹。

## 5. 已排除的过时或高风险方案

- 依赖海外 Sora/Runway 非官方逆向接口且不可直连的视频生成项目
- 未绑定 `MINIMAX_API_HOST=https://api.minimaxi.com` 导致跨境超时的高延迟配置

## 6. 交付产物检验清单

- [ ] 批量视频生成前已得到用户书面费用确认
- [ ] 所有镜头时长均严格对齐对应 TTS 配音时长
- [ ] 字幕、配音、BGM 音量平衡且无黑场或素材路径丢失
