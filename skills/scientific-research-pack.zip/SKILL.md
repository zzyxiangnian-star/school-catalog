---
name: scientific-research-pack
description: "Curated core scientific research skills covering literature review, citation management, hypothesis generation, experimental design, statistical analysis, EDA, visualization, schematics, grant writing, and manuscript authoring."
---

# Scientific Research Pack

Curated core scientific research skills covering literature review, citation management, hypothesis generation, experimental design, statistical analysis, EDA, visualization, schematics, grant writing, and manuscript authoring.

Source: https://github.com/K-Dense-AI/scientific-agent-skills

## Included Skills (12)

- `scientific-research-pack-citation-management`
- `scientific-research-pack-experimental-design`
- `scientific-research-pack-exploratory-data-analysis`
- `scientific-research-pack-hypothesis-generation`
- `scientific-research-pack-literature-review`
- `scientific-research-pack-research-grants`
- `scientific-research-pack-scientific-brainstorming`
- `scientific-research-pack-scientific-critical-thinking`
- `scientific-research-pack-scientific-schematics`
- `scientific-research-pack-scientific-visualization`
- `scientific-research-pack-scientific-writing`
- `scientific-research-pack-statistical-analysis`
