---
name: claude-for-manufacturing
description: "面向工厂制造场景的官方 17 项技能套件，整合多系统导出的生产与质量数据。"
---

# Claude for Manufacturing

面向工厂制造场景的官方 17 项技能套件，整合多系统导出的生产与质量数据。

Source: https://github.com/anthropics/claude-plugins-official

## Included Skills (17)

- `claude-for-manufacturing-breakdown-diagnosis`
- `claude-for-manufacturing-breakdown-to-next-report`
- `claude-for-manufacturing-custom-connector`
- `claude-for-manufacturing-customer-inquiry-intake`
- `claude-for-manufacturing-daily-production-report`
- `claude-for-manufacturing-data-consolidate`
- `claude-for-manufacturing-design-space-explore`
- `claude-for-manufacturing-inspection-to-capa`
- `claude-for-manufacturing-morning-plant-pulse`
- `claude-for-manufacturing-ncr-writeup`
- `claude-for-manufacturing-onboarding`
- `claude-for-manufacturing-quote-build`
- `claude-for-manufacturing-rfq-to-quote`
- `claude-for-manufacturing-root-cause-capa`
- `claude-for-manufacturing-supplier-escape-to-alternate-source`
- `claude-for-manufacturing-supplier-quote-request`
- `claude-for-manufacturing-trade-study-report`
