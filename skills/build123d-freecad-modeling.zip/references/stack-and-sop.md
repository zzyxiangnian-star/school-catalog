# build123d-mcp 与 FreeCAD MCP 参考配置与检验手册

## 1. 核心 GitHub 开源仓库清单

| 仓库地址 | 定位与职责 | 核心机制与常用工具 |
| --- | --- | --- |
| [`pzfreo/build123d-mcp`](https://github.com/pzfreo/build123d-mcp) | Python 参数化 CAD 内核 MCP 服务端，封装 `build123d` 并打通“编写代码 -> 渲染预览 -> 几何测量 -> 导出”闭环 | 提供持久化沙盒会话；核心工具包括 `execute`（执行 `build123d` Python 脚本）、几何测量（体积、包围盒、拓扑、孔/凸台与间隙检查）、PNG/SVG/DXF 视图渲染、STEP/STL 导出及 FDM 可打印性检查（悬垂、薄壁等） |
| [`neka-nat/freecad-mcp`](https://github.com/neka-nat/freecad-mcp) | FreeCAD 桌面端双向控制 MCP 服务端（Addon RPC + MCP Client 桥接） | 核心工具包括 `create_document`、`create_object`、`edit_object`、`delete_object`、`get_objects`、`get_object`、`get_view`、`execute_code`、`get_parts_list`、`insert_part_from_library` |

---

## 2. 典型 MCP / CLI 配置与环境准备模板

### 2.1 `build123d-mcp` 配置（推荐通过 `uv` 运行）

**前置 CLI 连通性自检：**

```bash
uv tool run --python 3.12 build123d-mcp@latest --version
```

*(支持 Python 3.11–3.14，建议使用 3.12 作为稳妥默认版本；如需全局 Python 环境安装亦可执行 `pip install build123d-mcp`。)*

**MCP 客户端配置示例（`.mcp.json` / `claude_desktop_config.json`）：**

```json
{
  "mcpServers": {
    "build123d-mcp": {
      "command": "uv",
      "args": [
        "tool",
        "run",
        "--python",
        "3.12",
        "build123d-mcp@latest"
      ]
    }
  }
}
```

### 2.2 `freecad-mcp` 安装与配置（需本地安装 FreeCAD）

**步骤一：安装 FreeCAD MCP Addon**

1. 克隆仓库：`git clone https://github.com/neka-nat/freecad-mcp.git`
2. 将仓库中的 `addon/FreeCADMCP` 目录复制到本地 FreeCAD 的 `Mod` 插件目录：
   - **Windows**: `%APPDATA%\FreeCAD\Mod\`
   - **macOS**: `~/Library/Application Support/FreeCAD/Mod/`
   - **Linux**: `~/.FreeCAD/Mod/` 或 `~/.local/share/FreeCAD/Mod/`
3. 重启 FreeCAD，在工作台（Workbench）下拉菜单中选择 **MCP Addon**，点击工具栏 **Start RPC Server** 启动本地 RPC 服务。

**步骤二：MCP 客户端配置示例**

```json
{
  "mcpServers": {
    "freecad": {
      "command": "uvx",
      "args": [
        "freecad-mcp"
      ]
    }
  }
}
```

*(若需精简上下文仅返回文本反馈，可在 `args` 中追加 `"--only-text-feedback"`；从本地源码调试时可使用 `uv --directory /path/to/freecad-mcp/ run freecad-mcp`。)*

---

## 3. `build123d` 工业建模与校验脚本骨架

```python
from build123d import (
    Align,
    Axis,
    Box,
    Cylinder,
    Locations,
    Mode,
    Part,
    export_step,
    export_stl,
)

# 1. 参数集中定义（单位：mm）
BASE_L = 80.0
BASE_W = 50.0
BASE_H = 6.0
HOLE_D = 4.4  # M4 通孔（含 +0.4mm 装配间隙）
HOLE_OFFSET_X = 32.0
HOLE_OFFSET_Y = 17.0

# 2. 实体构建
with Part() as bracket:
    Box(BASE_L, BASE_W, BASE_H, align=(Align.CENTER, Align.CENTER, Align.MIN))
    with Locations(
        (HOLE_OFFSET_X, HOLE_OFFSET_Y, 0),
        (-HOLE_OFFSET_X, HOLE_OFFSET_Y, 0),
        (HOLE_OFFSET_X, -HOLE_OFFSET_Y, 0),
        (-HOLE_OFFSET_X, -HOLE_OFFSET_Y, 0),
    ):
        Cylinder(
            radius=HOLE_D / 2,
            height=BASE_H,
            align=(Align.CENTER, Align.CENTER, Align.MIN),
            mode=Mode.SUBTRACT,
        )

part = bracket.part
bbox = part.bounding_box()
print("BBox (mm):", bbox.size)
print("Volume (mm^3):", round(part.volume, 3))
print("Center of Mass:", part.center())

# 3. 导出工业级文件
export_step(part, "output/mounting_bracket.step")
export_stl(part, "output/mounting_bracket.stl", tolerance=0.01, angular_tolerance=0.1)
```

**生成交付哈希（PowerShell / Bash）：**

```bash
sha256sum output/mounting_bracket.step output/mounting_bracket.stl
```

---

## 4. 交付产物检验清单（Deliverable Checklist）

- [ ] **工具链路就绪**：确认 `build123d-mcp`（及按需使用的 `freecad-mcp` RPC Server）真实可执行且无静默报错。
- [ ] **单位与基准一致**：所有输入/输出严格使用 `mm`，零件底部或装配原点与设计要求一致。
- [ ] **多视角可视化核验**：已生成并检查等轴测与正交三视图 PNG/SVG，确认无特征穿透、布尔失效或孔位偏移。
- [ ] **几何与公差实测**：包围盒 `X/Y/Z`、体积 `mm³`、质心坐标及关键配合孔径（含打印收缩/间隙补偿）均通过实测打印输出。
- [ ] **流形与可打印性通过**：STL 网格闭合无破面（Watertight/Manifold），薄壁与悬垂结构满足下游 3D 打印工艺阈值。
- [ ] **跨 Bot 交接完整**：已产出 `.step`、`.stl`、预览图及 SHA-256 校验值，结构清晰可供 `#18` 切片与 `#07` BOM 核算直接消费。
