---
name: enterprise-search
description: "Search across company email, chat, documents, and wikis in one place to synthesize answers and locate organizational knowledge."
---

# Enterprise Search

Search across company email, chat, documents, and wikis in one place to synthesize answers and locate organizational knowledge.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (5)

- `enterprise-search-digest`
- `enterprise-search-knowledge-synthesis`
- `enterprise-search-search`
- `enterprise-search-search-strategy`
- `enterprise-search-source-management`
