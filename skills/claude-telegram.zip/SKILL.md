---
name: claude-telegram
description: "Anthropic 官方插件，支持 Telegram 机器人消息收发、配对授权与精细化访问策略。"
---

# Claude Telegram Channel

Anthropic 官方插件，支持 Telegram 机器人消息收发、配对授权与精细化访问策略。

Source: https://github.com/anthropics/claude-plugins-official

## Included Skills (2)

- `claude-telegram-access`
- `claude-telegram-configure`
