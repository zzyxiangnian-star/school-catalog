# 简单结构仿真助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- neka-nat/freecad-mcp — MIT（v0.1.32，通过本地插件联动 FreeCAD）
- FreeCAD/FreeCAD (>= 1.1) — LGPL-2.1（外置独立软件，原生集成 Gmsh 与 GPL-2.0 CalculiX）
- earthtojake/text-to-cad & BaratiLab (`fea` / `quick-fea`) — MIT（工作流参考）

## 2. 本机前置准备

- 用户本机独立安装 FreeCAD >= 1.1（约 300~500 MB，内置 Gmsh 与 CalculiX）与 uv，并启用 FreeCADMCP 插件
- 推荐 4 核 CPU 与 8~16 GB 内存，纯 CPU 运算无需独立显卡

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
{
  "mcpServers": {
    "freecad": {
      "command": "uvx",
      "args": ["freecad-mcp"]
    }
  }
}

# 使用前请在 FreeCAD 1.1+ 安装并启动 FreeCADMCP 插件，确保存在闭合实体后调用 get_view 交互选面。
```

## 4. 合规与物理安全核查项

- 报告必须醒目声明：“仅适用于小变形、线性各向同性静力学概念初算，严禁用于建筑承重、桥梁、压力容器、汽车安全件或医疗器械法定强度校核。”
- 未经用户书面确认面 ID 前不得私自指定 Fixed 与 Force。

## 5. 已排除的过时或高风险方案

- `ymiya55/freecad-fem-mcp`（0 Stars，仅限单系统且无稳定 Release）
- `mcp-calculix`（低星参考原型）

## 6. 交付产物检验清单

- [ ] 输入为 `.step`/`.FCStd` 闭合实体而非破损无厚度 STL
- [ ] 固定面（Fixed）与载荷方向（Force/Pressure）已由用户截图确权
- [ ] 已区分尖角网格奇异值并做数量级解析复核，附带法定认证免责声明
