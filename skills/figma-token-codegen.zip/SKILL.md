---
name: figma-token-codegen
description: 基于 GLips/Figma-Context-MCP 精准解析 Figma 图层树、Auto Layout 约束、Design Tokens 与切片资产，生成高保真 React/Tailwind 或框架适配组件代码，并通过 Playwright 真实浏览器预览完成原稿视觉差异对比闭环。
---

# Figma Token 解析与高保真转码闭环（`figma-token-codegen`）

## 1. 触发条件

当遇到以下任一需求时触发本技能（可与 `figma`、`figma-implement-design` 协同调用）：
- 用户提供 Figma 设计稿 URL（`/file/...` 或 `/design/...`），要求还原为 React、Vue、Next.js 或 HTML/CSS 组件代码；
- 需要从 Figma 节点中抽离色彩、字体、间距、圆角、阴影等 Design Tokens 与 SVG/PNG 切片资产并对齐现有前端主题；
- 收到上游规划/架构 Bot 下发的设计还原任务包，要求产出可运行组件并通过浏览器视觉对比验收。

---

## 2. 核心 GitHub 开源底座与依赖环境

- **核心底座**：[`GLips/Figma-Context-MCP`](https://github.com/GLips/Figma-Context-MCP)（npm 包 `figma-developer-mcp`），提供 `get_figma_data` 与 `download_figma_images` 工具。
- **浏览器预览底座**：`playwright` MCP（`@playwright/mcp`）及本地 Dev Server / 静态预览环境。
- **鉴权前提**：本地或 MCP 服务已配置有效的 `FIGMA_API_KEY`（Personal Access Token，具备目标文件只读权限）。

---

## 3. 前置环境检测（Step 0：未就绪即停）

正式编码前，必须先核查以下三项前置条件：
1. **MCP 工具就绪**：确认当前会话可调用 `figma-context`（含 `get_figma_data`、`download_figma_images`）及 `playwright` 浏览器工具。
2. **Figma 凭据与文件权限**：若调用 `get_figma_data` 返回 401/403 或提示缺失 `FIGMA_API_KEY`，立即停止执行，向用户一次性输出 `FIGMA_API_KEY` 配置步骤与权限要求（`File content: Read`），返回 `BLOCKED`。
3. **节点范围明确**：确认 URL 中包含 `fileKey`；若缺少 `node-id` 且整页画板庞大，先提示用户指定目标 `node-id` 或确认首批遍历深度（`depth`），严禁盲目拉取超大型文件导致上下文截断失真。

---

## 4. 分步执行 SOP

### Step 1：URL 解析与参数标准化
- 从 `https://www.figma.com/design/<fileKey>/...?node-id=12-34` 提取：
  - `fileKey`：路径中的文件标识；
  - `nodeId`：将 URL 中的 `-` 转换为 `:`（例如 `12-34` → `12:34`）。

### Step 2：图层元数据与 Design Tokens 提取
- 调用 `get_figma_data(fileKey, nodeId, depth)` 获取精简结构化数据，禁止凭感觉猜测任何尺寸或颜色：
  - **布局约束**：记录每个容器的 `layoutMode`（Horizontal / Vertical / None）、`primaryAxisAlignItems`、`counterAxisAlignItems`、`itemSpacing`、四向 `padding` 及 `FILL / HUG / FIXED` 尺寸模式；
  - **视觉 Tokens**：提取主色/中性色/渐变色值、字族（`fontFamily`）、字号、字重、行高（`lineHeightPx`）、字距、圆角（`cornerRadius`）与投影（`effects`）；
  - **切片节点识别**：标记所有需独立导出的矢量图标（Vector/Boolean/Icon Frame）与位图填充节点（含 `imageRef`）。

### Step 3：切片资产导出与本地化映射
- 调用 `download_figma_images` 将识别出的图标导出为 `.svg`、将照片/复杂插画导出为 `.png`（`@2x` 或原图比例），保存至项目约定的静态目录（如 `public/assets/figma/` 或 `src/assets/figma/`）。
- 建立并记录 `nodeId -> 本地文件相对路径` 映射表，计算并记录导出文件校验信息（文件大小 / SHA-256），确认无 0 字节损坏文件。

### Step 4：Token 收口与高保真组件生成
- 联合 `figma-implement-design` 规范，优先复用目标项目既有的 `tailwind.config.*`、`tokens.css` 或主题变量；缺失的 Design Tokens 按语义命名补齐（如 `--color-surface-card`、`--space-section-gap`）。
- 严格对照 Auto Layout 语义编写组件（Flex/Grid 嵌套层级与设计树保持同构），补全 TypeScript Props 类型、hover/active/disabled 交互态及移动端响应式断点。
- 所有图片与图标严格引用 Step 3 导出的真实本地资产路径，绝不留空或使用随机网络图床。

### Step 5：真实浏览器预览与视觉对比闭环（硬性门禁）
1. 启动目标项目本地预览服务（或搭建独立组件预览路由），确认编译构建无语法/类型错误。
2. 调用 `playwright` MCP 打开预览 URL，至少覆盖 **Desktop (`1440×900`)** 与 **Mobile (`375×812`)** 两个视口：
   - 检查 `console` 与 `pageerror`，确保零运行时错误与零 404 资源请求；
   - 通过 DOM 查询验证所有 `<img>` 加载成功（`complete && naturalWidth > 0`）、无水平滚动条溢出（`scrollWidth <= clientWidth`）、无文字异常折行或遮挡；
   - 核对关键标题、卡片、按钮的 `getComputedStyle`（字体、字号、颜色、padding、gap）是否与 Step 2 提取值一致。
3. 截取真实渲染截图，对照 Figma 原稿设计规范（及用户提供的参考图/设计尺寸）逐区排查视觉差异；若发现偏移、错位、字体回退或对比度失真，直接定位修复代码并重新截图复验，直至无阻塞性视觉偏差。

---

## 5. 跨 Bot 协同接口契约

- **上游输入契约（Upstream Input）**：
  ```json
  {
    "figma_url": "https://www.figma.com/design/<fileKey>/...?node-id=12-34",
    "target_framework": "react-tailwind-ts",
    "repo_path": "/abs/path/to/project",
    "design_tokens_path": "src/styles/tokens.css"
  }
  ```
- **下游交接产物（Downstream Handoff）**：
  交付包含状态结论（`PASS` / `PARTIAL` / `BLOCKED`）、组件文件路径列表、Token 映射差异、本地切片资产路径及 SHA-256 校验值、本地预览 URL 与多视口实测截图路径的结构化清单，供前端合入或验收测试 Bot 直接复验。

---

## 6. 质检与异常处理

- **字体缺失**：若设计稿使用商用字体而本地未安装，在 `font-family` 中保留原字体声明并配置合理回退栈，同时在报告中显式标注“需补充字体文件”，绝不静默替换后谎称一致。
- **SVG 导出异常**：若复杂渐变/蒙版 SVG 在浏览器渲染失真，改为导出 2x PNG 并在报告中记录原因。
- **局部缺失节点数据**：若某子组件因权限或引用外部库无法解析，标为 `PARTIAL` 并精确指出未解析的 `nodeId`，绝不编造内部结构。

---

## 7. 禁止越界事项

- 严禁未读取 `get_figma_data` 即凭经验估算像素尺寸、色值或圆角；
- 严禁未在真实浏览器中打开预览并完成多视口截图核查即输出 `PASS`；
- 严禁篡改目标项目非相关的路由配置、后端接口或构建脚本；
- 严禁在日志、代码注释或输出文档中泄露用户的 `FIGMA_API_KEY`。
