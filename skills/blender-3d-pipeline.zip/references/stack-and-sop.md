# Blender 三维场景与渲染流水线参考手册 (`references/stack-and-sop.md`)

## 1. 核心 GitHub 开源底座

| 仓库 / 项目 | 作用定位 | 关键机制 |
|---|---|---|
| [`ahujasid/mcp-for-blender`](https://github.com/ahujasid/mcp-for-blender) | Blender 官方社区主流 MCP 桥接底座 | 由 Blender 插件端 `addon.py`（默认监听 `localhost:9876` TCP Socket）与 Python MCP Server（PyPI 包名 `mcp-for-blender` / 别名 `blender-mcp`）组成，暴露场景查询、代码执行与视口截图工具 |
| [`astral-sh/uv`](https://github.com/astral-sh/uv) | MCP Server 运行时启动器 | 提供 `uvx` 免手动建虚拟环境启动 `mcp-for-blender` |
| Blender Python API (`bpy`) | 原生程序化建模与渲染内核 | 支持几何体生成、Modifier 修改器、Shader Node 节点树、Keyframes 动画、Cycles/EEVEE 渲染及 `.blend`/`.glb`/`.mp4` 导出 |

---

## 2. 典型 MCP 与 Blender 配置模板

### 2.1 客户端 `mcpServers` 配置（Claude Desktop / Cursor / 通用 MCP 宿主）

```json
{
  "mcpServers": {
    "blender": {
      "command": "uvx",
      "args": ["mcp-for-blender"]
    }
  }
}
```

### 2.2 环境检查与插件启动步骤

1. **检查 `uvx` 与 `blender` 是否就绪**：
   ```powershell
   uvx --version
   blender --version
   ```
   若缺少 `uv`（Windows PowerShell）：
   ```powershell
   powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.sh | iex"
   ```
2. **安装并启用 `addon.py`**：
   - 自动尝试命令（视版本支持）：`uvx mcp-for-blender install-addon`
   - 手动安装（最稳妥）：从 `ahujasid/mcp-for-blender` 下载 `addon.py` → 打开 Blender → `Edit -> Preferences -> Add-ons -> Install...` → 选择 `addon.py` 并勾选启用。
3. **启动 Socket 服务**：
   - 在 Blender 3D 视口按 `N` 打开右侧边栏 → 切换至 `BlenderMCP` / `MCP for Blender` 面板 → 点击 **Connect to MCP server**，确保本地监听（默认端口 `9876`）处于开启状态。

---

## 3. 常用 `bpy` 实战校验与渲染代码模板

### 3.1 场景初始化与单位校准（公制米）

```python
import bpy

# 重置或清理指定集合时保持幂等
scene = bpy.context.scene
scene.unit_settings.system = 'METRIC'
scene.unit_settings.scale_length = 1.0
```

### 3.2 导入上游 CAD 网格（`.glb` / `.stl`）并自动归一接地

```python
import bpy
import mathutils

def normalize_imported_objects(objs, target_scale=1.0):
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objs:
        if obj.type == 'MESH':
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            obj.scale = (target_scale, target_scale, target_scale)
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

    # 计算联合包围盒底面并置于 Z=0
    min_z = min(
        (obj.matrix_world @ mathutils.Vector(corner)).z
        for obj in objs if obj.type == 'MESH'
        for corner in obj.bound_box
    )
    for obj in objs:
        obj.location.z -= min_z
```

### 3.3 Cycles / EEVEE 标准化渲染参数模板

```python
import bpy

scene = bpy.context.scene
scene.render.engine = 'CYCLES'  # 或 'BLENDER_EEVEE_NEXT' / 'BLENDER_EEVEE'
scene.cycles.samples = 128
scene.cycles.use_denoising = True
scene.render.resolution_x = 1920
scene.render.resolution_y = 1080
scene.render.resolution_percentage = 100
scene.view_settings.view_transform = 'AgX'  # Blender 4.x 推荐，3.x 可回退 'Filmic'
```

### 3.4 导出 `.glb` 与打包 `.blend`

```python
import bpy

# 打包外部贴图防止路径丢失
bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath="/abs/path/to/scene_master.blend")

# 导出商业展示 GLB
bpy.ops.export_scene.gltf(
    filepath="/abs/path/to/product_showcase.glb",
    export_format='GLB',
    export_apply=True
)
```

---

## 4. 交付产物检验清单（Pre-Handoff Checklist）

- [ ] **连通性已实测**：开局通过 `get_scene_info` 获取真实场景树，非离线盲写。
- [ ] **尺度与接地正确**：毫米/厘米导入已换算并 `Apply Scale`，模型无悬空、无穿插、无百倍放大。
- [ ] **材质与法线无异常**：无全黑/全紫（贴图丢失）表面；无反向法线导致的阴影破面；金属度与粗糙度符合物理直觉。
- [ ] **构图与曝光经截图确认**：已调用 `get_viewport_screenshot` 验证主摄视角、安全边距及高光不过曝。
- [ ] **工程可复现与资产自包含**：`.blend` 已执行 `pack_all()`，输出文件使用绝对路径且非空。
- [ ] **下游交接契约完整**（面向 `#08 HyperFrames`）：`MP4` 帧率/分辨率与目标分镜一致（`1920x1080` 或 `3840x2160`，`30/60fps`），附带 `render_manifest.json` 说明时长、机位及文件 SHA256。
