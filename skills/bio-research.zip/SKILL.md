---
name: bio-research
description: "Accelerate early-stage life sciences R&D with preclinical literature search, genomics analysis, and target prioritization workflows."
---

# Bio Research

Accelerate early-stage life sciences R&D with preclinical literature search, genomics analysis, and target prioritization workflows.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (6)

- `bio-research-instrument-data-to-allotrope`
- `bio-research-nextflow-development`
- `bio-research-scientific-problem-selection`
- `bio-research-scvi-tools`
- `bio-research-single-cell-rna-qc`
- `bio-research-start`
