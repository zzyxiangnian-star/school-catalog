---
name: claude-cwc-makers
description: "为 Code-with-Claude Makers 硬件创客提供一键环境搭建与固件示例引导技能。"
---

# Code-with-Claude Makers

为 Code-with-Claude Makers 硬件创客提供一键环境搭建与固件示例引导技能。

Source: https://github.com/anthropics/claude-plugins-official

## Included Skills (2)

- `claude-cwc-makers-cardputer-buddy`
- `claude-cwc-makers-m5-onboard`
