---
name: "中国大陆商业合同本地审阅流程"
description: "交叉核对主体金额比例、逐句引据排查失衡条款并支持写入 Word 批注"
---

# 合同与条款审阅助手 — 中国大陆商业合同本地审阅流程

## 定位与适用范围

集成 legal 技能、markitdown-mcp 与 docx-mcp，全程离线解析合同正文，执行数值逻辑校验与甲乙双方立场审查，可另存生成带 Word 原生批注副本。

- **归属 Bot**：`contract-reviewer`（分类：`documents`）
- **协同目录技能**：legal, docx, pdf
- **关联推荐 MCP 插件**：markitdown-mcp, docx-mcp

## 核心开源工具栈（国内高可用）

- anthropics/knowledge-work-plugins (`legal/skills/review-contract`) — Apache-2.0（合同核查规范参照）
- SecurityRonin/docx-mcp — MIT（纯本地写入 Word 原生修订与段落批注，免装 Word）
- microsoft/markitdown (`markitdown-mcp`) — MIT（合同文本与表格无损结构提取）
- anthropics/skills (`docx`, `pdf`) — Apache-2.0（本地文件读取与对照辅助）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- Python 3.10+ 与 uv；本地运行 `uvx markitdown-mcp` 与 `uvx docx-mcp-server`，无需安装 Word/WPS 或独立显卡
- 扫描版不可复制文字的 PDF，需提前经本地离线 OCR 提取文本后送审

## 标准执行 SOP

1. 格式检查与解析：判定 `.docx` 或可选文字 `.pdf`（扫描件转交本地 OCR），调用 `markitdown-mcp` 或 `docx-mcp` 提取条文与附件清单。
2. 主体与数值交叉校对：比对甲乙全称及统一社会信用代码、大小写金额、分期付款比例合计是否为 100% 以及起止时间矛盾。
3. 立场风险扫描：依用户立场排查单方解约、过重违约金、背靠背付款、知识产权宽泛归属、默认自动续签与异地管辖风险。
4. 基础条款查漏：排查是否漏掉商业保密、不可抗力、发票税率及开票节点、送达地址确认、争议解决条文。
5. 引据出表与批注副本：逐条原文精确引用输出风险等级审阅表，并在副本上调用 `docx-mcp` 写入批注（首尾强附免责声明）。

## 安全合规红线与执业边界

- 报告首尾必须醒目附带：“本审阅结果仅供商业风险提示与文本核对，不构成正式法律意见，重大合同须交执业律师复核。”
- 合同文件全部本地解析读取不自动外传云盘；同时向用户明确若使用云端大模型对话推理时的数据传输范围。
- Word 批注必须写入另存副本，绝不原地覆写用户原始合同。

## 已明确排除项目

- `GongRzhe/Office-Word-MCP-Server`（已于 2026-03-03 归档且缺乏原生 OOXML 红线批注支持）

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
