# DAW 编曲与双人播客参考手册（`stack-and-sop.md`）

## 1. GitHub 开源底座与关联技能清单

| 组件类型 | 名称 / 仓库 | 作用定位 | 关键依赖与说明 |
| --- | --- | --- | --- |
| MCP Server + Remote Script | [`ahujasid/ableton-mcp`](https://github.com/ahujasid/ableton-mcp) | 通过 TCP Socket（`localhost:9877`）桥接 AI 与 Ableton Live LOM | 需本地安装 Ableton Live 10+、Python 3.8+、`uv` |
| CLI + MCP Server | [`jacob-bd/gemini-notebook-mcp-cli`](https://github.com/jacob-bd/gemini-notebook-mcp-cli)（包名 `notebooklm-mcp-cli`） | 自动化管理 NotebookLM 笔记本、来源导入及双人 Audio Overview 生成下载 | 依赖 `uv`/`pipx` 与 Chrome CDP 提取 Google 会话 Cookie；属非官方 API 封装 |
| 目录既有技能 | `qiaomu-anything-to-notebooklm`（[`joeseesun/qiaomu-anything-to-notebooklm`](https://github.com/joeseesun/qiaomu-anything-to-notebooklm)） | 将多源异构资料（网页、PDF、Markdown、公众号、视频字幕）清洗标准化后送入 NotebookLM | 作为 Track B 长研报上游预处理层优先调用 |

---

## 2. 典型 MCP / CLI 配置与环境校验模板

### 2.1 `ableton-mcp` 配置模板（Track A）

1. **安装 Ableton Remote Script**
   从 `ahujasid/ableton-mcp` 仓库获取 `AbletonMCP_Remote_Script/__init__.py`，放入目标目录并确保文件夹严格命名为 `AbletonMCP`：
   - **Windows**: `%APPDATA%\Ableton\Live x.x.x\Preferences\User Remote Scripts\AbletonMCP\__init__.py`
   - **macOS**: `~/Library/Preferences/Ableton/Live XX/User Remote Scripts/AbletonMCP/__init__.py`

2. **Ableton Live 内启用 Control Surface**
   打开 Ableton Live → `Settings / Preferences` → `Link, Tempo & MIDI` → 在 `Control Surface` 下拉选中 `AbletonMCP`，`Input` 与 `Output` 均保持 `None`。

3. **MCP 客户端配置（`mcpServers` JSON）**
   ```json
   {
     "mcpServers": {
       "AbletonMCP": {
         "command": "uvx",
         "args": ["ableton-mcp"]
       }
     }
   }
   ```

4. **常用 MCP 工具调用链路**
   - 会话探测：`get_session_info`
   - 全局速度：`set_tempo(tempo=120)`
   - 建轨与加载音色：`create_midi_track(index=-1)` → `load_browser_item(...)`
   - 写入乐句：`create_clip(...)` → `add_notes_to_clip(...)`（传入音高、起始拍、时值、力度）

> **边界提示**：`ableton-mcp` 操作的是 Live 实时会话对象；最终工程保存（`Ctrl/Cmd+S`）与分轨/母带导出（`Ctrl/Cmd+Shift+R` 选择 `All Individual Tracks` / `Master`）如未由本地脚本自动触发，必须提示用户在 Live 中一键确认导出，并校验磁盘实际生成的 `.als`、`.wav`、`.mp3` 文件。

---

### 2.2 `notebooklm-mcp-cli` 配置与 CLI 模板（Track B）

1. **安装与登录认证**
   ```bash
   # 安装 CLI 与 MCP 服务
   uv tool install notebooklm-mcp-cli

   # 通过本地浏览器登录并提取 Google NotebookLM 会话 Cookie
   nlm login
   ```

2. **MCP 客户端配置（`mcpServers` JSON）**
   ```json
   {
     "mcpServers": {
       "notebooklm-mcp": {
         "command": "uvx",
         "args": ["--from", "notebooklm-mcp-cli", "notebooklm-mcp"]
       }
     }
   }
   ```

3. **标准双人播客生成 CLI 流水线**
   ```bash
   # 1. 新建笔记本
   nlm notebook create "研报播客-<主题>"

   # 2. 导入 #01/#04 上游清洗后的研报来源（支持 URL 或本地文件）
   nlm source add "<notebook-id-or-alias>" --file "./reports/cleaned_report.md"
   nlm source add "<notebook-id-or-alias>" --url "https://example.com/report"

   # 3. 触发双人深度对谈音频生成（--confirm 跳过交互确认）
   nlm audio create "<notebook-id-or-alias>" --confirm

   # 4. 下载生成的播客音频至交付目录
   nlm download audio "<notebook-id-or-alias>" "<artifact-id>" "./output/podcast.mp3"
   ```

---

## 3. 跨 Bot 协同接口契约

### 3.1 上游输入契约（接收自 `#01 爬虫 Bot` / `#04 ETL Bot`）
- **文件形态**：清洗后的 Markdown（`.md`）、纯文本（`.txt`）、PDF（`.pdf`）或已去重校验的 URL 列表。
- **必备元信息**：报告标题、来源 URL / 文件哈希、章节边界（若单篇超数十页，需保留清晰 H1/H2 标题以便分片注入，避免超过单源字数上限导致截断）。

### 3.2 下游交接契约（交付至 `#08 视频 Bot`）
- **配乐资产包（Track A）**：
  - 工程源文件：`project.als`
  - 母带与分轨音频：`master.wav`（48kHz / 24-bit 推荐）、`master.mp3`（320kbps）、`stems/{drums,bass,chords,lead}.wav`
  - 卡点清单（`beat_map.json` 或结构化表格）：精确记录 `bpm`、`time_signature`（如 `4/4`）、`duration_sec`、关键重拍/转场小节时间戳（毫秒或秒）。
- **播客资产包（Track B）**：
  - 播客主音频：`podcast.mp3`（或转码 WAV）
  - 引用溯源表（`sources_manifest.md`）：列出注入笔记本的全部真实来源标题、URL/文件名、Notebook ID 与 Artifact ID。

---

## 4. 交付产物检验清单（交付前逐项核验）

- [ ] **前置环境真实就绪**：Track A 已通过 `get_session_info` 收到 Live 返回；Track B `nlm` 命令返回正常且非登录过期报错。
- [ ] **文件物理存在且非空**：所有声明交付的 `.als`、`.wav`、`.mp3`、`.md`/`.json` 文件均存在于磁盘且字节数 > 0。
- [ ] **版权合规性（Track A）**：全部旋律、和弦与节奏均由 MIDI 编排及合法宿主合成器/音源生成，无未授权采样或成品音轨混入。
- [ ] **卡点可用性（Track A → #08）**：BPM、拍号、总时长及小节时间戳与实际导出的 WAV/MP3 首尾对齐，无明显超长静音拖尾。
- [ ] **引用可溯源（Track B）**：播客来源清单与实际执行 `nlm source add` 的输入源一一对应，无凭空捏造的文献或数据引用。
