---
name: finance
description: "Streamline finance and accounting workflows from journal entries and reconciliation to financial statements, variance analysis, and month-end close."
---

# Finance

Streamline finance and accounting workflows from journal entries and reconciliation to financial statements, variance analysis, and month-end close.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (8)

- `finance-audit-support`
- `finance-close-management`
- `finance-financial-statements`
- `finance-journal-entry`
- `finance-journal-entry-prep`
- `finance-reconciliation`
- `finance-sox-testing`
- `finance-variance-analysis`
