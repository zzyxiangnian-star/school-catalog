# 共享记忆与社媒增长官 — 开源底座与交付检验参考（`stack-and-sop.md`）

## 1. 关联 GitHub 开源仓库清单

| 仓库 | 定位 | 接入方式 | 说明 |
| :--- | :--- | :--- | :--- |
| [`mem0ai/mem0`](https://github.com/mem0ai/mem0) | 跨 Bot 长期共享记忆层 | Python SDK (`pip install mem0ai`) / Mem0 MCP | 提取事实与偏好，支持按 `user_id`、`agent_id`、元数据过滤语义检索与去重更新 |
| [`gitroomhq/postiz-app`](https://github.com/gitroomhq/postiz-app) | 开源全网社媒调度平台 | `postiz` CLI (`npm install -g postiz`) / Public API / Postiz MCP | 管理多平台渠道绑定、媒体预上传、定时排期与帖子列表检索 |
| [`modelcontextprotocol/servers`](https://github.com/modelcontextprotocol/servers) | 官方 MCP 参考实现（`server-memory`） | `npx -y @modelcontextprotocol/server-memory` | 基于本地 JSONL 知识图谱的零依赖 `memory` MCP 服务，适合轻量实体/关系记忆持久化 |

---

## 2. 典型 MCP 与 CLI 配置模板

### 2.1 `memory` MCP 配置模板（本地知识图谱参考服务）

适用于仅需轻量本地持久化实体与偏好关系的工作区配置（`MEMORY_FILE_PATH` 指向项目共享记忆文件）：

```json
{
  "mcpServers": {
    "memory": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-memory"],
      "env": {
        "MEMORY_FILE_PATH": "./data/shared-memory.jsonl"
      }
    }
  }
}
```

### 2.2 `mem0ai/mem0` Python SDK 初始化与命名空间读写模板

适用于需要语义向量检索、自动去重与多 Bot 分层管理的场景：

```bash
pip install mem0ai
```

```python
from mem0 import Memory

# 需提前设置对应 LLM / VectorStore 环境变量（例如 OPENAI_API_KEY 或本地配置）
m = Memory()

# 写入跨 Bot 共享记忆（通过 agent_id 与 metadata 区分来源和类别）
m.add(
    [
        {"role": "user", "content": "品牌主视觉保持极简冷色调，正文禁用夸张极限词。"}
    ],
    user_id="brand_workspace_default",
    agent_id="mem0-social-growth-bot",
    metadata={"namespace": "brand_tone", "source_bot": "research-bot"}
)

# 发布前检索品牌约束与历史爆款偏好
constraints = m.search(
    "品牌调性 禁用词 目标受众偏好",
    filters={"user_id": "brand_workspace_default"}
)
```

### 2.3 `gitroomhq/postiz-app` CLI 安装与前置校验命令

```bash
# 1. 安装 Postiz CLI
npm install -g postiz

# 2. 配置 API Key（自托管实例需额外设置 POSTIZ_API_URL）
# Linux / macOS:
export POSTIZ_API_KEY="your_postiz_api_key"
export POSTIZ_API_URL="https://your-postiz-domain.com/api"

# Windows PowerShell:
# $env:POSTIZ_API_KEY="your_postiz_api_key"
# $env:POSTIZ_API_URL="https://your-postiz-domain.com/api"

# 3. 环境与绑定渠道前置检测（只读）
postiz --help
postiz integrations:list
postiz posts:list -p 1 -l 10
```

### 2.4 审批前媒体上传与人工确认后排期命令（仅审批通过后执行）

```bash
# 预上传媒体获取 Postiz 内部资产 URL
postiz upload ./assets/product-demo-vertical.mp4

# 仅在用户明确批准 postiz-queue-draft.json 对应条目后执行排期：
postiz posts:create \
  -c "适配平台规格后的已审核正文内容" \
  -m "uploaded-media-url-from-postiz" \
  -s "2026-11-20T12:00:00Z" \
  -i "integration-id-123"
```

---

## 3. 本地待审排期草稿结构模板（`postiz-queue-draft.json`）

```json
{
  "batch_id": "queue-2026-11-w3",
  "approval_status": "PENDING_APPROVAL",
  "memory_snapshot_refs": ["mem_tone_01", "mem_hook_08"],
  "items": [
    {
      "draft_id": "item-001",
      "source_handoff_id": "vid-20261118-01",
      "platform": "x",
      "integration_id": "int_x_main",
      "scheduled_at": "2026-11-20T12:00:00Z",
      "content": "改写后的平台专属文案...",
      "media_local_path": "./assets/clip_16x9.mp4",
      "media_sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "postiz_media_url": "",
      "compliance_check": "PASS",
      "approved_by": null
    }
  ]
}
```

---

## 4. 交付产物检验清单（Pre-Delivery Checklist）

- [ ] **环境真实性核验**：已实测 `memory` MCP 工具响应或本地 `mem0` 导入，且已通过 `postiz integrations:list` 确认目标渠道绑定状态。
- [ ] **记忆去重与脱敏**：写入记忆前已检索冲突；未写入 API Key、Token、Cookie、手机号/邮箱等敏感信息。
- [ ] **上游资产完整性**：所有待发图片/视频均已核验本地文件存在、分辨率/时长符合目标平台规范且记录了 SHA-256 哈希。
- [ ] **审批门控严格生效**：`postiz-queue-draft.json` 中 `approval_status` 默认为 `PENDING_APPROVAL`；未经用户对具体 `draft_id`、`integration_id` 与 `scheduled_at` 明确放行，严禁执行 `postiz posts:create`。
- [ ] **闭环复盘可追溯**：每条新增的 `viral_hook` / `audience_pref` 记忆均关联了原始帖子 ID、来源 Bot 与统计周期。
