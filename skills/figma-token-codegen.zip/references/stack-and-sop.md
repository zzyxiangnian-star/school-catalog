# `figma-token-codegen` 技术底座与交付参考手册

## 1. 核心 GitHub 开源底座与关联工具

| 类别 | 名称 / 仓库 | 作用与关键能力 |
| :--- | :--- | :--- |
| 核心设计上下文 MCP | [`GLips/Figma-Context-MCP`](https://github.com/GLips/Figma-Context-MCP)（npm: `figma-developer-mcp`） | 精简并结构化 Figma REST API 图层树、Auto Layout 约束、Styles/Tokens 与图片引用，提供 `get_figma_data` 与 `download_figma_images` 工具 |
| 浏览器真实预览 MCP | [`microsoft/playwright-mcp`](https://github.com/microsoft/playwright-mcp)（npm: `@playwright/mcp`） | 驱动真实 Chromium/WebKit 内核渲染生成页面，采集多视口截图、DOM 计算样式、Console/Network 状态完成视觉验收闭环 |
| 协同技能参考 | `figma`、`figma-implement-design` | 提供 Figma 设计语义拆解、组件化边界划分与多端视觉保真规范 |

---

## 2. 典型 MCP 与 CLI 配置模板

### 2.1 MCP 客户端配置（`mcp.json`）

```json
{
  "mcpServers": {
    "figma-context": {
      "command": "npx",
      "args": ["-y", "figma-developer-mcp", "--stdio"],
      "env": {
        "FIGMA_API_KEY": "<YOUR_FIGMA_PERSONAL_ACCESS_TOKEN>"
      }
    },
    "playwright": {
      "command": "npx",
      "args": ["-y", "@playwright/mcp@latest"]
    }
  }
}
```

### 2.2 Figma Token 获取与最小权限要求

1. 登录 Figma → 右上角头像 → **Settings** → **Security** → **Personal access tokens** → **Generate new token**。
2. 至少勾选只读权限：**File content (`Read`)**（如需读取变量/组件库状态，按团队空间权限补充对应只读 scope）。
3. 将生成的 Token 写入 `FIGMA_API_KEY` 环境变量（严禁明文提交至 Git 仓库）。

### 2.3 CLI 预检命令参考

```bash
# 检查 Node.js 与 npx 可用性（建议 Node >= 18）
node -v && npx -v

# 验证 figma-developer-mcp 包可拉起
npx -y figma-developer-mcp --help

# 验证本地 Playwright 浏览器环境（如使用本地脚本辅助比对）
npx playwright --version
```

---

## 3. Figma URL 解析与样式映射速查

### 3.1 URL 到 MCP 参数转换

- 示例 URL：`https://www.figma.com/design/AbCdEf123456/Checkout-UI?node-id=120-458&m=dev`
- 提取结果：
  - `fileKey`: `"AbCdEf123456"`
  - `nodeId`: `"120:458"`（注意：URL 中的连字符 `-` 必须替换为冒号 `:`）

### 3.2 Auto Layout → CSS / Tailwind 映射基准

| Figma 属性 | 语义说明 | CSS / Tailwind 映射基准 |
| :--- | :--- | :--- |
| `layoutMode: "HORIZONTAL"` | 水平排列 | `flex flex-row` |
| `layoutMode: "VERTICAL"` | 垂直排列 | `flex flex-col` |
| `itemSpacing` | 子项间距 | `gap-[<px>px]` 或映射 Token |
| `paddingTop/Right/Bottom/Left` | 内边距 | `pt/pr/pb/pl` 精确值或间距 Token |
| `layoutSizingHorizontal: "FILL"` | 撑满父容器 | `flex-1 w-full`（按主/交叉轴区分） |
| `layoutSizingHorizontal: "HUG"` | 包裹内容 | `w-fit` |
| `layoutSizingHorizontal: "FIXED"` | 固定宽度 | `w-[<px>px]`（或响应式约束） |

---

## 4. 跨 Bot 协同交接契约（Handoff Manifest 示例）

```json
{
  "status": "PASS",
  "source": {
    "fileKey": "AbCdEf123456",
    "nodeId": "120:458",
    "figmaUrl": "https://www.figma.com/design/AbCdEf123456/Checkout-UI?node-id=120-458"
  },
  "artifacts": {
    "components": ["src/components/CheckoutSummary.tsx"],
    "tokensFile": "src/styles/tokens.css",
    "assets": [
      {
        "nodeId": "120:499",
        "path": "public/assets/figma/badge-verified.svg",
        "sha256": "<hex-digest>"
      }
    ]
  },
  "verification": {
    "previewUrl": "http://localhost:5173/preview/checkout-summary",
    "viewports": ["1440x900", "375x812"],
    "consoleErrors": 0,
    "brokenImages": 0,
    "screenshots": [
      "artifacts/preview-desktop-1440.png",
      "artifacts/preview-mobile-375.png"
    ]
  }
}
```

---

## 5. 交付产物检验清单（交付前逐项核对）

- [ ] **前置连通性**：已通过 `figma-context` 真实拉取节点树，非凭空估算样式值。
- [ ] **Tokens 一致性**：色值、字号/字重/行高、圆角、阴影、间距均提取自设计稿并统一收口至 Token/变量定义。
- [ ] **切片完整性**：所有图标与位图已通过 `download_figma_images` 导出至本地资源路径，无外部随机占位图。
- [ ] **布局保真度**：Auto Layout 方向、对齐与 Fill/Hug/Fixed 约束已准确转为 Flex/Grid，多视口下无横向溢出或文字遮挡。
- [ ] **真实浏览器闭环**：已通过 `playwright` 打开实时预览页，确认 Console 零报错、所有图片 `naturalWidth > 0` 且已附对比截图。
