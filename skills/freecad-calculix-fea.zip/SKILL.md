---
name: "FreeCAD 有限元分析与选面校核流程"
description: "引导闭合 STEP 模型导入、面确认约束加载、Gmsh 网格划分与 CalculiX 求解"
---

# 简单结构仿真助手 — FreeCAD 有限元分析与选面校核流程

## 定位与适用范围

通过 freecad-mcp 驱动本地 FreeCAD 1.1+（内置 Gmsh 与 CalculiX），实现人机交互确认约束加载面、二阶四面体网格划分与应力云图截取。

- **归属 Bot**：`structural-fea-bot`（分类：`design`）
- **协同目录技能**：无（本技能独立承担全流程）
- **关联推荐 MCP 插件**：freecad-mcp

## 核心开源工具栈（国内高可用）

- neka-nat/freecad-mcp — MIT（v0.1.32，通过本地插件联动 FreeCAD）
- FreeCAD/FreeCAD (>= 1.1) — LGPL-2.1（外置独立软件，原生集成 Gmsh 与 GPL-2.0 CalculiX）
- earthtojake/text-to-cad & BaratiLab (`fea` / `quick-fea`) — MIT（工作流参考）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- 用户本机独立安装 FreeCAD >= 1.1（约 300~500 MB，内置 Gmsh 与 CalculiX）与 uv，并启用 FreeCADMCP 插件
- 推荐 4 核 CPU 与 8~16 GB 内存，纯 CPU 运算无需独立显卡

## 标准执行 SOP

1. 实体合法性检查：导入 `.step`/`.FCStd` 并校验闭合性，若用户误传普通 STL 则提示转为实体或先重建。
2. 材料属性绑定：对照用户选定的国标牌号绑定 $E$、$\nu$ 与屈服强度 $\sigma_s$。
3. 交互选面确认：列出各面编号、质心及法向量并截图 (`get_view`)，等待用户明确确认固定约束面与受载面后再下发分析。
4. 网格划分控制：按壁厚与内存设定合理的 C3D10 二阶单元尺寸，防止局部单元数量失控崩溃。
5. 求解与奇异点复核：提取 CalculiX 结果（von Mises 最大应力、变形极值与安全系数），识别锐角应力奇异点并给出解析量级校核与加筋优化建议。

## 安全合规红线与执业边界

- 报告必须醒目声明：“仅适用于小变形、线性各向同性静力学概念初算，严禁用于建筑承重、桥梁、压力容器、汽车安全件或医疗器械法定强度校核。”
- 未经用户书面确认面 ID 前不得私自指定 Fixed 与 Force。

## 已明确排除项目

- `ymiya55/freecad-fem-mcp`（0 Stars，仅限单系统且无稳定 Release）
- `mcp-calculix`（低星参考原型）

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
