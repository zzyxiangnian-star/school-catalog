---
name: productivity
description: "Manage tasks, plan your day, and build persistent memory of key work context across calendars, email, and chat."
---

# Productivity

Manage tasks, plan your day, and build persistent memory of key work context across calendars, email, and chat.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (4)

- `productivity-memory-management`
- `productivity-start`
- `productivity-task-management`
- `productivity-update`
