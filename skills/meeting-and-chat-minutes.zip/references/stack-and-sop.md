# 群聊与会议纪要助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- modelscope/FunASR — MIT（v1.4.28，魔搭官方 SenseVoiceSmall/Paraformer-zh + CAM++ 本地转写与说话人分离）
- 钉钉开放平台 MCP 服务广场 — 官方托管（2026-07 更新，Streamable HTTP 覆盖日历、待办与 AI 表格）

## 2. 本机前置准备

- 本地音视频转写需用户在本地安装 Python 3.8+（含 PyTorch）配置 `modelscope/FunASR` MCP 或其零 Python GGUF 二进制
- 需同步到钉钉待办/日历时，须由企业管理员在 `mcp.dingtalk.com` 开通并分配专属托管 HTTP 接入地址
- 微信群聊场景用户需自行复制或通过自带“合并转发/聊天记录导出”转为纯文本喂给助手

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
# 本地 FunASR 内置 MCP 示例（需先从魔搭拉取源码并按官方文档下载模型）：
# python examples/mcp_server/funasr_mcp.py   (设置 FUNASR_DEVICE=cpu 或 cuda)

# 钉钉企业官方托管 MCP 广场接入形式（Streamable HTTP，管理员开通后填入）：
# https://mcp-gw.dingtalk.com/server/<server-id>?key=<secret-key>
```

## 4. 合规与物理安全核查项

- 绝对禁止任何形式个人微信桌面自动化、模拟点击、进程 Hook 或数据库解密操作。
- 严禁未获授权开启实时录音窃听，录音转写前提醒遵循参会各方知情同意原则。
- 未能确认对应发言者时如实标记“待确认”，绝不张冠李戴。

## 5. 已排除的过时或高风险方案

- `barantt/wxauto-mcp` 与任何个人微信 Hook/数据库解密方案（严重违反平台协议且触发封号）
- `larksuite/lark-openapi-mcp`（超 12 个月未提交，且飞书 2026-11 官方文档已不推荐个人远程/本地 OpenAPI MCP）
- `open-dingtalk/dingtalk-mcp`（超 12 个月未更，已被官方 MCP 广场替代）与低星 `mcp-server-funasr`

## 6. 交付产物检验清单

- [ ] 零个人微信 Hook 或非法爬库逻辑，微信文本均源自合法复制/导出
- [ ] 决议与分歧待定项界限清晰，模糊说话人已标为“待确认”
- [ ] 外部平台待办或日程写入前经过用户当次确认
