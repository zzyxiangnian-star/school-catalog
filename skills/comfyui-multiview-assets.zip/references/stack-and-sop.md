# ComfyUI 多视图与工业视觉资产参考手册（Stack & SOP）

## 1. 核心开源底座与关联工具清单

| 类别 | 名称 / 仓库 | 地址 / 端点 | 核心用途 |
| :--- | :--- | :--- | :--- |
| 核心 GitHub 底座 | `Comfy-Org/comfy-skills` | `https://github.com/Comfy-Org/comfy-skills` | 官方维护的 Comfy Cloud Agent Skills（`SKILL.md`）、插件清单与工作流编排规范 |
| 官方云端 MCP | Comfy Cloud MCP Server | `https://cloud.comfy.org/mcp` | 检索节点/模型/工作流模板，并通过 OAuth 授权触发云端 GPU 生成任务 |
| 本地推理引擎 | ComfyUI Local REST API | `http://127.0.0.1:8188`（默认端口） | 本地无头调度 API Format Workflow JSON，读取 `/system_stats`、`/object_info`、`/prompt`、`/history`、`/view` |
| 关联 MCP 插件 | `huggingface` | `https://huggingface.co/settings/mcp` | 检索 Hub 开源基座模型、ControlNet、IP-Adapter、深度/法线估计器、查看模型卡许可并调用带 MCP 徽章的 Space |

---

## 2. 典型 MCP / CLI 配置与环境检测模板

### 2.1 Comfy Cloud MCP 安装与鉴权（基于 `Comfy-Org/comfy-skills`）

**Claude Code 环境：**
```bash
/plugin marketplace add Comfy-Org/comfy-skills
/plugin install comfy-cloud@comfy-skills
```

**OpenClaw CLI 环境：**
```bash
openclaw mcp set comfy '{"url":"https://cloud.comfy.org/mcp","transport":"streamable-http","auth":"oauth"}'
openclaw mcp login comfy
openclaw mcp status --verbose
```

**通用 Skill 加载路径（如 OpenClaw / 自定义客户端）：**
- 指向仓库内技能说明：`https://github.com/Comfy-Org/comfy-skills/tree/main/openclaw/comfy`

### 2.2 Hugging Face MCP 接入

1. 登录 Hugging Face 后访问 `https://huggingface.co/settings/mcp`。
2. 选择对应客户端（Claude Code / Cursor / VS Code 等）复制生成的 MCP 配置与 OAuth/Token 鉴权片段。
3. 如需将特定公开图像预处理/去背景 Space 暴露为工具，在对应 Space 页面点击 **MCP** 徽章并选择 **Add to MCP tools**。

### 2.3 本地 ComfyUI API 就绪检测与最小提交流程

```bash
# 1. 检测本地服务存活与显存状态（若连接拒绝则提示用户启动 ComfyUI）
curl -sf http://127.0.0.1:8188/system_stats

# 2. 检查指定节点（如 ControlNet / PBR / 去背景节点）是否已安装
curl -sf http://127.0.0.1:8188/object_info | head -c 500

# 3. 上传上游参考图（如来自 #17 的买家草图/零件照）
curl -sf -X POST http://127.0.0.1:8188/upload/image \
  -F "image=@./input/raw_part.png" \
  -F "overwrite=true"

# 4. 提交版本化 API Workflow JSON（确保 JSON 中 seed 已锁定）
curl -sf -X POST http://127.0.0.1:8188/prompt \
  -H "Content-Type: application/json" \
  -d @./workflows/multiview_v1.0.0.payload.json

# 5. 查询执行历史并下载输出图
curl -sf http://127.0.0.1:8188/history/<prompt_id>
curl -sf "http://127.0.0.1:8188/view?filename=<output.png>&type=output" -o ./output/front.png
```

> 注意：禁止提交网页端导出的纯 UI 版 `workflow.json`（含 `nodes`/`links` 数组），必须使用 ComfyUI `Save (API Format)` 导出的节点字典结构（以节点 ID 为键，含 `class_type` 与 `inputs`）。

---

## 3. 版本化工作流与跨 Bot 交接标准模板

### 3.1 `manifest.json` 复现清单模板

```json
{
  "task_id": "MV-20261118-001",
  "task_type": "orthographic_multiview",
  "engine": "comfyui-local | comfy-cloud-mcp",
  "workflow_file": "workflows/orthographic_3view.v1.2.0.api.json",
  "workflow_version": "1.2.0",
  "workflow_sha256": "<sha256-of-workflow-api-json>",
  "seed": 42190877,
  "seed_mode": "fixed",
  "models": [
    {
      "role": "base_checkpoint",
      "name": "<verified_model_filename>",
      "license": "<verified_spdx_or_model_card_license>"
    }
  ],
  "inputs": [
    {
      "path": "input/raw_part.png",
      "sha256": "<sha256>"
    }
  ],
  "outputs": [
    {
      "view": "front",
      "path": "output/views/front.png",
      "resolution": "1024x1024",
      "channels": "RGBA",
      "sha256": "<sha256>"
    }
  ]
}
```

### 3.2 C2M 交接契约 `handoff_to_cad.json`（#06 → #02 CAD Bot）

```json
{
  "schema_version": "1.0",
  "source_bot": "comfyui-asset-bot",
  "target_bot": "cad-bot",
  "upstream_bot": "xianyu-bot",
  "order_id": "XY-20261118-8841",
  "unit": "mm",
  "dimension_status": "calibrated | estimated_from_photo | uncalibrated",
  "reference_scale": {
    "known_anchor": "outer_diameter_mm",
    "value_mm": 42.0,
    "source": "buyer_note_from_17"
  },
  "views": {
    "front": {
      "path": "output/views/front.png",
      "width_px": 1024,
      "height_px": 1024,
      "sha256": "<sha256>"
    },
    "side": {
      "path": "output/views/side.png",
      "width_px": 1024,
      "height_px": 1024,
      "sha256": "<sha256>"
    },
    "top": {
      "path": "output/views/top.png",
      "width_px": 1024,
      "height_px": 1024,
      "sha256": "<sha256>"
    },
    "orthographic_sheet": {
      "path": "output/views/orthographic_sheet.png",
      "width_px": 3072,
      "height_px": 1024,
      "sha256": "<sha256>"
    }
  },
  "reproducibility": {
    "workflow_version": "1.2.0",
    "workflow_sha256": "<sha256>",
    "seed": 42190877
  },
  "geometry_risks": [
    "背面卡扣结构在买家破损零件原照中被遮挡，side.png 右侧耳片轮廓为对称推演结果，需 #02 与买家确认孔距。"
  ]
}
```

---

## 4. 交付产物检验清单（Delivery Checklist）

- [ ] **环境真实性**：已真实通过 Comfy Cloud MCP 或本地 ComfyUI `/system_stats` 校验连通性，无伪造执行记录。
- [ ] **工作流格式**：归档文件为 ComfyUI API Format JSON，所有缺失自定义节点（Custom Nodes）与模型文件名均已核对存在。
- [ ] **可复现性**：所有采样节点 `seed` 已固定（非随机 `-1`），`workflow_version` 与 `workflow_sha256`、`manifest.json` 完整落盘。
- [ ] **正交三视图质量**：`front` / `side` / `top` 投影方向正确，无明显透视畸变，主物体高度/宽度在相邻视图间投影对齐，边缘清晰无背景噪点。
- [ ] **PBR 贴图质量**（如请求）：Normal 为标准蓝紫色切线空间法线（非反转 Y 轴混用无说明），Roughness 为单通道语义准确灰度图，各贴图与 Albedo 分辨率/UV 对齐。
- [ ] **去背景质量**（如请求）：输出真 RGBA 透明通道 PNG，边缘无白边/黑边光晕（halo），半透明或孔洞内部已镂空。
- [ ] **C2M 协同安全边界**（对接 `#02` 时）：`unit` 显式写明 `"mm"`，未测量的推演区域已在 `geometry_risks` 如实声明，绝未伪造实测公差。
