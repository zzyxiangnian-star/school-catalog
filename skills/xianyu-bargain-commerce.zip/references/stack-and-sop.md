# 闲鱼与电商自动议价客服参考手册（Stack & SOP）

> 本文档对应 `#17 闲鱼与电商自动议价客服 Bot`（`xianyu-commerce-bot`）及专属技能 `xianyu-bargain-commerce`，仅收录已核实的开源底座架构、典型配置模板与交付检验清单。

---

## 1. 核心 GitHub 开源底座清单

| 仓库 | 定位与职责 | 关键组件 / 入口 | 凭证与前置条件 |
| :--- | :--- | :--- | :--- |
| [shaxiu/XianyuAutoAgent](https://github.com/shaxiu/XianyuAutoAgent) | 闲鱼 7×24 WebSocket 实时监听与多专家意图路由系统 | `main.py`（主循环与 WebSocket 监听）、`XianyuAgent.py`（意图分类 + 议价/技术/默认专家路由）、`XianyuApis.py`（网页端接口与签名）、SQLite 对话记忆 | `.env` 填入大模型 `API_KEY` 与闲鱼网页端 `COOKIES_STR` |
| [DoLovya/xianyu-mcp-server](https://github.com/DoLovya/xianyu-mcp-server) | 基于底层 `pyxianyu` 封装的闲鱼标准 MCP Server | `uvx --from xianyu-mcp-server xianyu-mcp-server`；提供登录态工具（`qr_login_generate` / `qr_login_status` / `check_login`）、商品检索/上下架（`downshelf_item` / `reshelf_item`）、IM 会话与消息工具 | `XIANYU_COOKIE` 或 `XIANYU_COOKIE_FILE`（留空可启动本地扫码首次配置模式） |
| [stripe/ai](https://github.com/stripe/ai) | Stripe 官方 AI 集成与远程托管 MCP 服务 | 远程 MCP 端点 `https://mcp.stripe.com`（OAuth 认证）；替代已逐步废弃的 `@stripe/agent-toolkit` 与 `@stripe/mcp` | Stripe 账号 OAuth 授权或对应插件环境 |

> **平台合规与风控提示**：`shaxiu/XianyuAutoAgent` 与 `DoLovya/xianyu-mcp-server` 均基于闲鱼网页端/H5 接口或 WebSocket 协议运行，存在平台风控与账号受限风险；务必控制回复频率（如开启 `SIMULATE_HUMAN_TYPING=True`），严禁将 Cookie 提交至任何代码仓库。

---

## 2. 典型配置模板

### 2.1 MCP 客户端配置模板（`xianyu-mcp-server` + `stripe`）

```json
{
  "mcpServers": {
    "xianyu-mcp-server": {
      "command": "uvx",
      "args": [
        "--from",
        "xianyu-mcp-server",
        "xianyu-mcp-server"
      ],
      "env": {
        "XIANYU_COOKIE": "<YOUR_XIANYU_COOKIE_OR_LEAVE_EMPTY_FOR_QR_SETUP>",
        "XIANYU_COOKIE_FILE": ""
      }
    },
    "stripe": {
      "type": "http",
      "url": "https://mcp.stripe.com"
    }
  }
}
```

官方插件快速挂载命令（参考 `stripe/ai` 文档）：

```bash
# Claude Code
claude plugin install stripe@claude-plugins-official

# Codex
codex plugin add stripe@openai-curated

# Grok Build
grok plugin install stripe --trust
```

### 2.2 `shaxiu/XianyuAutoAgent` `.env` 最小配置模板

```env
# 大模型推理凭证（OpenAI 兼容接口）
API_KEY=<YOUR_LLM_API_KEY>
MODEL_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
MODEL_NAME=qwen-max

# 闲鱼网页版（goofish.com）F12 获取的 Cookie 字符串
COOKIES_STR=<YOUR_GOOFISH_COOKIES_STR>

# 人工接管切换关键词与拟人延迟
TOGGLE_KEYWORDS=。
SIMULATE_HUMAN_TYPING=True
```

启动命令：

```bash
git clone https://github.com/shaxiu/XianyuAutoAgent.git
cd XianyuAutoAgent
pip install -r requirements.txt
python main.py
```

### 2.3 阶梯底价博弈规则表模板（`pricing_tiers.json`）

```json
{
  "currency": "CNY",
  "skus": [
    {
      "sku_id": "C2M-3DP-BASE-01",
      "title": "定制结构件/桌面支架代打印基础款",
      "list_price": 128.0,
      "tier1_offer_price": 115.0,
      "tier2_floor_price": 102.0,
      "hard_redline_price": 95.0,
      "max_concession_per_turn": 10.0,
      "non_price_perks": ["满99包邮", "加赠备用螺丝包", "48小时优先排机"],
      "c2m_required": true
    }
  ]
}
```

### 2.4 飞书群机器人告警 / 升级审批 Payload 模板

```json
{
  "msg_type": "interactive",
  "card": {
    "header": {
      "title": { "tag": "plain_text", "content": "[闲鱼/电商升级通知] 需要人工介入" },
      "template": "orange"
    },
    "elements": [
      {
        "tag": "div",
        "text": {
          "tag": "lark_md",
          "content": "**工单号**：`ESC-20261118-001`\n**渠道/SKU**：闲鱼 / `C2M-3DP-BASE-01`\n**升级原因**：买家出价 `80 CNY` 低于利润红线 `95 CNY`（或触发售后纠纷）\n**建议动作**：人工复核是否拒单或切换 `TOGGLE_KEYWORDS` 接管会话"
        }
      }
    ]
  }
}
```

---

## 3. 交付产物与运行检验清单（Checklist）

### A. 前置就绪校验（开跑前必查）
- [ ] **闲鱼通道就绪**：已确认 `shaxiu/XianyuAutoAgent` 进程存活，或 `DoLovya/xianyu-mcp-server` 调用 `check_login` 返回有效登录态；未就绪时已向用户给出明确扫码/Cookie 指引并暂停。
- [ ] **Stripe MCP 就绪**：需要独立站收款或核账时，`https://mcp.stripe.com` 已完成 OAuth 授权且可读取目标账户下的 Payment Links / Checkout Sessions。
- [ ] **底价与知识库就绪**：当前商品在 `pricing_tiers.json` 中存在完整四档价格（`list_price` >= `tier1` >= `tier2` >= `hard_redline_price`），且技术参数有本地知识库支撑。
- [ ] **风控与脱敏检查**：输出内容、日志及飞书通知均未泄露明文 Cookie、API Key 或买家完整隐私信息。

### B. 议价与收款回合校验
- [ ] **阶梯纪律**：单轮让步未超过 `max_concession_per_turn`，未在首轮直接报出 `tier2_floor_price` 或 `hard_redline_price`。
- [ ] **话术合规**：每次让步均附带锚定理由（工艺/质保/包邮/时效）；拒单话术礼貌坚定且未暴露内部规则。
- [ ] **收款核验**：Stripe 订单仅在查明 `payment_status == "paid"` 且金额/币种与 SKU 一致后才标记可发货。

### C. C2M 跨 Bot 交接校验（对接 `#06 ComfyUI` / `#02 CAD Bot`）
- [ ] **单位统一**：长宽高、壁厚、公差全部显式换算并标注为 `mm`。
- [ ] **字段完整**：包含唯一 `c2m_order_id`、材料（如 `PETG`/`ABS`/`光敏树脂`）、表面工艺、公差等级与交付期限。
- [ ] **附件可校验**：买家提供的草图/参考图均附带本地文件相对路径与 `sha256` 校验摘要。

### D. 异常与越线升级校验
- [ ] **人工接管**：触发底价红线、仅退款/纠纷威胁或账号风控时，已停止自动议价并推送包含完整上下文的飞书通知卡片。
