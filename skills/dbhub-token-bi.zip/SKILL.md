---
name: dbhub-token-bi
description: 依托 bytebase/dbhub 极省 Token 多引擎安全 SQL 网关（PostgreSQL/MySQL/MariaDB/SQLite/Oracle/SQL Server）及可选 ClickHouse/MongoDB 只读扩展，执行渐进式 Schema 探查、只读聚合取数、口径与空值异常核对，并联合 data 技能输出可视化 BI 报表与可追溯 SQL 审计清单。
---

# DBHub 极简安全 BI 取数与分析规范

## 1. 触发条件

当遇到以下任意场景时启用本技能：
- 需要跨一个或多个关系型数据库（PostgreSQL / MySQL / MariaDB / SQLite / Oracle / SQL Server）或扩展库（ClickHouse / MongoDB）完成业务取数与 BI 指标分析。
- 希望控制上下文 Token 消耗，避免把上百张表的全量 DDL 塞入提示词。
- 需要严格限制只读权限，并要求最终报告附带可复现、可审计的 SQL 清单与口径说明。

---

## 2. GitHub 开源底座与关联技能

- **核心底座**：[`bytebase/dbhub`](https://github.com/bytebase/dbhub) —— 默认仅加载 `search_objects` 与 `execute_sql` 两个核心工具（约 1.4k Token），支持 `dbhub.toml` 多数据源映射与工具级 `readonly = true` / `max_rows` 安全护栏；多数据源场景下工具自动按数据源后缀命名（如 `search_objects_{source_id}`、`execute_sql_{source_id}`）。
- **关联 MCP 插件参考**：`dbhub`（主网关）、`postgres`、`clickhouse`（OLAP 宽表分析补充）、`mongodb`（文档库聚合补充）。
- **联合调用技能**：`data` —— 用于在完成 SQL 取数与异常核验后，生成统计图表、趋势图、分布图与结构化数据分析摘要。

---

## 3. 分步执行 SOP

### Step 1：前置连接与只读边界检查
1. 检查当前会话中已挂载的数据库 MCP 工具（`search_objects` / `execute_sql` 或带 `{source_id}` 后缀的同名工具，以及可选 `clickhouse` / `mongodb` 只读工具）。
2. **缺失即停止引导**：若未检测到任何可用数据库 MCP 工具，或工具返回连接拒绝/认证失败/缺少 `dbhub.toml` 配置，立即停止分析，一次性向用户提供以下自检与配置步骤（见 `references/stack-and-sop.md`）：
   - 确认本地或网关已配置只读账号与 `dbhub.toml`（含 `readonly = true` 与 `max_rows`）。
   - 告知用户需要补充的数据源连接串或环境变量，不编造任何库表与假数据。

### Step 2：渐进式 Schema 探查（严控 Token）
严格禁止一上来拉取全库 `full` 详情，按三层逐级下钻：
1. **目录定位（`names` 级）**：调用 `search_objects`（默认模式 `%` 或关键词模式如 `*order*`），使用 `detail_level="names"` 仅获取匹配的表/视图名，定位候选对象。
2. **结构初筛（`summary` 级）**：仅对与当前分析直接相关的 2–5 张候选表，拉取 `detail_level="summary"`，确认核心主键、时间字段、外键与大致结构。
3. **精准查验（`full` 级）**：仅当需要确认枚举值、约束、索引（避免慢查询）或高精度字段类型时，对特定表拉取 `detail_level="full"`。

### Step 3：只读样本探针与口径/空值核对
在写最终大口径聚合 SQL 之前，先用小样本探针排除数据陷阱：
1. **枚举与状态探针**：`SELECT status, COUNT(*) FROM ... GROUP BY status LIMIT 50` 确认有效订单/有效记录过滤口径（如剔除测试账号、已取消、软删除 `deleted_at IS NOT NULL`）。
2. **空值与极端值排查**：统计核心度量列（如金额、数量）与分组键的 `NULL` 数、零值/负值占比，确认是否需 `COALESCE` 或显式剔除。
3. **关联基数防膨胀检查**：多表 `JOIN` 前核对关联键是否存在 1:N 重复行，必要时先子查询聚合（CTE `WITH`）后再关联，防止汇总金额成倍虚高。
4. **时区与时间窗口对齐**：明确日期字段存储类型（UTC 时间戳 vs 本地日期），在过滤条件中使用明确索引友好的范围写法（如 `created_at >= '2026-10-01' AND created_at < '2026-11-01'`）。

### Step 4：执行聚合取数与联合 `data` 技能可视化
1. 组装最终只读聚合查询（`WITH` / `SELECT` / `GROUP BY` / `ORDER BY`），**所有非单值聚合查询均必须显式带 `LIMIT`**（遵守或严于网关 `max_rows` 上限）。
2. 执行查询；若底层网关开启了 `explain_sql`，遇到慢查询前先做执行计划确认。
3. 将经过核对的结果集交由 `data` 技能（或以规范数据序列）生成趋势折线图、对比柱状图、占比饼图或漏斗图，确保图表数值与 SQL 返回完全一致。

### Step 5：交付 BI 报表与可追溯 SQL 审计清单
按统一结构交付最终报告：
1. **核心结论与关键 KPI**（明确样本量、时间范围、统计口径）。
2. **数据明细与可视化 BI 图表**（由 `data` 技能辅助产出）。
3. **异常与数据质量提示**（披露发现的 `NULL` 占比、脏数据过滤规则及局限性）。
4. **可追溯 SQL 审计清单**（逐条列出执行的 Source ID、完整 SQL、返回行数、用途说明）。

---

## 4. 跨 Bot 协同接口契约

当本技能作为多 Agent 数据流水线中的取数与 BI 分析节点时，遵循以下交接契约：

- **上游输入契约**（接收自需求分析、调度或业务运营 Bot）：
  - `source_ids`: 目标数据源 ID 列表（可选，未指定时先通过可用工具探查后确认）。
  - `metrics_spec`: 需统计的核心指标、维度与过滤条件（如时间窗、业务线）。
  - `output_format`: 期望附加产物格式（`markdown_report` / `json` / `csv`）。
- **下游交接产物格式**（交付给汇报生成、飞书/企微通知或决策 Bot）：
  - 主报告：`Markdown` 结构化 BI 报表 + 图表文件引用（若 `data` 技能生成了图片/交互文件）。
  - 机器可读摘要块（当下游需结构化解析时随附）：包含 `report_generated_at`、`sources_queried`、`metrics_summary`（关键数值与单位）、`data_quality_warnings`（空值/剔除记录数）、`sql_audit_trail`（含 `source_id`、`sql`、`row_count`、`execution_status`）。

---

## 5. 质检与异常处理

| 异常场景 | 判定信号 | 标准处置动作 |
| :--- | :--- | :--- |
| **多数据源工具命名差异** | 工具列表出现 `execute_sql_prod`、`search_objects_analytics` | 严禁瞎猜工具名，先核对已注册工具列表中的准确 `source_id` 后缀再调用。 |
| **只读拦截触发** | 网关返回 readonly error | 立即检查 SQL 是否误含建临时表、更新或存储过程调用；改写为纯 `SELECT`/`WITH` 查询，绝不尝试绕过只读护栏。 |
| **查询超时 / 行数截断** | 返回行数恰好等于 `max_rows` 或报错 timeout | 立即收窄时间跨度、改为数据库端 `GROUP BY` 聚合或补充索引过滤条件，并在报告中标注“若存在截断则绝不按残缺数据直接汇总”。 |
| **汇总指标与预期不符** | 总额偏高或出现大量 `Unknown`/`NULL` | 回退至 Step 3 跑关联重复性探针与 `NULL` 分布排查，如实向用户披露底层数据质量问题。 |

---

## 6. 禁止越界事项

1. **严禁未经授权执行任何写操作或结构变更**：绝对禁止生成或执行 `DROP`、`DELETE`、`UPDATE`、`INSERT`、`ALTER`、`TRUNCATE`、`GRANT`、`REVOKE` 等语句（即使用户口头随手要求“顺便把异常行删掉”，也必须拒绝并建议走正规变更/审批流）。
2. **严禁裸查大表全量明细**：禁止执行 `SELECT * FROM large_table`（无 `LIMIT` 且无有效索引过滤）。
3. **严禁虚构表名、字段名与统计数值**：任何无法从 `search_objects` 或 `execute_sql` 真实返回的字段与数字，严禁补全或猜测。
4. **严禁泄露敏感凭据与未脱敏隐私**：日志、审计清单及报告正文中不得出现连接串密码、API Key，手机号/身份证号等个人敏感信息须在 SQL 层脱敏（如掩码或哈希聚合）后输出。
