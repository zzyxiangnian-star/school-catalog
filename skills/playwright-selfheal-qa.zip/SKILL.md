---
name: playwright-selfheal-qa
description: 基于微软官方 microsoft/playwright-mcp 无障碍树编写端到端 E2E 测试、捕获控制台与网络报错、在 UI 轻微改版时基于语义角色自愈修复测试脚本，并生成带 trace 与截图的验收报告。
---

# Playwright 自愈 QA（`playwright-selfheal-qa`）

## 1. 触发条件

当用户或上游流水线提出以下任一需求时激活本技能：
- 为 Web 应用（本地 dev server、Preview URL 或 Staging 站点）从零编写端到端（E2E）测试用例；
- 执行既有 Playwright 测试并捕获浏览器 `console.error`、`pageerror`、HTTP `4xx/5xx` 或请求超时异常；
- 前端 UI 轻微改版（文案微调、组件外层 DOM 重构、样式类名变动）导致旧选择器失效，需要排查并基于语义角色自愈修复 `*.spec.ts`；
- 在发版前或工作日早晨定时执行核心链路冒烟巡检，并输出带 `trace.zip` 与截图证据的验收报告。

## 2. GitHub 开源底座与协同工具

- **核心底座**：`microsoft/playwright-mcp`（基于浏览器无障碍树 Accessibility Tree 暴露结构化语义快照，不依赖脆弱 XPath 或纯像素截图猜测）
- **可联合调用的目录既有技能**：`playwright`
- **关联 MCP 插件**：`playwright`（页面导航、无障碍树快照、交互与控制台/网络采集）、`chrome-devtools`（深层网络瀑布流、DOM 样式与脚本异常补充排查）
- **本地测试运行器**：`@playwright/test`（用于持久化 `*.spec.ts` 回归执行、Trace 录制与截图输出）

## 3. 分步执行 SOP

### Step 1：前置环境与鉴权就绪检测（Fail-Fast）
1. 校验目标站点 URL 或本地端口是否可达，确认仓库中是否存在 `playwright.config.*` 与目标测试目录。
2. 核验 `playwright` MCP 工具是否已挂载且浏览器可正常启动；若需本地执行 `npx playwright test`，先运行 `npx playwright --version` 核验依赖与浏览器二进制。
3. 若页面受登录态保护，检查用户是否提供了只读测试账号或 `storageState.json` 路径。
4. **缺失引导规则**：任何前置工具未安装、MCP 未配置、目标服务未启动或缺少测试凭证时，立即停止并输出 `BLOCKED`，一次性列出确切的安装/启动/配置命令（参考 `references/stack-and-sop.md`），绝不绕过检测或编造运行结果。

### Step 2：无障碍树（Accessibility Tree）勘测
1. 调用 `playwright` MCP 打开目标 URL，使用无障碍树快照（`browser_snapshot`）采集页面可交互元素的真实语义角色（`role`）、可访问名称（`name`）、标签（`label`）与当前状态（`disabled`/`checked`/`expanded`）。
2. 如需定位脚本未显式暴露的深层异常，可联合调用 `chrome-devtools` MCP 查看详细 Console 堆栈与 Network 请求头/响应体。
3. 记录关键业务节点的语义锚点映射表，作为编写用例与后续自愈的基准。

### Step 3：编写低脆性语义 E2E 测试
1. 严格按以下定位优先级编写 `*.spec.ts`（或借助 `playwright` 技能生成标准化测试文件）：
   - `getByRole(role, { name })` > `getByLabel` / `getByPlaceholder` > `getByText` > `getByTestId`
2. 严禁写入绝对 XPath（如 `/html/body/div[2]/...`）或编译生成的随机 CSS 哈希类名。
3. 在关键状态切换后添加显式 Web-First 断言（如 `await expect(...).toBeVisible()`、`toHaveURL()`、`toHaveText()`），并启用 Trace 录制与失败截图（`--trace=on`）。

### Step 4：执行回归并捕获控制台与网络报错
1. 执行新编或既有用例，同步收集：
   - 浏览器控制台 `console.error` 与未捕获异常 `pageerror`；
   - 网络请求失败（`requestfailed`）及非预期 HTTP `4xx/5xx` 接口响应。
2. 若用例全部通过且零异常报错，直接进入 Step 6 输出验收报告。

### Step 5：UI 改版语义自愈修复（核心判定边界）
当测试因定位失败超时或报错时，必须先做**故障分流**，严禁盲目改写测试：
1. **重新采集无障碍树**：在失败页面状态抓取最新 Accessibility Tree 快照与截图，并核对网络/控制台是否有服务端报错。
2. **分流判定**：
   - **允许自愈（Selector Drift）**：页面业务功能正常、无阻塞性接口错误，仅因文案同义微调（如“立即提交”改为“确认提交”）、标签层级调整或语义角色微调（如 `link` 改为 `button`）导致旧定位器失效 -> 基于新无障碍树语义匹配等价目标元素，生成最小化 `*.spec.ts` diff，**保持原有业务结果断言不变**，重跑全量受影响用例验证通过后标记为 `HEALED`。
   - **禁止自愈（Real Regression）**：目标功能元素完全消失、核心接口返回 `4xx/5xx`、控制台抛出阻断性 JS 异常、或业务结果（金额、状态流转、权限拦截）与预期不符 -> 判定为真实缺陷 `FAIL`，保留原失败现场并输出复现步骤，绝不修改断言掩盖 Bug。

### Step 6：生成 Trace 与截图验收报告
1. 汇总本次运行的 `trace.zip` 路径、关键步骤/失败现场截图路径、`*.spec.ts` 变更 diff、Console/Network 异常列表与总状态结论（`PASS` / `HEALED` / `FAIL` / `BLOCKED`）。
2. 输出结构化交付摘要，确保人类开发者或上游编排 Agent 可直接定位并复核。

## 4. 跨 Bot 协同接口契约

### 4.1 上游输入契约（接收开发 / PR / 发版 Bot 派单）
```json
{
  "target_url": "http://localhost:5173",
  "repo_path": "./",
  "changed_routes": ["/login", "/checkout"],
  "checklist": ["登录成功跳转首页", "提交订单返回 201 且展示订单号"],
  "spec_glob": "tests/e2e/**/*.spec.ts",
  "auth_state_path": ".auth/test-user.json",
  "mode": "verify_and_heal"
}
```
- 缺失 `target_url` 时先向用户或上游一次索取；`auth_state_path` 为可选只读测试态路径，文件不存在且页面需登录时应立即返回 `BLOCKED` 并引导生成。

### 4.2 下游交接产物格式（交付发版门禁 / 缺陷追踪 / 通知 Bot）
交付报告末尾附带标准化机器可读摘要 `smoke-summary.json`（或内嵌 JSON 块）：
```json
{
  "status": "PASS | HEALED | FAIL | BLOCKED",
  "target_url": "http://localhost:5173",
  "total": 6,
  "passed": 5,
  "healed": 1,
  "failed": 0,
  "console_errors": [],
  "network_errors": [],
  "healed_files": ["tests/e2e/checkout.spec.ts"],
  "artifacts": {
    "trace_zip": "test-results/checkout/trace.zip",
    "screenshots": ["test-results/checkout/final.png"],
    "report_html": "playwright-report/index.html"
  }
}
```

## 5. 质检与异常处理

- **环境异常**：本地端口无响应或 Playwright 浏览器二进制未下载 -> 立即报告 `BLOCKED` 与具体修复命令，不尝试绕过检查。
- **鉴权失效**：检测到重定向至 `/login` 且无有效 `storageState` -> 停止操作并提示用户重新生成只读测试登录态，绝不猜测密码或绕过认证。
- **自愈防退化校验**：每次自愈完成后，必须确认 diff 仅触及定位器表达式（`getByRole`/`getByLabel` 等），且重新运行后原始断言链路完整执行无跳过（`test.skip`）。

## 6. 禁止越界事项

- **严禁**使用脆弱绝对 XPath 或构建哈希 CSS 类名作为测试定位器。
- **严禁**在自愈过程中删除、注释或放宽业务结果断言，或使用 `test.skip()` 隐藏失败用例。
- **严禁**在生产环境执行真实资金交易、真实用户数据篡改或破坏性删除操作。
- **严禁**未经用户确认直接 `git push`、合并 PR 或修改生产部署配置。
- **严禁**在未实际运行测试或未真实生成文件的情况下虚构 `PASS` 结论、Trace 路径或截图附件。
