# KiCad PCB 工程审查与投板验收参考手册

## 1. 核心开源底座与工具链清单

| 组件 | 来源 / 定位 | 核心用途 |
| --- | --- | --- |
| `lamaalrajih/kicad-mcp` | GitHub 开源 MCP Server (`https://github.com/lamaalrajih/kicad-mcp`) | 发现本地 KiCad 工程，解析 `.kicad_sch` / `.kicad_pcb`、提取网表与 BOM、读取与触发 DRC 检查 |
| `KiCad 9.0+ (kicad-cli)` | KiCad 官方命令行工具 | 确定性执行 `sch erc`、`pcb drc`、`sch export bom`、`pcb export gerbers`、`pcb export drill`、`pcb export pos` |
| `filesystem` MCP | 官方文件系统 MCP | 在授权工作区目录内安全读取工程文件、校验投板输出目录文件清单与计算文件哈希 |

> 前置要求：Python `>= 3.10`、`uv >= 0.8.0`、KiCad `>= 9.0`（确保 `kicad-cli` 可执行）。

---

## 2. 典型 MCP 与环境配置模板

### 2.1 `lamaalrajih/kicad-mcp` 本地部署与 `.env`

```bash
git clone https://github.com/lamaalrajih/kicad-mcp.git
cd kicad-mcp
make install
```

在仓库根目录创建 `.env`（指向你的本地 KiCad 工程根目录，多个路径用英文逗号分隔）：

```env
# Linux / macOS 示例
KICAD_SEARCH_PATHS=~/pcb,~/Electronics,~/Projects/KiCad

# Windows 示例
# KICAD_SEARCH_PATHS=D:\Hardware\KiCad_Projects,C:\Users\YourName\Documents\KiCad
```

### 2.2 MCP 客户端配置模板（含 `kicad` 与 `filesystem`）

```json
{
  "mcpServers": {
    "kicad": {
      "command": "/ABSOLUTE/PATH/TO/kicad-mcp/.venv/bin/python",
      "args": [
        "/ABSOLUTE/PATH/TO/kicad-mcp/main.py"
      ]
    },
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/ABSOLUTE/PATH/TO/YOUR/KICAD_WORKSPACE"
      ]
    }
  }
}
```

> Windows 下将 `command` 替换为 `D:\\path\\to\\kicad-mcp\\.venv\\Scripts\\python.exe`。

### 2.3 KiCad 9.0+ `kicad-cli` 核心命令参考

> 提示：Windows 默认路径通常为 `C:\Program Files\KiCad\9.0\bin\kicad-cli.exe`；macOS 为 `/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli`；Linux/Docker 为 `kicad-cli`。

```bash
# 0. 版本检测
kicad-cli version

# 1. 原理图 ERC（违规时返回非零退出码 5）
kicad-cli sch erc \
  --output reports/erc-report.rpt \
  --severity-all \
  --exit-code-violations \
  project.kicad_sch

# 2. PCB DRC（违规时返回非零退出码 5）
kicad-cli pcb drc \
  --output reports/drc-report.rpt \
  --exit-code-violations \
  project.kicad_pcb

# 3. 导出标准 BOM（面向采购与 #07 成本核算）
kicad-cli sch export bom \
  --output fab_out/bom.csv \
  --format csv \
  --fields "Reference,Value,Footprint,LCSC,MPN,DNP" \
  --group-by "Value,Footprint,MPN" \
  --sort-asc \
  project.kicad_sch

# 4. 导出 Gerber（KiCad 9 推荐使用复数 gerbers）
mkdir -p fab_out/gerbers
kicad-cli pcb export gerbers \
  --output fab_out/gerbers/ \
  project.kicad_pcb

# 5. 导出 Excellon 钻孔文件
kicad-cli pcb export drill \
  --output fab_out/gerbers/ \
  project.kicad_pcb

# 6. 导出 Pick-and-Place 贴片坐标（单位固定 mm）
kicad-cli pcb export pos \
  --output fab_out/pos.csv \
  --format csv \
  --units mm \
  --side both \
  project.kicad_pcb
```

---

## 3. 交付产物检验清单（Fab Gate Checklist）

### 3.1 规则与电气核查项
- [ ] **版本快照**：执行修改或导出前，工程已存在 Git Commit 或时间戳只读备份。
- [ ] **ERC 门禁**：`erc-report.rpt` 中 `Errors = 0`，所有 `Warnings`（如未标注 `No Connect` 的悬空脚、电源脚方向冲突）已逐条确认原因。
- [ ] **DRC 门禁**：`drc-report.rpt` 中 `Errors = 0`、`Unconnected items = 0`。
- [ ] **封装匹配**：`.kicad_sch` 中所有非 DNP 器件均绑定有效 `Footprint`，无丢失焊盘编号（Pin Number 与 Pad Number 一一对应）。
- [ ] **电源与载流**：主电源轨（如 `VBUS`、`5V`、`3V3`、电机/功率轨）线宽满足 IPC-2152/IPC-2221 温升要求，高电流过孔阵列充足，GND 回流平面不被长信号线割裂。
- [ ] **高速/差分线**：USB D+/D-、以太网、LVDS/MIPI 等差分对同层走线、参考平面完整、等长与线距符合目标阻抗约束。

### 3.2 投板制造文件完整性校验
- [ ] **Gerber 必需层齐全**：包含 `F.Cu`、`B.Cu`（及多面板内层 `In*.Cu`）、`F.Mask`、`B.Mask`、`F.Silkscreen`、`B.Silkscreen`、`F.Paste`、`B.Paste` 与闭合的 **`Edge.Cuts`** 板框层。
- [ ] **Drill 文件对齐**：Excellon 钻孔文件（`.drl`）存在，PTH/NPTH 分类正确，与 Gerber 原点及单位一致（推荐 `mm`）。
- [ ] **Pick-and-Place (POS)**：当存在贴片件时，`pos.csv` 包含 `Ref, Val, Package, PosX, PosY, Rot, Side`，坐标单位明确为 `mm`。
- [ ] **BOM 与 #07 交接核验**：`bom.csv` 字段完整（含位号、型号/值、封装、数量、LCSC/MPN），已标注 `DNP` 不贴片器件，并附带 `fab_out/` 产物 SHA-256 校验摘要。
