---
name: legal
description: "Speed up contract review, NDA triage, compliance workflows, legal brief drafting, and precedent research for in-house legal teams."
---

# Legal

Speed up contract review, NDA triage, compliance workflows, legal brief drafting, and precedent research for in-house legal teams.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (9)

- `legal-brief`
- `legal-compliance-check`
- `legal-legal-response`
- `legal-legal-risk-assessment`
- `legal-meeting-briefing`
- `legal-review-contract`
- `legal-signature-request`
- `legal-triage-nda`
- `legal-vendor-check`
