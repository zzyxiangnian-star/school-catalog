---
name: cursor-team-kit
description: "Cursor engineering team workflows for CI fixing, code review, shipping, smoke testing, deslopping, and weekly engineering summaries."
---

# Cursor Team Kit

Cursor engineering team workflows for CI fixing, code review, shipping, smoke testing, deslopping, and weekly engineering summaries.

Source: https://github.com/cursor/plugins

## Included Skills (18)

- `cursor-team-kit-check-compiler-errors`
- `cursor-team-kit-control-cli`
- `cursor-team-kit-control-ui`
- `cursor-team-kit-deslop`
- `cursor-team-kit-fix-ci`
- `cursor-team-kit-fix-merge-conflicts`
- `cursor-team-kit-get-pr-comments`
- `cursor-team-kit-loop-on-ci`
- `cursor-team-kit-make-pr-easy-to-review`
- `cursor-team-kit-new-branch-and-pr`
- `cursor-team-kit-pr-review-canvas`
- `cursor-team-kit-review-and-ship`
- `cursor-team-kit-run-smoke-tests`
- `cursor-team-kit-thermo-nuclear-code-quality-review`
- `cursor-team-kit-verify-this`
- `cursor-team-kit-weekly-review`
- `cursor-team-kit-what-did-i-get-done`
- `cursor-team-kit-workflow-from-chats`
