---
name: claude-discord
description: "Anthropic 官方插件，为助手提供带配对认证、白名单与策略管控的 Discord 消息通道。"
---

# Claude Discord Channel

Anthropic 官方插件，为助手提供带配对认证、白名单与策略管控的 Discord 消息通道。

Source: https://github.com/anthropics/claude-plugins-official

## Included Skills (2)

- `claude-discord-access`
- `claude-discord-configure`
