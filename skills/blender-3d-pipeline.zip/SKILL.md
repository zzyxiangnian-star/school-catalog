---
name: blender-3d-pipeline
description: 通过 ahujasid/mcp-for-blender 直连 Blender 执行程序化建模、CAD 零件导入、PBR 材质布光、相机动画与 Cycles/EEVEE 渲染导出（.blend/.glb/PNG/MP4）。
---

# Blender 三维场景与渲染流水线 (`blender-3d-pipeline`)

## 1. 触发条件

当任务涉及以下任意场景时启用本技能：
- 在 Blender 中从零构建程序化 3D 模型、产品展示台、建筑/空间场景或几何动效；
- 导入外部三维模型（含上游 `#02 CAD 机械建模 Bot` 交付的机械零件/结构件）进行材质赋予、商业级棚拍布光与渲染；
- 构建 Principled BSDF 程序化 PBR 材质、三点布光 / HDRI 环境光、Shadow Catcher 接地投影或相机环绕/推拉轨道动画；
- 渲染输出高分辨率静帧（`.png`）、带完整材质的 Web 3D 资产（`.glb`）、动画成片（`.mp4`）或可复现工程文件（`.blend`），供下游 `#08 HyperFrames 视频 Bot` 合成宣传片。

---

## 2. GitHub 开源底座

本技能强依赖真实开源桥接项目 **`ahujasid/mcp-for-blender`**（PyPI 包 `mcp-for-blender` / `blender-mcp`）：
- **Blender 端**：安装 `addon.py` 插件并在 3D 视口侧边栏启动本地 Socket 服务（默认 `127.0.0.1:9876`）。
- **MCP 端**：通过 `uvx mcp-for-blender` 启动标准 stdio MCP Server，向 Agent 暴露场景感知与 Python 执行能力，核心工具包括：
  - `get_scene_info`：读取当前场景对象列表、类型、层级与基础状态；
  - `get_object_info` / `get_viewport_screenshot`：读取指定对象细节与当前视口渲染预览截图（工具名以当前挂载的 `mcp-for-blender` 版本实际暴露为准）；
  - `execute_blender_code`：在运行中的 Blender 主进程上下文执行 `bpy` Python 脚本。

---

## 3. 前置环境检测与缺失引导（严禁跳过）

在执行任何建模或渲染动作前，**必须先检测连通性**：
1. 尝试调用 `get_scene_info` 读取 Blender 当前场景。
2. **若调用失败 / 工具不可用 / 返回连接被拒（Connection Refused）**：立即停止后续流程，不要伪造成功或退化为未验证的离线脚本，向用户一次性输出以下排查清单：
   - 确认本机已安装 Blender（建议 3.6 LTS 或 4.x）并**保持打开状态**；
   - 确认已安装 `uv`（提供 `uvx` 命令）且宿主已配置 `"command": "uvx", "args": ["mcp-for-blender"]`；
   - 确认已在 Blender `Edit -> Preferences -> Add-ons` 中安装并启用来自 `ahujasid/mcp-for-blender` 的 `addon.py`；
   - 确认已在 Blender 3D 视口按 `N` 键打开右侧栏，切至 `BlenderMCP` / `MCP for Blender` 标签页并点击启动本地服务（默认端口 `9876`）。

---

## 4. 分步执行 SOP

### Step 1：场景盘点与基准初始化
- 调用 `get_scene_info` 确认当前工程是否为空白默认场景（如 `Cube`/`Light`/`Camera`）或用户已有工程。
- 若为新建展示场景，清理默认无用占位体前先确认不要误删用户原有资产；统一将场景单位设为公制（`METRIC`），色彩管理优先使用 `AgX`（若 Blender < 4.0 回退 `Filmic`）。

### Step 2：上游导入与尺度校准 / 程序化建模
- **导入外部模型（含 `#02` CAD 交接件）**：
  - 优先接收 `.glb`/`.gltf`/`.obj`/`.stl`/`.fbx`；若用户或上游仅提供 `.step`/`.stp` 且当前 Blender 未装 STEP 插件，明确告知需先由 `#02` 导出高精度 `.glb`/`.stl`/`.obj`。
  - 导入后核对包围盒尺寸：CAD 常以毫米（mm）导出，导入 Blender 默认米制时会放大 1000 倍，必须按 `0.001` 缩放并执行 `transform_apply(scale=True)`，随后将模型联合包围盒最低点贴合 `Z = 0`。
- **程序化建模**：
  - 通过 `execute_blender_code` 使用 `bpy` / `bmesh` 编写幂等脚本（先清理同名旧 Collection 或使用专属 Collection 管理，避免重复运行产生冗余对象）。
  - 为硬表面零件添加合理 `BEVEL` 修改器（倒角高光）与平滑着色（`shade_smooth` / Auto Smooth），**严禁修改上游功能零件的孔位、配合面尺寸**。

### Step 3：PBR 材质节点搭建
- 全部使用节点式 `Principled BSDF`（兼容 Blender 3.x 与 4.x 输入槽名称，编写脚本时注意兼容 `Specular IOR Level` 与 `Specular`、`Coat Weight` 与 `Clearcoat` 差异）。
- 根据产品属性构建真实物理材质：阳极氧化铝/拉丝金属（高 `Metallic` + 程序化 `Noise Texture` 各向异性粗糙度微扰）、磨砂塑料（微弱次表面/细粒度凹凸 `Bump`）、透明玻璃（`Transmission` + 正确 `IOR`）。
- 外部贴图缺失时立即报错或改用程序化节点，绝不保留洋红色缺失贴图状态。

### Step 4：商业级布光与摄影棚环境
- 搭建无影弧形背景板（Backdrop）或启用桌面/地面 `Shadow Catcher`，避免背景生硬切边。
- 优先采用经典商业三点布光（主光 `Area Light` 柔光箱 + 轮廓分离边缘光 `Rim Light` + 弱补光）或加载可控旋转角的 HDRI 环境纹理，确保金属倒角出现清晰高光条纹而主体不死黑、不过曝。

### Step 5：相机构图与轨迹动画
- 设置商业产品焦段（静帧推荐 `50mm–85mm`，减少透视畸变），通过 `Track To` 约束锁定产品视觉中心空物体（`Empty`）。
- 若需视频片段，构建平滑 Bezier 运镜（如 360° 匀速转台、45° 俯拍推近或局部特写摇移），显式设定起止帧（`frame_start` / `frame_end`）与帧率（`30` 或 `60 fps`）。

### Step 6：视口视觉自检（强制门禁）
- **正式渲染前必须先调用 `get_viewport_screenshot`**（或低采样快速预览渲染并回读图像），检查：
  1. 主体是否完整落在安全框内，有无被裁切；
  2. 是否存在模型穿插、悬空、破面或法线反转导致的黑斑；
  3. 高光是否过曝、暗部是否糊成一片、背景过渡是否干净。
- 发现问题立即修改 `bpy` 参数并再次截图复检，直至构图与光影达标。

### Step 7：渲染与打包导出
- 按需选择引擎：
  - **商业主图 / 写实静帧**：`CYCLES` + 开启降噪（`use_denoising = True`），先以 `64–128` 采样验证，终稿按硬件算力合理设定采样与分辨率；
  - **长序列转台 / 快速动态预览**：`BLENDER_EEVEE_NEXT`（或 `BLENDER_EEVEE`）配合光线追踪/屏幕空间反射。
- 导出前执行 `bpy.ops.file.pack_all()` 打包贴图并保存 `.blend` 工程；按需求导出 `.glb`、`.png` 或 `.mp4`（FFmpeg `H.264` + `MPEG4`，常数帧率），全部使用绝对路径。

---

## 5. 跨 Bot 协同接口契约

### 5.1 上游接口：承接 `#02 CAD 机械建模 Bot`
- **期望输入格式**：`.glb`（优先，自带法线与基础分区）、`.obj`、`.stl`（高精度曲面细分）或 `.fbx`。
- **必备元数据**：源单位（`mm` / `cm` / `m`）、零件包围盒尺寸（L×W×H）、关键材质说明（如外壳铝合金、按钮硅胶）及文件 `sha256`。
- **异常拒收/回退**：若模型存在严重非流形破面导致法线混乱或未细分呈多边形锯齿，明确向用户反馈回 `#02` 重新按较高弦高公差导出。

### 5.2 下游接口：交付 `#08 HyperFrames 视频 Bot`
输出成片目录时，除渲染产物本身外，附带结构化 `render_manifest.json` 以便 `#08` 直接编排剪辑与文字动效叠层：
```json
{
  "producer": "blender-3d-bot",
  "target_consumer": "hyperframes-video-bot",
  "render_engine": "CYCLES",
  "resolution": [1920, 1080],
  "fps": 30,
  "duration_sec": 6.0,
  "camera_focal_mm": 65,
  "has_alpha": false,
  "assets": [
    {
      "role": "hero_turntable",
      "path": "/abs/path/to/hero_turntable.mp4",
      "sha256": "..."
    },
    {
      "role": "hero_still",
      "path": "/abs/path/to/hero_still.png",
      "sha256": "..."
    }
  ]
}
```

---

## 6. 质检与异常处理

| 异常现象 | 根因排查 | 处理规范 |
|---|---|---|
| `addon.py` 端口无响应 | Blender 未开、插件未勾选或未点击启动连接 | 停止执行并输出前置引导步骤，绝不硬写结果 |
| `Principled BSDF` 节点 KeyError | Blender 3.x 与 4.x Socket 命名变更（如 `Specular` vs `Specular IOR Level`） | 在脚本中用 `if name in bsdf.inputs:` 动态适配版本 |
| 导入零件黑屏或消失 | 单位未缩放导致相机处于物体内部，或超出 `clip_end` | 统一按单位比例缩放、`Apply Scale` 并自动对焦相机距离 |
| Cycles 渲染显存 OOM / 超时 | 分辨率过高、细分等级过大（Subsurf > 3）或采样过高 | 降低视图/渲染细分差异、启用自适应采样或切至 EEVEE 先出预览 |

---

## 7. 禁止越界事项

- 绝不擅自编写与 3D 场景无关的系统级命令或删除工作目录外的文件；
- 绝不修改 `#02` CAD 上游零件的工程结构与配合公差；
- 绝不承担视频剪辑配音、字幕节奏编排或成片营销文案包装（渲染完成后移交 `#08 HyperFrames 视频 Bot`）；
- 绝不夸大硬件渲染能力或伪造未真实生成的渲染路径与截图结论。
