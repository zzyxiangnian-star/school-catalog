# 3D 打印与智能家居联动技术栈与检验清单（`stack-and-sop.md`）

本文档为 `bambu-homeassistant-fab` 技能的配套工程参考，汇总已验证的三方开源底座、典型配置模板与交付产物验收清单。

---

## 1. 核心 GitHub 开源底座清单

| 仓库 | 定位 | 核心能力与协议 | 关键配置项 |
| :--- | :--- | :--- | :--- |
| [DMontgomery40/bambu-printer-mcp](https://github.com/DMontgomery40/bambu-printer-mcp) | 拓竹 Bambu Lab 局域网 MCP 服务 | 基于 LAN Mode 的 MQTT 遥测/控制与 FTPS 文件传输；支持 `.3mf` 上传打印、AMS 槽位映射、喷嘴/热床/腔温读取、STL 网格基础变换及切片器联动 | `BAMBU_IP`（或 `PRINTER_HOST`）、`BAMBU_ACCESS_CODE`（或 `BAMBU_TOKEN`）、`BAMBU_SERIAL`、`BAMBU_MODEL` |
| [codeofaxel/Kiln](https://github.com/codeofaxel/Kiln) | 3D 打印编排 MCP 与 CLI 套件 | 支持 `pip install kiln3d` 与 `kiln serve`；整合 OrcaSlicer/PrusaSlicer 切片、模型检索、任务队列、状态查询（`kiln status --json`）、画面抓拍（`kiln snapshot`）与安全停靠（`kiln park`） | `~/.kiln/config.yaml`（通过 `kiln setup` / `kiln auth` 初始化） |
| [tevonsb/homeassistant-mcp](https://github.com/tevonsb/homeassistant-mcp) | Home Assistant 智能家居 MCP 服务 | 基于 Node.js (>= 20.10.0) 或 Docker 对接 HA REST/WebSocket API；支持灯光、开关、风扇、传感器、摄像头与自动化脚本的读取与触发 | `HASS_HOST`、`HASS_TOKEN`（Long-Lived Access Token）、`HASS_SOCKET_URL`、`PORT` |

> **安全边界提示**：所有 Access Code 与 Long-Lived Access Token 仅能保存在本机 `.env` 或 MCP 客户端配置中，严禁粘贴到对话或写入版本库。

---

## 2. 典型 MCP 与环境配置模板

### 2.1 `.env.example`（本地环境变量模板）

```env
# --- Bambu Lab 局域网连接（需在打印机屏幕开启 LAN Only / 开发者模式） ---
BAMBU_IP=192.168.1.100
BAMBU_ACCESS_CODE=<your_bambu_lan_access_code>
BAMBU_SERIAL=<your_printer_serial_number>
BAMBU_MODEL=p1s

# --- Home Assistant 连接（用于排风扇/照明/插座/传感器联动） ---
HASS_HOST=http://homeassistant.local:8123
HASS_SOCKET_URL=ws://homeassistant.local:8123/api/websocket
HASS_TOKEN=<your_ha_long_lived_access_token>
PORT=3000
```

### 2.2 MCP 客户端配置模板（`.mcp.json` / `claude_desktop_config.json` 参考）

```json
{
  "mcpServers": {
    "bambu-printer": {
      "command": "python",
      "args": ["-m", "bambu_printer_mcp"],
      "env": {
        "BAMBU_IP": "192.168.1.100",
        "BAMBU_ACCESS_CODE": "<your_bambu_lan_access_code>",
        "BAMBU_SERIAL": "<your_printer_serial_number>",
        "BAMBU_MODEL": "p1s"
      }
    },
    "kiln": {
      "command": "kiln",
      "args": ["serve"]
    },
    "homeassistant": {
      "command": "node",
      "args": ["/path/to/homeassistant-mcp/dist/index.js"],
      "env": {
        "HASS_HOST": "http://homeassistant.local:8123",
        "HASS_SOCKET_URL": "ws://homeassistant.local:8123/api/websocket",
        "HASS_TOKEN": "<your_ha_long_lived_access_token>"
      }
    }
  }
}
```

*(注：若使用 `DMontgomery40/bambu-printer-mcp` 官方仓库源码运行，请按其仓库 `README` 指定的 `uv` / `python` 入口路径替换 `command` 与 `args`；`Kiln` 亦可通过 `pip install kiln3d` 安装后直接运行 `kiln serve`。)*

### 2.3 Kiln 常用 CLI 检测模式（Agent 友好 JSON 输出）

```bash
# 1. 检查本地 Kiln 与已配置打印机状态
kiln status --json

# 2. 抓拍当前打印机监控画面用于防炒面视觉核验
kiln snapshot --json

# 3. 紧急异常时停靠喷头并保护现场
kiln park --json
```

---

## 3. 交付产物与跨 Bot 交接检验清单

### 3.1 模型与切片阶段门禁
- [ ] 输入文件为合法 `.stl` 或 `.3mf`，本地文件存在且 `sha256` 与上游派单一致。
- [ ] 几何单位确认为 `mm`，零件包围盒未超出目标机型（如 `256×256×256 mm`）有效成型空间。
- [ ] 模型已正确贴合热床底部（无悬空），关键悬垂区域已启用合理支撑。
- [ ] 切片产物（`.gcode.3mf`）的层高、填充、喷嘴/热床温度与目标 AMS 槽位耗材材质严格匹配。

### 3.2 开印与防炒面巡检门禁
- [ ] 开印前已通过 Home Assistant 联动打开对应打印工位排风扇/空气净化与照明实体。
- [ ] 已确认热床空闲、门盖/风道状态正常，并通过 FTPS/MQTT 成功提交任务并回读到活跃任务 ID。
- [ ] 打印过程中已按巡检节拍采集机舱画面与温度/进度遥测，无脱床、翘边、炒面或断料告警。
- [ ] 如触发异常拉丝，已立即执行暂停指令并推送带快照路径的告警记录。

### 3.3 完工收尾与下游交接门禁
- [ ] 打印进度 `100%` 且热床冷却至安全取件温度后，已延迟关闭排风扇并将指示灯切换为待取件状态。
- [ ] 跨 Bot 交接 JSON 字段完整（`order_id`、`job_id`、`status`、`gcode_3mf_path`、`filament_used_g`、`duration_min`、`snapshot_path`、`feishu_card_payload`）。
