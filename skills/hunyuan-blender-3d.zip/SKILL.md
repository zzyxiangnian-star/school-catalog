---
name: "混元生 3D 与 Blender 修整流程"
description: "云端文图生 3D 初模并联动 Blender MCP 完成缩放、补洞与多视角校验"
---

# 3D 建模助手 — 混元生 3D 与 Blender 修整流程

## 定位与适用范围

打通国内直连的腾讯云混元生 3D API 与 mcp-for-blender，无需本地高显存 N 卡即可完成初模生成、单位毫米化、贴地齐平、网格修复及 STL/GLB 导出。

- **归属 Bot**：`hunyuan-3d-modeling-bot`（分类：`design`）
- **协同目录技能**：无（本技能独立承担全流程）
- **关联推荐 MCP 插件**：mcp-for-blender

## 核心开源工具栈（国内高可用）

- ahujasid/mcp-for-blender — MIT（原 blender-mcp，Blender >= 3.0 插件联动）
- 腾讯云混元生 3D 官方 API（国内直连，人民币按量计费，免本地 GPU）
- RobLe3/cc-blender-skill — MIT（链式 Blender 操作规范参考）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- 本机安装 Blender >= 3.0 与 uv，运行 `uvx mcp-for-blender install-addon` 并启用插件
- 务必配置 `BLENDER_MCP_SAFE_MODE=1` 与 `BLENDER_HOST=localhost`，仅监听 `127.0.0.1:9876`
- 使用云端生 3D 需开通腾讯云混元生 3D 并自备 `TENCENTCLOUD_SECRET_ID` / `TENCENTCLOUD_SECRET_KEY`

## 标准执行 SOP

1. 输入与用途定标：确认文生 3D / 单图 / 多图输入及最终输出规格（打印 `.stl` 或展示 `.glb`）。
2. 云端任务生成：调用混元生 3D 官方接口提交任务并轮询完成，将 `.glb`/`.obj` 下载至本地工作目录。
3. 尺度与坐标对齐：经 `mcp-for-blender` 导入模型，设置毫米单位、应用旋转缩放并将模型底面贴紧 `Z=0`。
4. 拓扑修整：针对 3D 打印需求运行 Voxel Remesh、闭合破洞与重算外向法线；展示需求保留材质并适度减面。
5. 多视角复核导出：抓取前/侧/顶/等轴测截图自检结构畸变，导出终版文件并报告精确包围盒尺寸（mm）。

## 安全合规红线与执业边界

- 强制 `BLENDER_MCP_SAFE_MODE=1` 与回环地址监听，使用最新已修复历史漏洞的 `mcp-for-blender` 版本。
- 不擅自清空用户既有 Blender 场景内容，操作前提示新建/备份 `.blend` 工程。
- 不推荐商业许可受限且已停更的本地重型推理权重包。

## 已明确排除项目

- `Tencent/Hunyuan3D-2` 与 `Hunyuan3D-2.1` 本地权重（超 12 个月未提交、需 10~29 GB 显存且带商用限制）
- `tripo-mcp`（超 12 个月未维护）

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
