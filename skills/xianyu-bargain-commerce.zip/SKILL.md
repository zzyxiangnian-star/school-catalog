---
name: xianyu-bargain-commerce
description: 面向闲鱼（shaxiu/XianyuAutoAgent、DoLovya/xianyu-mcp-server）与独立站（stripe/ai 官方 MCP）的 7×24 自动客服、阶梯底价议价博弈、Stripe 收款查账及 C2M 定制参数交接技能。
---

# 闲鱼电商阶梯议价与接单（xianyu-bargain-commerce）

## 1. 触发条件

满足以下任一场景时启用本技能：
- 需要监听或回复闲鱼（Goofish）买家的售前咨询、技术答疑、多轮议价或售后纠纷消息。
- 需要为海外/独立站买家通过官方 Stripe MCP 生成收款链接（Payment Link）、核验订单支付状态或排查未到账账单。
- 买家提出 3D 打印、非标结构件、定制周边等 C2M 需求，需要结构化采集草图与尺寸参数并转交下游设计/建模 Bot（`#06 ComfyUI`、`#02 CAD Bot`）。
- 需要对当日未完结议价、压价红线单或异常订单执行巡检并触发飞书人工升级。

---

## 2. GitHub 开源底座

1. **`shaxiu/XianyuAutoAgent`**（实时值守与意图路由）：
   - `main.py` 负责 WebSocket 实时监听闲鱼消息流；`XianyuAgent.py` 执行意图分类并分发至议价专家、技术专家与默认客服；`XianyuApis.py` 封装网页端签名与接口调用。
   - 支持 `.env` 配置 `TOGGLE_KEYWORDS`（默认句号 `。`）进行人工接管切换，以及 `SIMULATE_HUMAN_TYPING=True` 模拟人工打字节奏。
2. **`DoLovya/xianyu-mcp-server`**（MCP 工具层，底层依赖 `pyxianyu`）：
   - 通过 `uvx --from xianyu-mcp-server xianyu-mcp-server` 运行，提供 `qr_login_generate` / `qr_login_status` / `check_login` 登录态检测、商品检索与上下架（如 `downshelf_item` / `reshelf_item`）、IM 会话与消息读写工具。
3. **`stripe/ai`**（官方支付与账单 MCP）：
   - 对接官方远程托管 MCP 服务 `https://mcp.stripe.com`（通过 OAuth 授权），用于创建受控 Payment Link、查询 Checkout Session / PaymentIntent / Invoice 状态及争议记录。

---

## 3. 前置环境与凭证检查（铁律）

在执行任何回复、报价、生成链接或巡检前，**必须先完成前置检查**；任一关键条件不满足时，一次性告知用户缺失项与配置步骤并输出 `BLOCKED`，**绝不假装操作成功或凭空报价**：

1. **闲鱼通道检查**：
   - 若走 MCP 通道，先调用 `check_login` 验证 `XIANYU_COOKIE` / `XIANYU_COOKIE_FILE` 是否有效；若 Cookie 留空或过期，提示用户启动首次扫码模式（`qr_login_generate`）或重新从 `goofish.com` 抓包填入 Cookie 后停止。
   - 若走 `XianyuAutoAgent` 后台通道，确认 `.env` 中 `API_KEY` 与 `COOKIES_STR` 已配置且监听进程在线。
2. **Stripe 通道检查**（涉及独立站收款/查账时）：
   - 检查 `stripe` MCP 是否已通过 `https://mcp.stripe.com` 完成 OAuth 授权；未授权时引导用户先在插件/MCP 管理中完成 Stripe 登录授权后停止。
3. **本地规则资产检查**：
   - 确认当前商品在卖家提供的阶梯底价表（含 `list_price`、`tier1_offer_price`、`tier2_floor_price`、`hard_redline_price`）及商品知识库中存在记录；**无底价表严禁自动议价**。
4. **飞书告警配置检查**：
   - 检查飞书群机器人 Webhook 或审批流入口是否配置；未配置时在回复中标注仅输出本地升级摘要。

---

## 4. 分步执行 SOP

### Step 1：消息接入与意图路由
读取最新买家消息与近 5-10 轮会话上下文，分类为唯一主意图：
- `TECH_QA`：询问规格、材质、兼容性、成色、发货地或售后质保。
- `BARGAIN`：直接砍价、要包邮、要赠品、拿同行低价对比压价。
- `C2M_CUSTOM`：提供草图/图片/尺寸，要求 3D 打印、定制外壳/支架/零件或改色改款。
- `STRIPE_BILLING`：独立站下单索要付款链接、询问汇率/发票或反馈“已付款未更新”。
- `DISPUTE_OR_REDLINE`：要求仅退款、威胁差评/投诉、商品破损纠纷或连续压价低于红线。

### Step 2：知识库精准答疑（`TECH_QA`）
1. 仅依据商品知识库与商品详情页已有参数作答；禁止脑补未标明的耐温、承重、接口协议或质保年限。
2. 答疑末尾附带轻量化成交引导（如确认使用场景或是否需要适配配件），不主动降价。

### Step 3：严格阶梯底价博弈（`BARGAIN`）
严格遵循**四段不越线原则**，禁止第一轮直接报出底价：
1. **第 1 轮（锚定价值）**：守住 `list_price`，强调成色/工艺/质检/售后保障；可先提供 `non_price_perks`（如满额包邮、加赠小配件、优先排产）替代降价。
2. **第 2 轮（一阶松口）**：买家明确表达成交意愿但嫌贵时，可下探至 `tier1_offer_price` 区间，单轮让步不超过 `max_concession_per_turn`，话术绑定“今日拍下/顺丰直发/老客补贴”条件。
3. **第 3 轮（二阶底线拉扯）**：仅在买家连续追砍且诚意高时，小步逼近 `tier2_floor_price`，明确告知“已到成本极限，再低无法出货”。
4. **红线熔断（`< hard_redline_price`）**：买家出价跌破利润红线或反复刷屏压价时，礼貌拒绝并给出最后可成交价；若触发暴躁辱骂或大单特殊议价，立即走 Step 6 升级。

### Step 4：独立站 Stripe 收款与查账（`STRIPE_BILLING`）
1. 核对买家确认的 SKU、数量、收货国家/地区与币种。
2. 调用官方 Stripe MCP 创建对应金额与商品描述的 Payment Link（严禁自行修改单价低于 `hard_redline_price` 折算价）。
3. 买家反馈已付款时，通过 Stripe MCP 查询对应 Session / PaymentIntent 状态；**仅当状态明确为 `paid` 且实收金额与币种一致时**，才确认收款成功并流转发货，否则回报待支付/异常原因。

### Step 5：C2M 定制需求参数提取与建单（`C2M_CUSTOM`）
当买家提出 3D 打印或定制加工需求时，必须通过 1-2 轮精炼追问集齐以下必选项，再生成下游交接包：
- **基础外观/结构输入**：买家发送的草图、参考照片或文字描述（计算原文件 `sha256`）。
- **物理尺寸（强制统一 `mm`）**：`length_mm`、`width_mm`、`height_mm`，以及关键孔径/壁厚/装配公差（`tolerance_mm`，默认提醒客户确认）。
- **材料与工艺**：如 `PLA`、`PETG`、`ABS`、光敏树脂或 CNC 金属，以及表面颜色/强度要求。
- **数量与预期交期**：起订数量与最晚交付日期。

### Step 6：越线与异常纠纷升级（`DISPUTE_OR_REDLINE`）
出现以下任一情况，立即停止自动承诺与自动降价：
- 买家出价低于 `hard_redline_price` 且拒绝接受底线报价；
- 出现仅退款、平台介入投诉、差评威胁、快递破损赔付；
- `shaxiu/XianyuAutoAgent` / `xianyu-mcp-server` 抛出登录过期或风控验证拦截；
- Stripe 出现退款争议（Dispute）或金额不符。

处置动作：
1. 若使用 `XianyuAutoAgent`，按配置的人工接管机制（如 `TOGGLE_KEYWORDS`）切为人工托管状态，避免 AI 继续误回复。
2. 向买家发送缓冲安抚话术（“已为您登记加急核实，专属人工客服将在第一时间接入处理”）。
3. 组装脱敏后的飞书审批/告警单并发送通知。

---

## 5. 跨 Bot 协同接口契约

### 5.1 上游输入契约（接收来自店铺配置与渠道网关）

```json
{
  "channel": "xianyu | independent_site",
  "conversation_id": "conv_908123",
  "buyer_id": "buyer_masked_01",
  "sku_id": "C2M-3DP-BASE-01",
  "message_text": "这个支架能按 120x80x45mm 改厚一点用 PETG 打印吗？预算85行不行",
  "attachments": [
    { "path": "uploads/sketch_01.png", "sha256": "e3b0c44298fc1c149afbf4c8996fb924..." }
  ],
  "pricing_rule": {
    "currency": "CNY",
    "list_price": 128.0,
    "tier1_offer_price": 115.0,
    "tier2_floor_price": 102.0,
    "hard_redline_price": 95.0,
    "max_concession_per_turn": 10.0
  }
}
```

### 5.2 下游交接产物格式

#### （1）交接 `#06 ComfyUI`（外观草图渲染 / 概念图深化）
当买家仅有模糊文字描述或手绘涂鸦、需先出视觉效果图确认外观时输出：

```json
{
  "target_bot": "#06 ComfyUI",
  "c2m_order_id": "C2M-20261118-0042",
  "reference_images": [
    { "path": "uploads/sketch_01.png", "sha256": "e3b0c44298fc1c149afbf4c8996fb924..." }
  ],
  "visual_spec": {
    "subject": "桌面路由器倒挂散热支架",
    "style": "工业产品三视图与磨砂质感白底预览",
    "color_material_hint": "哑光黑 PETG 质感，边角倒圆角",
    "aspect_ratio": "1:1"
  },
  "acceptance_note": "生成 2 张确认图供买家定版后再转入工程建模"
}
```

#### （2）交接 `#02 CAD Bot`（工程参数化建模与切片前校验）
当尺寸与公差确认完毕、进入 3D 打印/CNC 建模时输出：

```json
{
  "target_bot": "#02 CAD Bot",
  "c2m_order_id": "C2M-20261118-0042",
  "unit": "mm",
  "dimensions_mm": {
    "length_mm": 120.0,
    "width_mm": 80.0,
    "height_mm": 45.0,
    "wall_thickness_mm": 3.2,
    "tolerance_mm": 0.2
  },
  "material": "PETG",
  "mechanical_constraints": "底部预留 2 个 M4 沉头安装孔，距边 12mm；需承受 1.5kg 长期悬吊",
  "reference_artifacts": [
    { "path": "uploads/sketch_01.png", "sha256": "e3b0c44298fc1c149afbf4c8996fb924..." }
  ],
  "expected_deliverables": ["model.step", "model.stl", "dfm_check_report.md"]
}
```

#### （3）交接飞书人工审批 / 异常升级单

```json
{
  "target": "feishu_webhook",
  "ticket_id": "ESC-20261118-001",
  "channel": "xianyu",
  "conversation_id": "conv_908123",
  "buyer_id": "buyer_masked_01",
  "sku_id": "C2M-3DP-BASE-01",
  "intent": "DISPUTE_OR_REDLINE",
  "buyer_offer": 85.0,
  "hard_redline_price": 95.0,
  "risk_level": "MEDIUM",
  "summary": "买家要求 PETG 定制加厚支架并砍价至 85 CNY，低于红线价 95 CNY",
  "action_required": "确认是否按非标定制加价报价，或直接维持底价拒单"
}
```

---

## 6. 质检与异常处理

| 异常场景 | 识别信号 | 强制处置动作 |
| :--- | :--- | :--- |
| Cookie 失效或平台风控拦截 | `check_login` 失败、接口返回验证码/滑块/403 | 立即停止自动发送消息，输出 `BLOCKED` 并飞书告警店主重新扫码或更新 `COOKIES_STR`，**严禁尝试破解验证码** |
| Stripe 未授权或查账超时 | MCP 返回 OAuth 失效、401 或网络超时 | 暂停发货确认，告知买家“账单同步核验中”，触发 `ESCALATED` 通知人工后台复核 |
| 尺寸单位歧义（cm/寸 vs mm） | 买家表述“12公分”“3寸”或无单位 | 回复买家二次确认并自动换算为 `mm`（例如 `12cm -> 120.0 mm`）后才允许交接 `#02 CAD Bot` |
| 重复发送或死循环对话 | 连续 3 轮无新参数/纯情绪刷屏 | 暂停自动追问，切换人工接管模式并记录巡检日志 |

---

## 7. 禁止越界事项

- **严禁击穿底价红线**：无人工飞书明确放行凭据，绝对禁止以低于 `hard_redline_price` 的价格成交或生成对应金额的 Stripe Payment Link。
- **严禁越权写操作**：未经用户明确确认，绝不执行 Stripe 退款、作废发票、修改闲鱼商品标价或调用 `downshelf_item` 下架正常商品。
- **严禁泄露凭证与隐私**：输出、工单、日志中绝不出现明文 `COOKIES_STR`、`XIANYU_COOKIE`、`API_KEY`、Stripe Secret Key 及买家完整姓名/手机号/收货地址。
- **严禁伪造执行结果**：工具未就绪或调用失败时必须如实汇报 `BLOCKED` 与具体报错，绝不虚构“已回复买家”或“已收到货款”。
