---
name: "中英文文献综述与 GB/T 7714 答辩流程"
description: "并行检索真实文献、核验 GB/T 7714-2015 题录并生成答辩 PPT 骨架"
---

# 学习与论文助手 — 中英文文献综述与 GB/T 7714 答辩流程

## 定位与适用范围

结合 paper-search-mcp 与目录科研/PPT 技能，检索真实中英文论文构建文献矩阵、按 GB/T 7714-2015 格式化参考文献并生成精炼答辩展示文稿。

- **归属 Bot**：`thesis-study-assistant`（分类：`research`）
- **协同目录技能**：pptx, scientific-research-pack
- **关联推荐 MCP 插件**：paper-search-mcp

## 核心开源工具栈（国内高可用）

- openags/paper-search-mcp — MIT（免密钥直连 arXiv/OpenAlex/Crossref/PubMed）
- K-Dense-AI/scientific-agent-skills — MIT（按需挑选综述与引文管理技能）
- anthropics/skills (`skills/pptx`) — Apache-2.0（可编辑 PPTX 导出）
- ChengDSYJ-Studio/CNKI-Enhanced-MCP — GPL-3.0（仅由用户作为独立外部进程自备，支持 GB/T 7714）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- Python 3.10+、uv；英文检索可零密钥直接运行 `uvx paper-search-mcp`
- 中文知网检索如选用外部 `CNKI-Enhanced-MCP`，需用户在本机 Chrome/Edge 登录机构或个人账号（不可静态打包源码进闭源工程）
- 可选安装 Zotero 7+、Pandoc（配合 GB/T 7714 Numeric CSL）及 LibreOffice（PPT 质检）

## 标准执行 SOP

1. 检索词拆解：提炼核心概念中英文同义词、限定时间跨度与目标数据库来源。
2. 真实文献拉取：并行调用 `paper-search-mcp` 与用户外部检索接口获取真实摘要与元数据，记录未查得项而不脑补。
3. 矩阵与综述构建：按“研究问题—方法—核心结论—局限”汇总对比表，起草三级综述写作提纲。
4. GB/T 7714-2015 规范化：校验文献标识（`[J]`/`[D]`/`[C]`/`[M]`）、卷期页码与 3 人截断规则（等 / et al.）。
5. 答辩 PPT 产出：提炼 12~18 页答辩逻辑骨架（每页<=80 字突出图表结论），调用 `pptx` 导出并用 LibreOffice 转图自检。

## 安全合规红线与执业边界

- 保持 `paper-search-mcp` 的 Sci-Hub 相关配置关闭，杜绝版权违规获取。
- 严格禁止模型凭记忆杜撰参考文献或虚构实验数据与引用数量。
- GPL-3.0/AGPL-3.0 第三方本地服务仅由用户独立进程运行，不集成打包或用于批量采集。

## 已明确排除项目

- 各类知网自动打码脚本与批量爬虫（触及 IP 封禁与版权风险）
- 任何 Sci-Hub 通道及全量加载 177 项无关学科技能的低效配置

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
