# `mineru-doc-etl` 参考底座与执行规范（`references/stack-and-sop.md`）

## 1. 核心 GitHub 开源底座与关联能力

| 组件类型 | 名称 / 仓库 | 定位与职责边界 |
| :--- | :--- | :--- |
| 核心开源解析引擎 | [`opendatalab/MinerU`](https://github.com/opendatalab/MinerU) | 负责复杂 PDF/扫描件的版面分析（多栏/阅读序）、表格结构识别、LaTeX 公式还原、图像切片与块级坐标（`content_list.json` / `middle.json`）输出。 |
| 目录下既有协同技能 | `pdf` | 用于 MinerU 执行前的轻量预检（读取页数、元数据、判断是否存在原生文本层）或极简纯文本文档的快速抽样对比。 |
| 关联 MCP 插件 | `filesystem` | 用于在本地授权工作区读取待解析文档、计算校验信息、写入 ETL 输出目录及核验生成的 `.md` / `.json` / `images/` 资产完整性。 |

---

## 2. 典型 MCP 与本地环境配置模板

### 2.1 `filesystem` MCP 配置参考
需确保待解析源目录与 ETL 输出目录均在授权路径白名单内：

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/path/to/doc_inbox",
        "/path/to/etl_output"
      ]
    }
  }
}
```

### 2.2 `opendatalab/MinerU` 本地安装与预检命令
若前置检测未发现可用 CLI，提示用户按官方仓库指引完成安装与模型拉取：

```bash
# 1. 创建隔离环境并安装 MinerU（以官方 PyPI/GitHub 最新说明为准）
pip install -U "mineru[core]"
# 若需使用旧版入口，对应包为 magic-pdf[full]

# 2. 环境变量与工具链自检（执行任何解析前必跑）
which mineru || which magic-pdf
mineru --version || magic-pdf -v
nvidia-smi  # 可选：用于判断是否具备 VLM/GPU 加速条件
```

### 2.3 典型场景 CLI 调用模板

```bash
# 场景 A：通用多栏论文 / 硬件规格书（CPU 友好，低幻觉 pipeline 后端）
mineru -p "./inbox/spec_sheet.pdf" -o "./etl_output/spec_sheet" -b pipeline

# 场景 B：复杂跨页财务报表 / 密集 LaTeX 公式（高精度 VLM 后端，需 GPU/推理服务）
mineru -p "./inbox/annual_report.pdf" -o "./etl_output/annual_report" -b vlm-transformers

# 场景 C：老旧扫描件 / 无文本层 PDF（强制 OCR，或使用 classic magic-pdf 入口）
mineru -p "./inbox/scanned_contract.pdf" -o "./etl_output/scanned_contract" -m ocr
# 旧版 magic-pdf 等价写法：
# magic-pdf -p "./inbox/scanned_contract.pdf" -o "./etl_output/scanned_contract" -m ocr
```

---

## 3. 下游交接契约模板（`etl_manifest.json`）

```json
{
  "schema_version": "1.0.0",
  "source_file": "/path/to/doc_inbox/annual_report.pdf",
  "sha256": "<64-char-hex>",
  "page_count": 48,
  "engine": "opendatalab/MinerU",
  "backend": "pipeline",
  "method": "auto",
  "artifacts": {
    "markdown": "./etl_output/annual_report/auto/annual_report.md",
    "content_list_json": "./etl_output/annual_report/auto/annual_report_content_list.json",
    "middle_json": "./etl_output/annual_report/auto/annual_report_middle.json",
    "images_dir": "./etl_output/annual_report/auto/images"
  },
  "qa_summary": {
    "unreadable_blocks": [
      {
        "page": 14,
        "bbox": [112, 430, 388, 492],
        "reason": "low_dpi_stamp_occlusion",
        "crop_image": "images/unreadable_p14_01.png"
      }
    ],
    "cross_page_tables_count": 3,
    "formula_blocks_count": 27
  },
  "downstream_targets": ["bot-07-bom", "bot-22-podcast", "bot-23-investment"]
}
```

---

## 4. 交付产物检验清单（Pre-flight & Post-ETL QA Checklist）

### 前置检测（Pre-flight）
- [ ] `filesystem` MCP 可访问目标源文件，且对目标输出目录具备写权限。
- [ ] 本地存在可执行 `mineru` 或 `magic-pdf` 命令，且核心模型权重已下载就绪（未出现缺权重报错）。
- [ ] 已读取源文件基础属性（文件大小、页数、SHA-256 哈希），并与用户指定页码范围匹配。

### 产出质检（Post-ETL）
- [ ] 输出目录同时包含完整 `.md`、`*_content_list.json`、`*_middle.json` 与 `images/` 目录，且页面覆盖无遗漏。
- [ ] `.md` 中所有 `![](images/...)` 引用均能在 `images/` 目录中找到对应非空图片文件。
- [ ] `content_list.json` 中每个内容块均保留 `page_idx` 与 `bbox` 边界框坐标，无无出处裸文本拼接。
- [ ] 跨页表格已核对表头延续与行对齐情况；复杂数学公式使用标准 `$...$` / `$$...$$` 定界。
- [ ] 所有模糊、印章遮挡、乱码或低置信度 OCR 块均已显式标记 `[UNREADABLE: page=..., bbox=...]`，并保留原图切片路径，未做任何主观猜测补全。
- [ ] 已生成 `etl_manifest.json`，可直接交付 `#07 BOM 核算`、`#22 播客合成` 或 `#23 投研` 消费。
