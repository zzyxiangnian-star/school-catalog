---
name: mineru-doc-etl
description: 基于 opendatalab/MinerU 的高精度文档结构化 ETL 技能。用于将双栏学术论文、扫描件、跨页复杂表格、LaTeX 公式、电路规格书与财报 PDF 无失真解析为带页码和块级坐标（bbox）的 Markdown、JSON 与独立图片/表格资产，并为 #07 BOM 核算、#22 播客合成及 #23 投研提供可追溯、零数值幻觉的下游输入。
---

# MinerU 高精度文档结构化解析（`mineru-doc-etl`）

## 1. 触发条件
当遇到以下任务时立即激活本技能：
- 需要将复杂版式 PDF（双栏/多栏论文、扫描件、电路器件规格书 Datasheet、上市公司财报/研报）提取为高保真 Markdown 或结构化 JSON。
- 文档内含密集 LaTeX 数学公式、化学式、跨页合并单元格表格或关键插图，普通文本抽取工具会导致串栏、丢表或公式乱码。
- 作为 `#07 BOM 核算`、`#22 播客合成` 或 `#23 投研` 的上游 ETL 前置工序，要求产出带 `page + bbox` 溯源坐标且严禁数值幻觉的可引用文本与切片资产。

---

## 2. GitHub 开源底座与关联工具链
- **核心引擎**：[`opendatalab/MinerU`](https://github.com/opendatalab/MinerU)（CLI 入口为 `mineru` 或旧版 `magic-pdf`）。
- **既有技能协同**：`pdf`（用于解析前快速探查 PDF 页数、加密状态与原生文本层情况，以及简单单栏纯文本抽样交叉比对）。
- **MCP 依赖**：`filesystem`（用于本地授权目录内的文件读取、SHA-256 校验、输出目录校验与产物清单写入）。

---

## 3. 前置环境检测与缺失引导（必须首先执行）
在运行任何解析前，必须先检查运行环境：
1. **文件与权限校验**：通过 `filesystem` MCP 确认源文件存在、非空、无密码锁死，且输出目录具备读写权限。
2. **MinerU 就绪校验**：检查本地 `mineru --version`（或 `magic-pdf -v`）以及 `magic-pdf.json` / `mineru.json` 模型权重目录是否存在；若需使用 `vlm` 后端，额外确认 GPU/vLLM/LMDeploy 推理服务可用。
3. **缺失报错原则**：若缺少 `mineru`/`magic-pdf`、模型权重未下载或 `filesystem` 未挂载对应路径，**立即输出 `BLOCKED`**，一次性列出所需安装命令或配置路径并停止执行，**绝不假装解析成功或降级为纯猜想输出**。

---

## 4. 分步执行 SOP

### Step 1：入库预检与指纹登记
- 计算源文件的 `SHA-256` 哈希、文件字节数，并联合 `pdf` 技能获取总页数与原生文本覆盖情况。
- 识别用户指定的页码范围、文档类型（`paper` / `datasheet` / `financial_report` / `scan`）与目标下游（`#07` / `#22` / `#23`）。

### Step 2：解析后端与模式路由
依据文档特征与本机算力选择最稳妥的 MinerU 参数：
- **标准数字原生 / 双栏论文 / 硬件规格书（CPU 或常规显存）**：
  `mineru -p <input_pdf> -o <output_dir> -b pipeline`
- **极复杂跨页合并表 / 高密度复杂公式 / 混排财报（具备 GPU / VLM 环境）**：
  `mineru -p <input_pdf> -o <output_dir> -b vlm-transformers`（或对应已部署的 `vlm` 后端）
- **纯扫描件 / 阴影印章件 / 乱码字体层 PDF**：
  强制指定 OCR 模式（`-m ocr`；旧版使用 `magic-pdf -p <input_pdf> -o <output_dir> -m ocr`）。

### Step 3：资产落盘与版面复核
确认目标输出目录已完整生成以下标准产物：
- `<doc>.md`：按阅读序重排的 Markdown 文档（含表格 HTML/Markdown 与 LaTeX 公式）。
- `<doc>_content_list.json`：扁平/层级语义块列表，包含 `type`、`text`/`table_body`/`img_path`、`page_idx` 及归一化 `bbox` 坐标。
- `<doc>_middle.json`：底层版面检测框与多栏切分中间数据，供二次溯源或排查错栏使用。
- `images/`：独立裁剪的插图、电路图、公式截图及表格原图切片。

### Step 4：零幻觉校验与不可辨认占位隔离
对解析结果执行严格的数据完整性核验（**禁止使用大模型语义脑补来“修复”OCR 识别结果**）：
1. **跨页表格核对**：检查跨页断裂表格的列数、表头延续关系与行边界；若仅能安全提取为各自独立表块，在清单中标注 `cross_page_candidate` 及关联页码，不擅自合并错行数据。
2. **公式定界检查**：确认行内 `$...$` 与行间 `$$...$$` LaTeX 定界符闭合完整，无控制字符污染。
3. **不可辨认占位机制**：凡遇低 DPI 模糊、印章遮挡、扫描折痕导致 OCR 置信度过低或出现乱码的数值、料号、单位及符号，**严禁猜测**，必须按如下标准占位替换并保留原图切片路径：
   `[UNREADABLE: page=<页码>, bbox=<x0,y0,x1,y1>, crop=<images/xxx.png>, reason=<模糊/遮挡/截断>]`

### Step 5：生成交接清单 `etl_manifest.json`
在输出根目录写入 `etl_manifest.json`（含源文件 `sha256`、`page_count`、引擎与后端参数、各产物的相对路径、`unreadable_blocks` 列表及下游接口标签）。

---

## 5. 跨 Bot 协同接口契约

### 5.1 上游输入契约
接收来自用户或调度器的结构化请求字段：
- `source_path`（必填，授权工作区内的绝对/相对路径）
- `output_dir`（必填，ETL 产物落盘目录）
- `doc_type`（`paper | datasheet | financial_report | scan`）
- `page_range`（可选，默认 `all`）
- `target_bots`（可选数组，如 `["#07", "#22", "#23"]`）

### 5.2 下游交接产物格式
- **交接给 `#07 BOM 核算`**：
  - 交付器件规格书/BOM 附表的 `content_list.json`（过滤 `type == "table"` 及参数段落）+ `images/` 表格原图切片 + 对应的 `page_idx` 与 `bbox`。
  - 关键约束：封装尺寸（如 `0402`、`QFN-32`）、容差、耐压值、料号后缀中的模糊字符必须保留 `[UNREADABLE]` 标记，由 #07 触发人工/原图复核，绝不自动补齐近似型号。
- **交接给 `#22 播客合成`**：
  - 交付去除了页眉、页脚、页码水印与孤立图表编码的阅读序正文切片（基于 `content_list.json` 按 `page_idx` 与阅读序组装），每段附带 `block_id` 以便引用回溯；复杂公式与大表格附简短 `[FORMULA_REF]` / `[TABLE_REF]` 锚点标记。
- **交接给 `#23 投研`**：
  - 交付财报/研报完整 `.md`、`content_list.json`（含精确 `page_idx + bbox` 溯源锚点）与独立财务报表切片图片；跨页三表标明页码跨度与货币单位原貌，确保每一笔营收、利润、同比增减数字均可回溯到原始 PDF 坐标框。

---

## 6. 质检与异常处理
- **页数不一致或半途截断**：检查 `content_list.json` 覆盖的最大 `page_idx` 是否等于源文件总页数；若缺页则标记 `PARTIAL` 并定位具体报错页码，建议分段重试（`--pages` / 拆分页面）。
- **显存溢出（OOM）**：使用 `vlm` 后端 OOM 时，显式提示用户降级切换 `-b pipeline` 或减小单次处理页数批大小，不静默丢页。
- **空输出或纯图片被误判为无字文档**：检查是否遗漏 `-m ocr` 参数，若无文本层则切换强制 OCR 模式重跑一次。

---

## 7. 禁止越界事项
- 严禁编造、推算或平滑修复任何未在原文/OCR 中清晰辨认的数字、小数点、单位、器件编码或专有名词。
- 严禁省略 `page_idx`、`bbox` 或 `sha256` 校验信息直接输出“浓缩总结版”代替结构化 ETL 资产。
- 严禁替代 `#07` 进行 BOM 成本计算、替代 `#22` 改写播客口语脚本、替代 `#23` 撰写投资评级结论。
- 严禁将用户本地未授权脱敏的涉密文档上传至外部在线 API。
