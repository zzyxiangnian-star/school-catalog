# 办公文档助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- anthropics/skills (`skills/docx`, `pptx`, `xlsx`, `pdf`) — Apache-2.0（2026-11 PR #2146 转开源）
- microsoft/markitdown (`markitdown-mcp`) — MIT，纯本地多格式转 Markdown
- haris-musa/excel-mcp-server — MIT（v2.3.3），内置 479 个 Excel 公式引擎
- lewis-hui1202/WPS-AI — MIT（可选国产 WPS MCP 加载项）

## 2. 本机前置准备

- Python 3.10+ 与 `uv`（国内 PyPI 镜像直装，无需独立显卡与 API Key）
- 版面视觉自检需本机安装 LibreOffice（`soffice --headless --convert-to pdf`）与 Poppler（`pdftoppm -png`）
- 配置 `excel-mcp-server` 时务必通过 `EXCEL_FILES_PATH` 或 `--allow-dir <工作目录>` 限定读写边界

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
{
  "mcpServers": {
    "markitdown": { "command": "uvx", "args": ["markitdown-mcp"] },
    "excel-mcp-server": {
      "command": "uvx",
      "args": ["excel-mcp-server", "stdio", "--allow-dir", "<你的工作目录>"],
      "env": { "EXCEL_FILES_PATH": "<你的工作目录>", "EXCEL_MCP_READ_ONLY": "0" }
    }
  }
}
```

## 4. 合规与物理安全核查项

- 严格遵守最小目录权限（`--allow-dir` / `EXCEL_FILES_PATH`），不读取授权外文件。
- 默认禁用 `--allow-vba-write`，杜绝生成带宏的工作簿。
- 敏感企业文件全程本地离线解析，禁止回传外部云端 OCR。

## 5. 已排除的过时或高风险方案

- `GongRzhe/Office-Word-MCP-Server`（已于 2026-03-03 归档，停止维护）
- `GongRzhe/Office-PowerPoint-MCP-Server`（已于 2026-03-03 归档，停止维护）

## 6. 交付产物检验清单

- [ ] Word/PPT 中文字体无乱码、行距与首行缩进符合格式要求
- [ ] Excel 工作簿不存在 `#REF!`、`#DIV/0!`、`#NAME?` 等公式错误
- [ ] PPT/PDF 已通过 LibreOffice + Poppler 转图确认无文本框遮挡与页尾溢出
- [ ] 未擅自覆盖原始文档（除非用户明确要求原位修改）
