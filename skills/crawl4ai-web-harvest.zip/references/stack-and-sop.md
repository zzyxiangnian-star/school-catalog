# Crawl4AI 网页信源采集参考手册（stack-and-sop）

本手册配套 `crawl4ai-web-harvest` 技能使用，汇总真实可用的开源底座、MCP/CLI 配置骨架与交付质检清单。

---

## 一、核心 GitHub 开源底座清单

| 仓库 | 定位与职责 | 典型适用场景 | 安装与基础诊断 |
| :--- | :--- | :--- | :--- |
| `unclecode/crawl4ai` | 异步 LLM 友好型爬虫与正文降噪引擎 | 静态页/文档站毫秒转 Markdown、`PruningContentFilter` 去噪、批量深度抓取 | `pip install -U crawl4ai`<br>`crawl4ai-setup`<br>`crawl4ai-doctor` |
| `browser-use/browser-use` | AI 驱动真实浏览器交互代理框架 | SPA 复杂点击、多步筛选、登录态表单操作、无限滚动与反爬应对 | `pip install "browser-use[cli]"` 或 `uv tool install "browser-use"`<br>`playwright install chromium`<br>`browser-use --doctor` |

---

## 二、典型 CLI 与可复现脚本模板

### 1. Crawl4AI CLI 快速验证（静态与文档站）

```bash
# 单页转去噪 Markdown
crwl https://example.com/article -o markdown

# 文档站广度优先深度抓取（限制最大页数，避免失控）
crwl https://docs.example.com --deep-crawl bfs --max-pages 10
```

### 2. Crawl4AI Python 可复现降噪采集脚本模板

```python
import asyncio
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from crawl4ai import AsyncWebCrawler, CrawlerRunConfig
from crawl4ai.content_filter_strategy import PruningContentFilter
from crawl4ai.markdown_generation_strategy import DefaultMarkdownGenerator


async def harvest_url(url: str, out_dir: Path, slug: str) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    prune_filter = PruningContentFilter(
        threshold=0.45,
        threshold_type="dynamic",
        min_word_threshold=5,
    )
    md_generator = DefaultMarkdownGenerator(
        content_filter=prune_filter,
        options={"ignore_links": False, "escape_html": True},
    )
    config = CrawlerRunConfig(
        markdown_generator=md_generator,
        excluded_tags=["form", "header", "footer", "nav", "aside"],
    )

    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(url=url, config=config)
        if not result.success:
            raise RuntimeError(f"Crawl failed for {url}: {result.error_message}")

        fit_md = ""
        if getattr(result, "markdown_v2", None) and result.markdown_v2.fit_markdown:
            fit_md = result.markdown_v2.fit_markdown
        elif isinstance(result.markdown, str):
            fit_md = result.markdown

        fetched_at = datetime.now(timezone.utc).isoformat()
        sha256 = hashlib.sha256(fit_md.encode("utf-8")).hexdigest()
        title = (result.metadata or {}).get("title") or slug

        md_path = out_dir / f"{slug}.md"
        json_path = out_dir / f"{slug}.json"

        frontmatter = (
            f"---\n"
            f"source_url: \"{url}\"\n"
            f"title: \"{title.replace(chr(34), chr(39))}\"\n"
            f"fetched_at: \"{fetched_at}\"\n"
            f"engine: \"crawl4ai\"\n"
            f"sha256: \"{sha256}\"\n"
            f"---\n\n"
        )
        md_path.write_text(frontmatter + fit_md, encoding="utf-8")

        payload = {
            "source_url": url,
            "title": title,
            "fetched_at": fetched_at,
            "engine": "crawl4ai",
            "sha256": sha256,
            "content_markdown": fit_md,
            "char_count": len(fit_md),
        }
        json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return payload


if __name__ == "__main__":
    # 示例入口：按需替换为目标 URL
    asyncio.run(harvest_url("https://example.com", Path("artifacts/harvest/demo"), "example"))
```

### 3. 关联 MCP 服务器配置骨架（`.mcp.json` / `claude_desktop_config.json`）

> 密钥与 Token 仅以环境变量占位符呈现，严禁在仓库中硬编码真实凭证。

```json
{
  "mcpServers": {
    "firecrawl": {
      "command": "npx",
      "args": ["-y", "firecrawl-mcp"],
      "env": {
        "FIRECRAWL_API_KEY": "${FIRECRAWL_API_KEY}"
      }
    },
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp@latest", "--headless"]
    },
    "chrome-devtools": {
      "command": "npx",
      "args": ["-y", "chrome-devtools-mcp"]
    },
    "tavily": {
      "command": "npx",
      "args": ["-y", "tavily-mcp"],
      "env": {
        "TAVILY_API_KEY": "${TAVILY_API_KEY}"
      }
    },
    "browser-use": {
      "command": "uvx",
      "args": ["browser-use", "--mcp"],
      "env": {
        "OPENAI_API_KEY": "${OPENAI_API_KEY}"
      }
    }
  }
}
```

---

## 三、监控源表参考格式（仅用户主动启用例程时使用）

```yaml
# crawl-sources.yaml
sources:
  - id: "sec-ai-news"
    url: "https://example.com/changelog"
    mode: "static"          # static | dynamic
    downstream: ["etl", "podcast"]
    min_interval_hours: 24
```

---

## 四、交付产物检验清单（Delivery Checklist）

交付给用户或下游 Bot（`#04` / `#22` / `#23`）前，逐项核对：

1. **前置与合法性**
   - [ ] 运行时 / MCP 工具已在真实环境执行并返回结果，未编造页面内容或时间戳。
   - [ ] 未绕过付费墙、未尝试破解验证码或人机校验；遇阻断已标明 `BLOCKED` 并停机提示。
2. **去噪与语料质量**
   - [ ] 已剔除导航栏、页脚、弹窗广告、Cookie Banner 与无关脚本标签。
   - [ ] 核心正文完整（SPA 异步区块已等待渲染完毕，无骨架屏或“Loading...”残留）。
   - [ ] 中英文编码为 UTF-8，无乱码、断行错乱或 Markdown 表格崩坏。
3. **元数据与可复现性**
   - [ ] `.md` 含完整 YAML Frontmatter（`source_url`、`title`、`fetched_at`、`engine`、`sha256`）。
   - [ ] `.json` 可被 `json.loads` 合法解析，且 `sha256` 与正文内容实算一致。
   - [ ] 已附上或保存可复现采集脚本（`scripts/harvest_<job_id>.py`）及 `manifest.json` 汇总索引。
