# 公众号与小红书写手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- JimLiu/baoyu-skills — MIT（排版与通义/智谱/MiniMax/即梦/Seedream 生图集成）
- comeonzhj/Auto-Redbook-Skills — MIT（零生图成本本地 1080x1440 Playwright 卡片渲染备选）
- caol64/wenyan-mcp — Apache-2.0（v2.0.4，微信公众号官方草稿箱 API）
- xpzouying/xiaohongshu-mcp — Apache-2.0（仅高风险可选外置本地进程，默认不自动发帖）

## 2. 本机前置准备

- Node.js 18+；生图模式需用户在本地配置至少 1 个国内平台密钥（如 `DASHSCOPE_API_KEY`、`MINIMAX_API_KEY`、`ZAI_API_KEY` 等）
- 使用 `wenyan-mcp` 推送公众号草稿需提前配置 `WECHAT_APP_ID`、`WECHAT_APP_SECRET` 与公众号后台出口 IP 白名单
- 若启用本地卡片渲染或高风险可选浏览器工具，需本机已安装 Chrome 或 Playwright 浏览器内核

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
{
  "mcpServers": {
    "wenyan-mcp": {
      "command": "npx",
      "args": ["-y", "@wenyan-md/mcp"],
      "env": {
        "WECHAT_APP_ID": "<你的公众号 AppID>",
        "WECHAT_APP_SECRET": "<你的公众号 AppSecret>"
      }
    }
  }
}
```

## 4. 合规与物理安全核查项

- 小红书默认采用“文案 + 配图 + 本地图文包导出”模式，禁止默认执行自动发帖或持久化模拟登录。
- 严禁启用逆向网页 Cookie 或高危抓包工具。
- 所有输出内容不替代用户对事实真实性与平台规则的终审。

## 5. 已排除的过时或高风险方案

- `iFurySt/RedNote-MCP`（超 12 个月未维护且仅支持读取）
- `baoyu-skills` 中任何带 `danger` 前缀的逆向 Cookie 自动发布技能

## 6. 交付产物检验清单

- [ ] 3 套方案均附 5 个备选标题且符合对应平台篇幅上限
- [ ] 违禁词与引流敏感词已逐条标出并给出安全替换
- [ ] 配图比例正确（公众号 2.35:1 / 小红书 3:4）且无文字裁切
- [ ] 公众号仅写入草稿箱未群发；小红书仅导出本地文件夹未自动发布
