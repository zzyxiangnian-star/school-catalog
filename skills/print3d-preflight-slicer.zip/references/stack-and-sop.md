# 3D 打印预检与切片助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- mikedh/trimesh — MIT（v5.2.1，纯 Python 网格包围盒、水密性与壁厚计算）
- OrcaSlicer/OrcaSlicer — AGPL-3.0（v2.5+ 内置本机 MCP，外置独立安装）
- OrcaSlicer/orcaslicer-mcp-skills — AGPL-3.0（官方配套外置工具说明参考）

## 2. 本机前置准备

- 从官方渠道（GitHub Releases / 官网）在本机独立安装 OrcaSlicer >= 2.5，并在 `Preferences > General > AI features` 按需启用内置 MCP
- Python 环境安装 `pip install trimesh[easy]`（纯 CPU，免独立显卡）

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
# 本地几何预检依赖安装：
pip install "trimesh[easy]"

# OrcaSlicer >= 2.5 请在软件菜单 Preferences -> General -> AI features 中开启内置 MCP，
# 并在本机复核切片预览与温度上下限（严禁开启免确认自动下发打印）。
```

## 4. 合规与物理安全核查项

- 严格禁用任何物理端 `start_print` 自动执行，只产出静态预检报告和 `.gcode.3mf` 文件。
- 提醒用户下载 OrcaSlicer 认准官方域名与 GitHub Releases 谨防仿冒钓鱼网站。
- 严格遵循 AGPL-3.0 边界，仅作外部进程联动。

## 5. 已排除的过时或高风险方案

- `PyMeshLab`（更新停滞且 Qt/C++ 体积过重，优先使用纯 Python `trimesh`）
- 任何默认启用物理机直连自动开打的不受控打印插件

## 6. 交付产物检验清单

- [ ] 已确认模型尺寸与目标热床成形体积匹配（单位为 mm）
- [ ] 网格封闭性通过检查，thin-wall 风险区域已书面标注
- [ ] `.gcode.3mf` 预览的喷嘴与热床温度符合耗材标签安全阈值，且未下发物理打印
