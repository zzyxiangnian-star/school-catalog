---
name: kicad-pcb-engineering
description: 挂载 lamaalrajih/kicad-mcp 与 KiCad 9.0+ CLI 对接硬件 PCB 工程：解析原理图（.kicad_sch）、网表连通性、元件封装库匹配与 BOM 清单，自动执行 ERC 与 DRC，核查电源回流、差分线/线宽载流及 Gerber/Drill/Pick-and-Place 投板文件完整性，并导出标准 BOM 衔接 #07 沙盒 BOM 成本核算。
---

# KiCad PCB 工程审查与投板验收（`kicad-pcb-engineering`）

本技能专为 `#13 硬件 PCB Bot`（`kicad-pcb-bot`）设计，围绕 **KiCad 9.0+** 工程提供从原理图网表、规则检查、高速/电源工艺复核到投板制造包验收的标准化工程流水线。

---

## 1. 触发条件

满足以下任一场景时激活本技能：
- 用户要求审查、排错或验收本地 KiCad（`.kicad_pro` / `.kicad_sch` / `.kicad_pcb`）工程。
- 用户需要在发板打样或 SMT 贴片前执行 ERC/DRC 检查、核查电源载流/差分线/封装匹配。
- 用户要求生成并校验 Gerber、Excellon Drill、Pick-and-Place（POS）坐标与标准化 BOM 物料清单。
- 上游需求需要导出清洗后的标准 BOM，交由 **#07 沙盒 BOM 核算 Bot** 进行物料与贴片成本估算。

---

## 2. GitHub 开源底座与依赖工具

- **核心 MCP 底座**：[`lamaalrajih/kicad-mcp`](https://github.com/lamaalrajih/kicad-mcp)（项目发现、原理图 S-expression/网表解析、BOM 提取、DRC 检查）
- **文件系统能力**：`filesystem` MCP（在授权工程目录下安全读取设计文件、校验 `fab_out/` 输出并计算文件哈希）
- **本地编译器/检查引擎**：KiCad `9.0+` 官方 `kicad-cli`（用于确定性生成 ERC/DRC 报告与 Gerber/Drill/POS/BOM）

---

## 3. 前置检测与缺失报错引导（铁律）

在读取或审查任何工程前，必须先执行环境探测；**任意前置项缺失时必须一次说清修复步骤并停止，绝不假装检查通过**：

1. **检测 `kicad-mcp` 挂载状态**：确认当前会话可调用 KiCad MCP 工具（如工程列表 / 网表 / DRC 读取）。
   - 若未挂载：提示用户按 `lamaalrajih/kicad-mcp` 文档完成 `make install`，配置 `.env` 中的 `KICAD_SEARCH_PATHS` 指向工程目录，并在 MCP 客户端配置中添加该服务后重试。
2. **检测 `kicad-cli` 版本**：运行 `kicad-cli version` 验证版本为 `9.0` 及以上（Windows 常见路径为 `C:\Program Files\KiCad\9.0\bin\kicad-cli.exe`）。
   - 若未安装或版本低于 9.0：明确告知缺失版本要求，请用户安装 KiCad 9.0+ 并将其 `bin` 目录加入系统 `PATH`。
3. **检测工程文件与版本快照**：确认目标目录内 `.kicad_pro`、`.kicad_sch`、`.kicad_pcb` 存在；检查是否存在 `.git` 或备份，若无 Git 版本控制且需执行写入/导出操作，先提醒用户执行 `git init && git commit` 留存快照。

---

## 4. 分步执行 SOP

### Stage 1：工程盘点与原理图网表解析
1. 通过 `kicad-mcp` 列出目标工程，或用 `filesystem` 读取 `.kicad_pro` 获取层数、板厂规则预设与网络类（Netclass）。
2. 解析 `.kicad_sch` 原理图与导出网表，重点核查：
   - **连通性异常**：是否存在无 `No Connect (X)` 标记的悬空引脚、单引脚网络（Single-pin net）、同名网络标签大小写拼写不一致（如 `VCC_3V3` vs `VCC_3v3`）。
   - **电源冲突**：PWR_FLAG 缺失导致的电源驱动报错、不同电压域（如 `3V3` 与 `5V`）误短接。
   - **封装库匹配度**：逐颗核对元件 `Reference`、`Value` 与 `Footprint` 是否已填且非空；校验原理图符号引脚编号（Pin）与 PCB 封装焊盘编号（Pad）是否一致（典型高发错误：二极管 A/K、SOT-23 1-2-3 脚序反转、QFN 散热焊盘 `EP` 漏连接）。

### Stage 2：自动化 ERC 与 DRC 规则检查
1. 调用 `kicad-cli`（或通过 `kicad-mcp` DRC 工具）执行全量规则检查，**必须加 `--exit-code-violations` 防止违规静默通过**：
   - 原理图 ERC：`kicad-cli sch erc --output reports/erc-report.rpt --severity-all --exit-code-violations <project>.kicad_sch`
   - PCB DRC：`kicad-cli pcb drc --output reports/drc-report.rpt --exit-code-violations <project>.kicad_pcb`
2. 解析 `.rpt` 报告：按 **Error（阻塞投板）**、**Warning（需人工签字确认）**、**Unconnected Items（未连接网络）** 分类汇总，提取违规类型、涉及网络名与坐标 `(X, Y) mm`。

### Stage 3：物理布线与可制造性（DFM/SI/PI）深度核查
在软件 DRC 通过基础上，基于板厂常见工艺基线（默认 2/4 层 FR-4、外层铜厚 `1 oz / 35 um`、最小线宽/线距 `4/4 mil` 或 `0.1/0.1 mm`）复核以下物理项：
1. **电源回流路径**：
   - 检查关键高速信号（CLK/USB/SPI/I2C/差分对）下方参考平面是否完整，是否跨越电源分割槽（Split Plane）。
   - 检查开关电源（DC-DC）输入/输出电容接地回流环路面积及功率地（PGND）与模拟地（AGND）单点连接策略。
2. **线宽载流与铜厚温升**：
   - 识别主供电轨与大电流路径（如 `VBUS`、电池 `VBAT`、电机驱动、LDO/Buck 输出），对照铜厚与目标电流核验走线宽度及换层过孔数量（单颗常规 0.3 mm 过孔载流约 1–1.5 A，大电流需多孔并联）。
3. **差分对与阻抗控制**：
   - 核对差分网络（如 `USB_DP/USB_DM`、`ETH_TX+/TX-` 等）是否成对等长、线距一致、无锐角及无孤立过孔Stub。
4. **常规可制造性细节**：
   - 确认丝印未压焊盘、器件极性/一脚标识（Pin 1 Dot）清晰可见、器件边缘距闭合 `Edge.Cuts` 板框留有安全工艺边距（通常 ≥ 0.3–0.5 mm，V-cut 拼板 ≥ 1 mm）。

### Stage 4：投板制造文件生成与完整性校验
1. 导出 Gerber（KiCad 9 强制使用复数子命令 `gerbers`）：
   - `kicad-cli pcb export gerbers --output fab_out/gerbers/ <project>.kicad_pcb`
2. 导出 Excellon 钻孔文件：
   - `kicad-cli pcb export drill --output fab_out/gerbers/ <project>.kicad_pcb`
3. 导出 Pick-and-Place 贴片坐标（单位固定 `mm`）：
   - `kicad-cli pcb export pos --output fab_out/pos.csv --format csv --units mm --side both <project>.kicad_pcb`
4. 完整性验收：
   - 校验 `fab_out/gerbers/` 内必需层是否存在且非空（`F.Cu`、`B.Cu`、内层铜皮、阻焊 `F/B.Mask`、丝印 `F/B.Silkscreen`、钢网 `F/B.Paste`、闭合外框 `Edge.Cuts`、`.drl` 钻孔文件）。
   - 校验 `pos.csv` 坐标单位是否为 `mm`，顶底层（`top`/`bottom`）器件归属与板面方向是否合理。
   - 对 `fab_out/` 产物生成 SHA-256 校验清单留档。

### Stage 5：标准 BOM 清洗与跨 Bot 协同交接
1. 导出合并后的工程 BOM：
   - `kicad-cli sch export bom --output fab_out/bom.csv --format csv --fields "Reference,Value,Footprint,LCSC,MPN,DNP" --group-by "Value,Footprint,MPN" --sort-asc <project>.kicad_sch`
2. 剔除或明确标记 `DNP`（Do Not Populate）虚拟测试点/不贴片器件，检查缺失 `MPN`（制造商料号）或 `LCSC`（立创商城编号）的物料行并标注风险。
3. 当用户需要估算样板或小批量采购成本时，生成标准交接包对接 **#07 沙盒 BOM 核算 Bot**。

---

## 5. 跨 Bot 协同接口契约

### 5.1 上游输入契约
- **必填字段**：`project_dir`（绝对路径）、主原理图文件名（`*.kicad_sch`）、主 PCB 文件名（`*.kicad_pcb`）。
- **可选约束**：`layers`（层数，默认从 `.kicad_pro` 读取）、`copper_oz`（铜厚，默认 `1oz`）、`fab_house`（目标板厂工艺基线）、`power_nets`（重点载流网络及额定电流列表，单位 `A`）。

### 5.2 下游交接产物格式（对接 `#07` 物料成本核算）
向 `#07` 交接以下标准化文件与元数据摘要：
- **核心文件**：`fab_out/bom_for_costing.csv`（UTF-8 编码）
  - 必需列头：`Reference,Value,Footprint,Quantity,MPN,LCSC,DNP,Layer_Side`
  - 示例行：`C1 C2 C5,100nF 16V,Capacitor_SMD:C_0402_1005Metric,3,CL05B104KO5NNNC,C1525,false,top`
- **附属制造摘要（JSON / 文本块）**：
  - `project_name`: 工程名称
  - `board_size_mm`: `[width_mm, height_mm]`（单位统一 `mm`）
  - `layer_count`: 铜层数
  - `smd_unique_parts` / `tht_unique_parts`: 贴片与插件种类数及总焊点数（用于评估 SMT 开机费/上料位）
  - `bom_sha256`: `bom_for_costing.csv` 的 SHA-256 校验哈希
  - `fab_bundle_dir`: `fab_out/` 投板文件目录路径

---

## 6. 质检与异常处理

- **ERC/DRC 报错但用户称“已知可忽略”**：必须在报告中原文保留该违规条目，标注 `USER_WAIVED`，严禁静默删改规则或伪造 `0 Errors`。
- **原理图与 PCB 网表不同步**：检测到 `.kicad_sch` 修改时间晚于 `.kicad_pcb` 或存在未更新网表差异时，直接判定为 `FIX_REQUIRED`，要求用户在 KiCad UI 中执行 `Update PCB from Schematic (F8)` 并重新保存。
- **单面/双面混合或缺省坐标**：`pos.csv` 导出为空时，检查器件封装属性是否误设为 `Exclude from position files` 或 `Through hole`。

---

## 7. 禁止越界事项

- **严禁直接篡改原生设计**：未经用户显式确认及版本备份，禁止直接脚本重写 `.kicad_sch` / `.kicad_pcb` 走线或删除设计规则。
- **严禁虚构电气或报价结论**：不可编造芯片封装引脚定义、不可猜测未查证的元件单价与交期（交期与报价计算交由 `#07` 负责）。
- **严禁跳过阻塞门禁**：任何 `Error > 0`、`Unconnected > 0` 或缺少 `Edge.Cuts`/`.drl` 的工程，一律禁止给出 `READY_FOR_FAB` 结论。
