---
name: "机械公差与零部件强度校核流程"
description: "强制量纲计算，自动查表 GB/T 1800 公差、材料牌号、螺栓及齿轮强度"
---

# 机械设计计算助手 — 机械公差与零部件强度校核流程

## 定位与适用范围

基于 BaratiLab 机械工程技能方法，驱动本地 Python pint、scipy 与 python-gearbox 执行物理量纲锁定计算与国标配合查表，附带特种设备合规免责声明。

- **归属 Bot**：`mechanical-calc-bot`（分类：`other`）
- **协同目录技能**：无（本技能独立承担全流程）
- **关联推荐 MCP 插件**：filesystem

## 核心开源工具栈（国内高可用）

- BaratiLab/mechanical-engineering-skills — MIT（构件尺寸、公差叠算与选材方法）
- hgrecco/pint — BSD（强制物理量纲运算）
- efirvida/python-gearbox — MIT（ISO 6336:2019 对应 GB/T 3480 齿轮强度）
- CoolProp/CoolProp & fluids & puran-water/fluids-mcp — MIT（可选流体热物性扩展）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- Python 3.10+ 与 uv，在本地环境安装 `numpy scipy matplotlib pint CoolProp fluids python-gearbox`
- 全部核心运算均在本地纯 CPU 执行，零 API Key 与独立显卡依赖

## 标准执行 SOP

1. 物理量纲锁定：在本地计算脚本入口用 `pint.UnitRegistry` 解析所有力、扭矩、功率、转速与长度，杜绝 N·m 与 N·mm 错位。
2. 国标公差查表：依据 GB/T 1800.1-2020 计算指定基本尺寸与公差代号（如 H7/g6、H7/k6）的上下极限偏差与极值间隙/过盈量。
3. 材料数据匹配：从 45 钢、40Cr、Q235B、304、6061-T6 牌号表检索屈服/抗拉强度，补充建议热处理状态。
4. 螺栓与轴系校核：按 GB/T 3098.1 求解高强螺栓（8.8/10.9/12.9）推荐预紧力与参考拧紧力矩；核算轴段弯扭合成应力与挠度。
5. 齿轮安全系数计算：调用 `python-gearbox` 输出 ISO 6336 齿面接触与齿根弯曲安全系数，生成附应力集中警示的计算书。

## 安全合规红线与执业边界

- 报告明确提醒“未计入局部应力集中与疲劳折减时安全余量偏乐观”，强调仅限初算方案评估。
- 起重机械、压力容器、载人设备等特种承力部件，严禁替代持证单位和注册工程师法定审批。

## 已明确排除项目

- `e-dub/pygear`（仍停留在 Python 2.6 年代，早已停止维护）
- `claude-engineering-skills`（偏向纯流体且超半年无活跃更新）与纯网页 `fit-calculator`

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
