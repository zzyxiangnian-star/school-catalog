---
name: customer-support
description: "Triage support tickets, draft customer responses, escalate complex issues, and turn resolved cases into knowledge base articles."
---

# Customer Support

Triage support tickets, draft customer responses, escalate complex issues, and turn resolved cases into knowledge base articles.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (5)

- `customer-support-customer-escalation`
- `customer-support-customer-research`
- `customer-support-draft-response`
- `customer-support-kb-article`
- `customer-support-ticket-triage`
