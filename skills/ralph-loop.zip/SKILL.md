---
name: ralph-loop
description: "Continuous self-referential AI loops for iterative development, implementing the Ralph Wiggum technique until task completion."
---

# Ralph Loop

Continuous self-referential AI loops for iterative development, implementing the Ralph Wiggum technique until task completion.

Source: https://github.com/cursor/plugins

## Included Skills (3)

- `ralph-loop-cancel-ralph`
- `ralph-loop-ralph-loop`
- `ralph-loop-ralph-loop-help`
