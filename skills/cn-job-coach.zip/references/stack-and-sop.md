# 简历与求职教练 — 技术栈与配置参考

## 1. 选型开源仓库索引

- rendercv/rendercv — MIT（v2+ 内置 Typst 排版引擎，无需安装 TeXLive）
- rendercv/rendercv-skill — MIT（官方 RenderCV CLI 编排参考）
- anthropics/skills (`skills/docx`) — Apache-2.0（可编辑 Word 简历输出）
- microsoft/markitdown (`markitdown-mcp`) — MIT（本地简历原件读取）

## 2. 本机前置准备

- Python 3.12+ 并通过国内镜像执行 `pip install "rendercv[full]"`（内置 Typst，无需 TeXLive、API Key 或独立显卡）
- 若需读入已有 PDF/DOCX 原件，挂载 `markitdown-mcp`；重度多版本 Web 库用户可按需自部署开源 Reactive Resume

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
# 本地 RenderCV（内置 Typst，免装 TeXLive）安装：
pip install "rendercv[full]"

# 渲染中文简历 PDF 命令：
rendercv render <your_resume.yaml>
```

## 4. 合规与物理安全核查项

- 系统级约束：严格忠于真实经历，遇到需要量化成果时先留空占位请候选人补全数字，绝不自行编造虚假指标。
- 隐私保护：提醒简历含手机/邮箱/薪资，坚持本地 Typst/Word 渲染，不向未知网盘与在线免费站上传。
- 严禁产出自动爬取招聘网站或批量轰炸 HR 的自动化脚本。

## 5. 已排除的过时或高风险方案

- 需本机安装超 4 GB TeXLive 且中文宏包频频报错的传统重型 LaTeX 简历方案
- 任何违反招聘平台服务条款的自动群发打招呼外挂或岗位爬虫脚本

## 6. 交付产物检验清单

- [ ] 全部履历时间、公司名与量化数据 100% 来源用户本人确认，无虚构
- [ ] PDF 控制在 1~2 页精排且通过文本复制检查（ATS 可解析）
- [ ] BOSS 直聘/脉脉开场白控制在 150 字以内，直击 JD 核心需求
