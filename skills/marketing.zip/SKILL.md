---
name: marketing
description: "Create content, plan campaigns, analyze performance across marketing channels, maintain brand voice, and track competitors."
---

# Marketing

Create content, plan campaigns, analyze performance across marketing channels, maintain brand voice, and track competitors.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (8)

- `marketing-brand-review`
- `marketing-campaign-plan`
- `marketing-competitive-brief`
- `marketing-content-creation`
- `marketing-draft-content`
- `marketing-email-sequence`
- `marketing-performance-report`
- `marketing-seo-audit`
