---
name: "全链路分镜配音与剪辑合成流程"
description: "配音驱动镜头时长、生成多模态素材并导出剪映专业版草稿或 MP4"
---

# 剪辑师 — 全链路分镜配音与剪辑合成流程

## 定位与适用范围

集成大陆直连 MiniMax MCP（生图/Hailuo视频/TTS）与 VectCutAPI/FFmpeg 本地剪辑链路，先定音画时长再拼装时间线，并在批量生成前核对预估费用。

- **归属 Bot**：`video-editor-bot`（分类：`design`）
- **协同目录技能**：无（本技能独立承担全流程）
- **关联推荐 MCP 插件**：minimax-mcp

## 核心开源工具栈（国内高可用）

- MiniMax-AI/MiniMax-MCP — MIT（大陆节点 `api.minimaxi.com` 配音/生图/Hailuo 视频）
- sun-guannan/VectCutAPI — Apache-2.0（输出剪映专业版 10.x 草稿 `dfd_*` 及实时预览）

## 首次使用前置检查

在正式处理用户文件或工程任务前，先检查以下前置条件是否就绪；若缺少运行环境或授权密钥，一次清晰列出安装指引并暂停，绝不假装执行成功：

- Python 3.10+、uv 与本机 FFmpeg（用于音频时长探测及直接渲染 MP4）
- 配置大陆版 `MINIMAX_API_KEY`，保持 `MINIMAX_API_RESOURCE_MODE=local` 落盘
- 如需剪映草稿二次精修，本机安装剪映专业版 10.x 并克隆启动 `VectCutAPI`

## 标准执行 SOP

1. 环境与预算确认：检查 FFmpeg 与 MiniMax 配置；统计拟生成片段数并给出预估费用清单，等用户确认后继续。
2. 分镜脚本拆解：将文案拆为带编号的分镜表，写清景别、运镜、口播词、字幕与目标画幅（1080x1920 或 1920x1080）。
3. 配音先行定长：优先生成各句 TTS 配音并用 `ffprobe` 读取真实毫秒级音频长度，锁定对应镜头时长。
4. 视觉素材生成：生成关键帧图与 Hailuo 动态片段，统一下载保存至项目素材子目录。
5. 多轨剪辑组装：使用 VectCutAPI（`create_draft` / `add_video` / `add_audio` / `add_subtitle`）导出剪映草稿，或运行本地 FFmpeg 合成带字幕预览 MP4。

## 安全合规红线与执业边界

- 按量计费的视频/图片生成批量动作前必须由用户确认预算。
- 音色克隆需明确具备声音权利人授权，成片发布需遵守国家深度合成内容显著标识规定。
- 提示剪映草稿格式随客户端大版本升级可能变化，建议同步保留原始素材文件夹。

## 已明确排除项目

- 依赖海外 Sora/Runway 非官方逆向接口且不可直连的视频生成项目
- 未绑定 `MINIMAX_API_HOST=https://api.minimaxi.com` 导致跨境超时的高延迟配置

> 详细 MCP/CLI 配置示例与逐项交付检验表请参阅 `references/stack-and-sop.md`。
