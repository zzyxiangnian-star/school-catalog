# 合同与条款审阅助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- anthropics/knowledge-work-plugins (`legal/skills/review-contract`) — Apache-2.0（合同核查规范参照）
- SecurityRonin/docx-mcp — MIT（纯本地写入 Word 原生修订与段落批注，免装 Word）
- microsoft/markitdown (`markitdown-mcp`) — MIT（合同文本与表格无损结构提取）
- anthropics/skills (`docx`, `pdf`) — Apache-2.0（本地文件读取与对照辅助）

## 2. 本机前置准备

- Python 3.10+ 与 uv；本地运行 `uvx markitdown-mcp` 与 `uvx docx-mcp-server`，无需安装 Word/WPS 或独立显卡
- 扫描版不可复制文字的 PDF，需提前经本地离线 OCR 提取文本后送审

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
{
  "mcpServers": {
    "markitdown": { "command": "uvx", "args": ["markitdown-mcp"] },
    "docx-mcp": { "command": "uvx", "args": ["docx-mcp-server"] }
  }
}
```

## 4. 合规与物理安全核查项

- 报告首尾必须醒目附带：“本审阅结果仅供商业风险提示与文本核对，不构成正式法律意见，重大合同须交执业律师复核。”
- 合同文件全部本地解析读取不自动外传云盘；同时向用户明确若使用云端大模型对话推理时的数据传输范围。
- Word 批注必须写入另存副本，绝不原地覆写用户原始合同。

## 5. 已排除的过时或高风险方案

- `GongRzhe/Office-Word-MCP-Server`（已于 2026-03-03 归档且缺乏原生 OOXML 红线批注支持）

## 6. 交付产物检验清单

- [ ] 每一条风险提示均逐字引用了合同原段落与原文句子
- [ ] 主体名称、信用代码、大小写金额与分期比例和 100% 已完成复算核对
- [ ] 首尾均完整附有“仅供风险提示与文本核对，不构成正式法律意见”免责声明
