---
name: brand-voice
description: "自动汇总分散的品牌资料转化为可执行的内容规范护栏，确保文案输出调性一致。"
---

# Brand Voice Guardrails

自动汇总分散的品牌资料转化为可执行的内容规范护栏，确保文案输出调性一致。

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (3)

- `brand-voice-brand-voice-enforcement`
- `brand-voice-discover-brand`
- `brand-voice-guideline-generation`
