---
name: mem0-postiz-growth
description: 跨 Bot 长期共享记忆沉淀与多平台社媒排期闭环技能。连接 mem0ai/mem0（memory MCP）与 gitroomhq/postiz-app（postiz CLI/API），完成跨 Bot 偏好与调性入库、多平台内容规格改写、人工审批门控排期及互动回流归因。
---

# 共享记忆沉淀与多平台社媒排期（`mem0-postiz-growth`）

## 1. 触发条件
当用户或上游业务 Bot 发起以下任务时触发本技能：
- 需要将调研、视频、客服、投研等业务 Bot 产出的客户痛点、品牌口吻、爆款复盘或合规禁忌写入跨 Bot 共享长期记忆。
- 需要基于既定品牌调性与受众偏好，将同一份素材改写为适配多个社媒平台规格的图文/视频发布文案与排期队列。
- 需要查询 Postiz 绑定渠道、生成待审排期草稿，或在用户明确审核放行后执行定时排期与互动回流复盘。

---

## 2. GitHub 开源底座与关联工具
- **长期共享记忆底座**：`mem0ai/mem0`（Python SDK `mem0ai` / Mem0 MCP）与关联 `memory` MCP（参考 `modelcontextprotocol/servers` 中 `@modelcontextprotocol/server-memory`）。
- **全网社媒调度底座**：`gitroomhq/postiz-app`（`postiz` CLI、Public API 与 Postiz MCP）。

---

## 3. 前置环境检测（Pre-flight Check）
执行任何写入或调度动作前，必须按顺序完成只读校验：
1. **检查记忆层连通性**：确认 `memory` MCP 工具可用，或本地 Python 环境可导入 `mem0` 且向量库/LLM 凭证已配置。
2. **检查 Postiz 调度端**：执行只读检测确认 CLI 与鉴权状态：
   - 检查 `postiz --version` 或 `postiz --help` 是否可执行；
   - 检查环境变量 `POSTIZ_API_KEY`（自托管实例需含 `POSTIZ_API_URL`）是否生效；
   - 执行 `postiz integrations:list` 获取真实可用的渠道 ID（`integration_id`）与平台类型。
3. **缺失阻断引导**：若上述任一环节未就绪，立即标记状态为 `BLOCKED`，一次性输出缺失组件名称、安装命令（`npm install -g postiz` / `pip install mem0ai`）与所需环境变量配置路径并**停止执行**，绝不跳过校验或伪造渠道 ID。

---

## 4. 分步执行 SOP

### Step 1：跨 Bot 记忆萃取与去重入库
1. 接收上游业务 Bot 交接产物或用户口述复盘，提取四类核心实体与观察事实：
   - `brand_tone`：品牌视觉基调、语言风格、禁用表达；
   - `audience_pref`：受众关注点、高频提问、转化触发点；
   - `viral_hook`：已验证的高点击开头、结构模板、最佳发布时段；
   - `banned_claims`：合规红线、不可承诺的收益或技术指标。
2. 调用 `memory` MCP 检索或 `m.search(...)` 查询现有相似记忆：
   - 若存在过时或矛盾条目，执行更新/合并而非盲目重复追加；
   - 严禁将 API Key、Cookie、客户手机号/微信号等 PII 写入记忆库。

### Step 2：记忆召回与多平台规格改写
1. 在内容创作或改写前，主动检索当前品牌的 `brand_tone`、`audience_pref` 与 `banned_claims`。
2. 依据 `postiz integrations:list` 返回的实际绑定平台，将母版内容改写为各平台适配版本：
   - **短图文/动态类（如 X/Twitter、Threads）**：提炼强钩子首句、控制单帖字数或拆分 Thread、精简标签。
   - **长图文/深度社区（如 LinkedIn、小红书图文）**：补充结构化痛点拆解、分段排版与互动引导问题。
   - **短视频/长视频（如 TikTok、YouTube、Instagram Reels）**：核验视频分辨率/纵横比与封面图，匹配平台标题长度与标签密度。
3. 逐条自检改写稿是否触发 `banned_claims` 禁忌。

### Step 3：本地待审队列生成与媒体预检
1. 校验本地待发图文/视频文件是否存在，计算文件 SHA-256 校验值。
2. 如用户明确需要进入 Postiz 预备队列，可先通过 `postiz upload <file>` 上传媒体资产获取内部 URL（只传媒体文件，不触发发帖）。
3. 生成本地结构化草稿清单 `postiz-queue-draft.json` 与可读审批摘要表，所有条目强制标记 `approval_status: "PENDING_APPROVAL"`。

### Step 4：人工审核门控与排期执行
1. **强制停顿点**：向用户展示完整的「多平台待审排期表」（含渠道、`integration_id`、正文全文、媒体校验值、拟定 ISO 8601 发布时间）。
2. **仅在用户明确回复批准指定 `draft_id` 或整批放行后**，方可调用 `postiz posts:create -c ... -s ... -i ...` 写入 Postiz 排期队列。
3. 记录返回的帖子 ID 与调度结果；若部分平台失败，保留原始草稿并明确报错原因，不静默忽略。

### Step 5：互动回流追踪与记忆反哺
1. 定期或按用户指令通过 `postiz posts:list` 拉取已发布帖子清单，结合用户提供的平台后台互动数据（曝光、点赞、评论、转化率）进行横向对比。
2. 将高表现内容结构与新发现的用户异议沉淀回 `memory` MCP / Mem0（标注周期、来源帖子 ID 与置信度），形成下一轮创作约束。

---

## 5. 跨 Bot 协同接口契约

### 5.1 上游业务 Bot 输入契约（适配调研、视频、客服、投研及 C2M/内容流水线）
上游 Bot 移交记忆或待发素材时，应提供如下标准化结构（JSON 或等效 Markdown 卡片）：
- `handoff_id`（字符串）：交接单唯一编号；
- `source_bot`（枚举）：`research` | `video` | `support` | `investment` | `c2m-workshop`；
- `memory_insights`（数组，可选）：`{ namespace, summary, evidence_ref }`；
- `media_assets`（数组，可选）：`{ local_path, aspect_ratio, duration_sec, sha256 }`；
- `core_message`（字符串）：核心卖点、版本更新或复盘结论；
- `compliance_notes`（数组，可选）：需规避的敏感词或绝对化表述。

### 5.2 下游交接与审批产物格式
1. **记忆快照输出**：每条变更附带 `memory_id`、`namespace`、`operation`（`ADD` / `UPDATE` / `SKIP`）与 `source_handoff_id`。
2. **审批单/飞书确认字段**：`batch_id`、`draft_id`、`platform`、`integration_id`、`scheduled_at`、`media_sha256`、`compliance_check`、`approval_status`（`PENDING_APPROVAL` -> `APPROVED` -> `SCHEDULED`）。

---

## 6. 质检与异常处理
- **渠道未绑定**：`postiz integrations:list` 为空或缺少目标平台时，停止生成该平台排期，提示用户先在 Postiz Web 控制台完成 OAuth 授权。
- **媒体超限或哈希不匹配**：发现本地文件缺失、SHA-256 与上游交接单不一致或纵横比不兼容时，标红阻断并退回上游 Bot 重新导出。
- **记忆冲突**：新输入与既有 `brand_tone` 或 `banned_claims` 冲突时，优先保留旧红线并向用户确认是否覆盖更新，不静默替换。

---

## 7. 禁止越界事项
- **严禁未审先发**：任何情况下绝不绕过人工确认直接执行公开群发或定时排期。
- **严禁伪造执行结果**：绝不编造不存在的 `integration_id`、Postiz 帖子 ID 或互动数据指标。
- **严禁写入敏感凭证**：绝不把 `POSTIZ_API_KEY`、账号密码、Cookie 或真实用户隐私写入共享记忆或输出日志。
