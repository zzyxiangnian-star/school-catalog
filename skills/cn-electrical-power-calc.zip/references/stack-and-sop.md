# 电气计算助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- Power-Agent/PowerMCP — MIT（v0.5.1，内置 pandapower / PyPSA 计算内核）
- Power-Agent/PowerSkills — MIT（潮流与短路风险排查技能参考）

## 2. 本机前置准备

- Python 3.11~3.14 环境并安装 `powermcp`（支持国内 PyPI 镜像直装，无需 API Key 与独立显卡）
- 建议配齐电压等级、主变 `Ud%`、上级电网最大/最小短路容量（或基准阻抗）实测资料

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
{
  "mcpServers": {
    "powermcp": {
      "command": "uvx",
      "args": ["--from", "powermcp", "powermcp", "run", "pandapower"],
      "env": {
        "POWERIO_MCP_ALLOWED_ROOTS": "<允许访问工程文件目录>"
      }
    }
  }
}
```

## 4. 合规与物理安全核查项

- 计算书首尾必须醒目附带：“仅限方案比选初步校核，中国大陆工程设计须由具备资质的设计院及注册电气工程师签章，严禁直接用于施工图与定值下发。”
- 禁止凭经验编造上级系统短路容量或变压器短路阻抗。

## 5. 已排除的过时或高风险方案

- `OpenDSSDirect.py`（已逾 2 年未更新）
- `opendss-mcp-server`（2025-01 后超 12 个月未维护；如需 OpenDSS 可改选官方 `powermcp[opendss]`）

## 6. 交付产物检验清单

- [ ] 报告首尾均包含注册电气工程师签章与施工图禁用免责声明
- [ ] 基准频率明确设置为 50 Hz，且同时校核了最大/最小运行方式
- [ ] 短路计算公式基准（GB/T 15544.1 / IEC 60909）与假设条件全部可溯源
