---
name: obsidian-skills
description: "Official Obsidian agent skills for Obsidian CLI, Obsidian Flavored Markdown, Bases views, JSON Canvas, web clipping, and headless sync."
---

# Obsidian Skills

Official Obsidian agent skills for Obsidian CLI, Obsidian Flavored Markdown, Bases views, JSON Canvas, web clipping, and headless sync.

Source: https://github.com/obsidianmd/obsidian-skills

## Included Skills (7)

- `obsidian-skills-defuddle`
- `obsidian-skills-json-canvas`
- `obsidian-skills-knap`
- `obsidian-skills-obsidian-bases`
- `obsidian-skills-obsidian-cli`
- `obsidian-skills-obsidian-headless`
- `obsidian-skills-obsidian-markdown`
