# 机械设计计算助手 — 技术栈与配置参考

## 1. 选型开源仓库索引

- BaratiLab/mechanical-engineering-skills — MIT（构件尺寸、公差叠算与选材方法）
- hgrecco/pint — BSD（强制物理量纲运算）
- efirvida/python-gearbox — MIT（ISO 6336:2019 对应 GB/T 3480 齿轮强度）
- CoolProp/CoolProp & fluids & puran-water/fluids-mcp — MIT（可选流体热物性扩展）

## 2. 本机前置准备

- Python 3.10+ 与 uv，在本地环境安装 `numpy scipy matplotlib pint CoolProp fluids python-gearbox`
- 全部核心运算均在本地纯 CPU 执行，零 API Key 与独立显卡依赖

## 3. MCP / CLI 启动参考模板

> 所有密钥、路径与账号标识均以 `<...>` 占位，切勿将真实密钥写入仓库或日志文件。

```text
# 本地纯 CPU 机械工程环境安装（国内镜像直装）：
pip install numpy scipy matplotlib pint CoolProp fluids python-gearbox

# 可选流体管道扩展（MIT）：
# uvx --python 3.12 --from git+https://github.com/puran-water/fluids-mcp.git@v0.1.0 fluids-mcp
```

## 4. 合规与物理安全核查项

- 报告明确提醒“未计入局部应力集中与疲劳折减时安全余量偏乐观”，强调仅限初算方案评估。
- 起重机械、压力容器、载人设备等特种承力部件，严禁替代持证单位和注册工程师法定审批。

## 5. 已排除的过时或高风险方案

- `e-dub/pygear`（仍停留在 Python 2.6 年代，早已停止维护）
- `claude-engineering-skills`（偏向纯流体且超半年无活跃更新）与纯网页 `fit-calculator`

## 6. 交付产物检验清单

- [ ] 所有数值计算均经本地 Python `pint` 执行并携带精确量纲单位
- [ ] 公差代号明确标注 GB/T 1800.1-2020 上下偏差与配合性质（间隙/过渡/过盈）
- [ ] 包含应力集中提醒及特种设备/关键安全件免责声明
