---
name: design
description: "Accelerate design workflows including critique, design system management, UX writing, accessibility audits, research synthesis, and dev handoff."
---

# Design

Accelerate design workflows including critique, design system management, UX writing, accessibility audits, research synthesis, and dev handoff.

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (7)

- `design-accessibility-review`
- `design-design-critique`
- `design-design-handoff`
- `design-design-system`
- `design-research-synthesis`
- `design-user-research`
- `design-ux-copy`
