---
name: slack
description: "结合官方 Slack 工作流，自动归纳群聊要点、起草回复并推进跨团队协同事项。"
---

# Slack Collaboration Pack

结合官方 Slack 工作流，自动归纳群聊要点、起草回复并推进跨团队协同事项。

Source: https://github.com/anthropics/knowledge-work-plugins

## Included Skills (2)

- `slack-slack-messaging`
- `slack-slack-search`
