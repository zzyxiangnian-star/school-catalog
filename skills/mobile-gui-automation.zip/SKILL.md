---
name: mobile-gui-automation
description: 手机真机跨 App 自动化操控技能。基于 mobile-next/mobile-mcp（ADB/WDA 原生无障碍树）与 X-PLUG/MobileAgent（多模态视觉策略）驱动 iOS/Android 真机与模拟器，完成小红书、抖音、闲鱼、美团、微信小程序等跨应用操作，并支持接收 #08 视频 Bot 15s 成片执行备用机发布引流。
---

# 手机真机跨 App 自动化操控（`mobile-gui-automation`）

## 1. 触发条件
当任务涉及以下任意场景时启用本技能：
1. **无网页端或强风控移动端操作**：小红书图文/短视频发布、抖音互动、闲鱼商品管理、美团/微信小程序操作、企业打卡或仅限 App 内的跨软件闭环流程。
2. **跨 Bot 协同发布**：接收来自 `#08 视频 Bot` 产出的 15s 成片，推入备用机相册并操作移动端 App 完成发布与引流回传。
3. **移动端真机回归或界面取证**：需要基于原生无障碍树或屏幕截图真实点击、滑动并留存结果截图的任务。

---

## 2. GitHub 开源底座与关联工具
- **核心 MCP 插件**：`mobile-mcp`（对应开源项目 `mobile-next/mobile-mcp`，包名 `@mobilenext/mobile-mcp`）
  - 常用工具：`mobile_list_available_devices`、`mobile_list_elements_on_screen`、`mobile_take_screenshot`、`mobile_save_screenshot`、`mobile_get_screen_size`、`mobile_click_on_screen_at_coordinates`、`mobile_swipe_on_screen`、`mobile_type_keys`、`mobile_press_button`、`mobile_launch_app`、`mobile_terminate_app`、`mobile_list_apps`、`mobile_open_url`、`mobile_list_crashes`、`mobile_get_crash`。
- **多模态视觉兜底策略**：`X-PLUG/MobileAgent`（Mobile-Agent-v2 规划-决策-反思三阶段框架 / Mobile-Agent-E 自进化视觉策略，用于解决无障碍树缺失、Canvas 渲染、小程序嵌套等复杂视觉定位问题）。

---

## 3. 前置环境检测与缺失引导（Pre-flight Gate）

**在执行任何点击或启动 App 前，必须依次完成以下检测；任一项失败立即停止，输出 `BLOCKED` 与一次性排查命令，绝不假装操作成功：**

1. **MCP 工具可用性检查**：确认当前会话已挂载 `mobile-mcp` 工具集。若未挂载，提示用户在 `mcp.json` 中配置 `npx -y @mobilenext/mobile-mcp@latest` 并确保本机已安装 Node.js（≥ v20）。
2. **真机/模拟器连接检查**：
   - 调用 `mobile_list_available_devices`（或终端执行 `adb devices -l`）。
   - 若返回空列表或设备状态为 `unauthorized`/`offline`：引导用户开启 Android「开发者选项 → USB 调试」并点击弹窗「允许调试」（或检查 iOS 开发者模式与 Xcode/WebDriverAgent 状态），确认后重试。
3. **备用机安全隔离确认**：若任务为自动化营销发布（如小红书/抖音/闲鱼引流），核对 `device_id` 是否为指定的备用机/测试机，防止误操作用户主力机。
4. **中文输入法检查（Android）**：涉及中文标题/正文输入时，提示确认设备已安装并启用 `ADBKeyboard` 或确认 `mobile_type_keys` 可正确输入中文。
5. **多模态视觉模型凭证检查（若需 MobileAgent 兜底）**：确认用户已在本地环境配置可用的视觉模型 API Key 与基础依赖（`pip install -r requirements.txt`），未配置则提示补充后再继续视觉策略流程。

---

## 4. 跨 Bot 协同接口契约

### 4.1 上游输入契约（接收 `#08 视频 Bot` 15s 成片交付包）
接收上游任务时，须校验以下字段（缺失关键字段时向用户或调度方索取，不得臆造）：

```json
{
  "source_bot": "#08-video-bot",
  "task_id": "vid-20261118-001",
  "video_path": "./output/promo_15s.mp4",
  "video_spec": {
    "format": "mp4",
    "resolution": "1080x1920",
    "duration_sec": 15.0,
    "sha256": "<64位十六进制校验值>"
  },
  "publish_payload": {
    "target_platform": "xiaohongshu",
    "device_id": "<备用机序列号>",
    "title": "标题文本（≤20字）",
    "caption": "正文描述与引导文案",
    "hashtags": ["#标签1", "#标签2"],
    "cover_path": "./output/cover.jpg",
    "approval_status": "approved"
  }
}
```

**前置文件核验要求**：
- 确认 `video_path`（及可选 `cover_path`）本地真实存在；
- 校验文件 SHA256 与上游声明一致，且视频时长 ≤ 15s；
- 确认 `approval_status` 已通过审批（或用户当面确认发布），未审批时不得擅自点击「发布」。

### 4.2 下游交接产物格式（执行回执 JSON + 截图证据）
任务结束或被拦截时，统一输出如下结构化交接回执，并附上保存的终态截图路径：

```json
{
  "bot_id": "#16-mobile-device-gui-bot",
  "task_id": "vid-20261118-001",
  "status": "DONE",
  "device_id": "<实际执行设备ID>",
  "platform": "xiaohongshu",
  "actions_summary": [
    "校验 MP4 哈希一致并推送至 /sdcard/DCIM/Camera/",
    "触发媒体库扫描并启动小红书",
    "选定 15s 视频与封面、填入标题正文与标签",
    "完成发布并核验个人主页可见"
  ],
  "deliverables": {
    "post_url_or_id": "<仅填写从屏幕/分享复制中真实观测到的链接或ID，未获取到填 null>",
    "evidence_screenshots": [
      "./artifacts/mobile/preflight_screen.png",
      "./artifacts/mobile/published_result.png"
    ]
  },
  "blocked_reason": null
}
```

---

## 5. 分步执行 SOP（双引擎路由）

### Step 1：资源准备与媒体入机（仅发布流需要）
1. 校验上游视频文件完整性与时长（≤ 15s）。
2. 使用 `adb -s <device_id> push <video_path> /sdcard/DCIM/Camera/` 推入备用机（如有封面图一并推入）。
3. 广播 `MEDIA_SCANNER_SCAN_FILE` 刷新系统相册，避免 App 内媒体选择器找不到新文件。

### Step 2：应用唤醒与路由
- 使用 `mobile_list_apps` 确认目标 App 包名存在；通过 `mobile_launch_app` 启动（或 `mobile_open_url` 使用 DeepLink 直达目标页）。
- 等待页面稳定后执行感知。

### Step 3：双引擎感知与执行循环（Perception → Action → Reflection）
每一步操作严格遵守「先感知、再动作、后验证」：
1. **第一优先级（无障碍树感知）**：调用 `mobile_list_elements_on_screen` 获取结构化控件树，匹配 `text`、`content-desc` 或 `resource-id` 后计算中心坐标，调用 `mobile_click_on_screen_at_coordinates` 或 `mobile_type_keys` 执行操作。
2. **第二优先级（MobileAgent 多模态视觉策略兜底）**：当遇到以下情况时，立即调用 `mobile_take_screenshot` 并切换至 `X-PLUG/MobileAgent` 视觉策略：
   - 控件树返回为空、仅含单个 `WebView`/`Canvas` 容器（如微信小程序、游戏化互动弹窗、自定义底部发布栏）；
   - 目标图标无文本标签（如「+」号发布按钮、封面裁剪滑块、贴纸关闭「×」）。
   - 视觉策略闭环：
     - **Planning**：对照目标拆解当前子步骤与已完成进度；
     - **Decision**：结合截图与屏幕尺寸（`mobile_get_screen_size`）输出精确坐标或滑动向量；
     - **Reflection**：动作执行后再次截图比对前后画面变化；若连续 2 次画面无响应或进入错误弹窗，自动执行 `mobile_press_button("BACK")` 回退并修正路径。

### Step 4：发布前确认与结果核验
- 在点击最终「发布/提交」前，截图核对素材、标题、标签、可见性设置与账号一致性。
- 提交后等待跳转或刷新个人主页/列表，调用 `mobile_save_screenshot` 保存终态证据。

---

## 6. 质检与异常处理
1. **无响应/卡死重试**：单步操作后若页面未变化，先等待 1–2 秒重新拉取元素树或截图，最多重试 2 次；仍无响应则检查是否触发全屏广告/更新弹窗并优先关闭。
2. **App 闪退诊断**：若目标 App 意外退出，调用 `mobile_list_crashes` 与 `mobile_get_crash` 提取崩溃上下文并如实上报，不盲目无限重启。
3. **风控与人机校验熔断**：一旦识别到图形验证码、滑块验证、短信验证码、人脸识别、账号异常警告或登录失效，**立即终止自动化动作**，保存当前截图并输出 `NEED_HUMAN`，请用户手工完成验证后再继续。

---

## 7. 禁止越界事项
- **严禁绕过安全机制**：绝不编写或执行任何绕过验证码、滑块、人脸识别、虚拟定位篡改或反作弊风控的脚本。
- **严禁高危越权操作**：未经用户当面或审批单明确确认，绝不执行真实付款、转账、提现、解绑账号、删除历史内容或大批量骚扰私信/评论。
- **严禁虚报结果**：未在最终屏幕截图或元素树中真实观测到「发布成功 / 已发布 / 打卡成功」状态，绝不允许输出 `DONE` 或编造笔记链接。
